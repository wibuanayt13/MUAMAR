<?php

namespace Database\Seeders;

use App\Models\Category;
use Illuminate\Database\Seeder;

class CategorySeeder extends Seeder
{
    public function run(): void
    {
        // 1. Jasa Make-Up Artist (Service)
        $catJasa = Category::updateOrCreate(
            ['slug' => 'jasa-mua'],
            [
                'name' => 'Jasa Make-Up Artist',
                'type' => 'service',
                'icon' => 'sparkles',
                'sort_order' => 1,
                'is_active' => true,
            ]
        );

        $jasaSub = [
            ['slug' => 'mua-wedding-akad', 'name' => 'MUA Pernikahan & Akad', 'sort_order' => 1],
            ['slug' => 'mua-resepsi-adat', 'name' => 'MUA Resepsi & Baju Adat (Jawa/Sunda/dll)', 'sort_order' => 2],
            ['slug' => 'mua-wisuda-pesta', 'name' => 'MUA Wisuda, Yudisium & Pesta', 'sort_order' => 3],
            ['slug' => 'mua-lamaran-prewed', 'name' => 'MUA Lamaran, Tunangan & Prewedding', 'sort_order' => 4],
            ['slug' => 'mua-photoshoot-model', 'name' => 'MUA Photoshoot, Fashion & Modeling', 'sort_order' => 5],
            ['slug' => 'kursus-private-mua', 'name' => 'Kelas & Kursus Private Makeup Artist', 'sort_order' => 6],
        ];

        foreach ($jasaSub as $sub) {
            Category::updateOrCreate(
                ['slug' => $sub['slug']],
                [
                    'parent_id' => $catJasa->id,
                    'name' => $sub['name'],
                    'type' => 'service',
                    'sort_order' => $sub['sort_order'],
                    'is_active' => true,
                ]
            );
        }

        // 2. Produk Kosmetik & Makeup (Physical)
        $catProduk = Category::updateOrCreate(
            ['slug' => 'produk-kosmetik'],
            [
                'name' => 'Produk Kosmetik & Makeup',
                'type' => 'product',
                'icon' => 'heart',
                'sort_order' => 2,
                'is_active' => true,
            ]
        );

        $produkSub = [
            ['slug' => 'foundation-bb-cushion', 'name' => 'Foundation, BB Cream & Cushion', 'sort_order' => 1],
            ['slug' => 'bedak-powder-concealer', 'name' => 'Bedak Tabur, Padat & Concealer', 'sort_order' => 2],
            ['slug' => 'lipstik-lipcream-liptint', 'name' => 'Lipstik, Lip Cream & Lip Tint', 'sort_order' => 3],
            ['slug' => 'eyeshadow-eyeliner-mascara', 'name' => 'Eyeshadow, Eyeliner & Mascara', 'sort_order' => 4],
            ['slug' => 'blushon-highlighter-contour', 'name' => 'Blush On, Highlighter & Contour', 'sort_order' => 5],
            ['slug' => 'bulu-mata-palsu-lem', 'name' => 'Bulu Mata Palsu & Lem Bulu Mata', 'sort_order' => 6],
            ['slug' => 'kuas-sponge-alat-makeup', 'name' => 'Kuas Makeup, Sponge & Beauty Blender', 'sort_order' => 7],
            ['slug' => 'setting-spray-primer', 'name' => 'Setting Spray, Primer & Skincare Persiapan', 'sort_order' => 8],
        ];

        foreach ($produkSub as $sub) {
            Category::updateOrCreate(
                ['slug' => $sub['slug']],
                [
                    'parent_id' => $catProduk->id,
                    'name' => $sub['name'],
                    'type' => 'product',
                    'sort_order' => $sub['sort_order'],
                    'is_active' => true,
                ]
            );
        }

        // 3. Sewa Tenda & Perlengkapan Acara (Rental)
        $catRental = Category::updateOrCreate(
            ['slug' => 'sewa-perlengkapan-acara'],
            [
                'name' => 'Sewa Tenda & Perlengkapan Acara',
                'type' => 'rental',
                'icon' => 'home',
                'sort_order' => 3,
                'is_active' => true,
            ]
        );

        $rentalSub = [
            ['slug' => 'sewa-tenda-dekorasi-vip', 'name' => 'Sewa Tenda Dekorasi VIP & Semi-VIP', 'sort_order' => 1],
            ['slug' => 'sewa-kursi-futura-meja', 'name' => 'Sewa Kursi Futura, Cover & Meja Prasmanan', 'sort_order' => 2],
            ['slug' => 'sewa-panggung-pelaminan', 'name' => 'Sewa Panggung, Pelaminan & Backdrop Acara', 'sort_order' => 3],
            ['slug' => 'sewa-sound-lighting-genset', 'name' => 'Sewa Sound System, Lighting & Genset', 'sort_order' => 4],
            ['slug' => 'sewa-baju-pengantin-adat', 'name' => 'Sewa Baju Pengantin, Gaun & Pakaian Adat', 'sort_order' => 5],
            ['slug' => 'sewa-kotak-seserahan-hantaran', 'name' => 'Sewa Kotak Seserahan, Hantaran & Ring Box', 'sort_order' => 6],
        ];

        foreach ($rentalSub as $sub) {
            Category::updateOrCreate(
                ['slug' => $sub['slug']],
                [
                    'parent_id' => $catRental->id,
                    'name' => $sub['name'],
                    'type' => 'rental',
                    'sort_order' => $sub['sort_order'],
                    'is_active' => true,
                ]
            );
        }
    }
}
