<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\Conversation;
use App\Models\Message;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Payment;
use App\Models\PaymentAuditLog;
use App\Models\Product;
use App\Models\ProductVariant;
use App\Models\Provider;
use App\Models\ProviderAvailability;
use App\Models\RentalBooking;
use App\Models\RentalProfile;
use App\Models\Review;
use App\Models\ServiceBooking;
use App\Models\ServiceProfile;
use App\Models\ShippingHistory;
use App\Models\User;
use App\Models\VendorOrder;
use Carbon\Carbon;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // 1. Admin User
        $admin = User::firstOrCreate(
            ['email' => 'admin@muamar.test'],
            [
                'name' => 'Administrator MUAMAR',
                'password' => Hash::make('password'),
                'phone' => '081199998888',
                'role' => 'admin',
                'email_verified_at' => now(),
                'is_active' => true,
            ]
        );

        // 2. Customer Users
        $customer1 = User::firstOrCreate(
            ['email' => 'siti@customer.test'],
            [
                'name' => 'Siti Rahmawati',
                'password' => Hash::make('password'),
                'phone' => '081234567891',
                'role' => 'customer',
                'email_verified_at' => now(),
                'is_active' => true,
            ]
        );

        $customer2 = User::firstOrCreate(
            ['email' => 'anisa@customer.test'],
            [
                'name' => 'Anisa Putri',
                'password' => Hash::make('password'),
                'phone' => '081234567892',
                'role' => 'customer',
                'email_verified_at' => now(),
                'is_active' => true,
            ]
        );

        // 3. Provider Users & Studios
        $providerUser1 = User::firstOrCreate(
            ['email' => 'tasya@provider.test'],
            [
                'name' => 'Tasya Farasya (Glow Studio)',
                'password' => Hash::make('password'),
                'phone' => '081344445555',
                'role' => 'provider',
                'email_verified_at' => now(),
                'is_active' => true,
            ]
        );

        $provider1 = Provider::firstOrCreate(
            ['slug' => 'glow-by-tasya'],
            [
                'user_id' => $providerUser1->id,
                'business_name' => 'Glow by Tasya Studio',
                'description' => 'Studio makeup profesional spesialis wedding modern, wisuda, dan prewedding dengan produk premium internasional.',
                'address' => 'Jl. Kemang Raya No. 45',
                'city' => 'Jakarta Selatan',
                'province' => 'DKI Jakarta',
                'postal_code' => '12730',
                'latitude' => -6.261493,
                'longitude' => 106.810600,
                'is_location_public' => true,
                'phone' => '081344445555',
                'is_verified' => true,
                'status' => 'approved',
                'qris_active' => true,
                'cod_active' => true,
            ]
        );

        $providerUser2 = User::firstOrCreate(
            ['email' => 'bella@provider.test'],
            [
                'name' => 'Bella Wedding Organizer',
                'password' => Hash::make('password'),
                'phone' => '081377778888',
                'role' => 'provider',
                'email_verified_at' => now(),
                'is_active' => true,
            ]
        );

        $provider2 = Provider::firstOrCreate(
            ['slug' => 'bella-wedding-tent'],
            [
                'user_id' => $providerUser2->id,
                'business_name' => 'Bella Wedding & Rental Tenda',
                'description' => 'Layanan lengkap tata rias pengantin adat & modern, sewa tenda dekorasi VIP, kursi futura, serta panggung pelaminan.',
                'address' => 'Jl. Dago Asri No. 18',
                'city' => 'Bandung',
                'province' => 'Jawa Barat',
                'postal_code' => '40135',
                'latitude' => -6.885610,
                'longitude' => 107.613580,
                'is_location_public' => true,
                'phone' => '081377778888',
                'is_verified' => true,
                'status' => 'approved',
                'qris_active' => true,
                'cod_active' => false,
            ]
        );

        // 4. Set Provider Availabilities (Senin - Minggu 08:00 - 20:00)
        foreach ([$provider1, $provider2] as $prov) {
            for ($day = 0; $day <= 6; $day++) {
                ProviderAvailability::updateOrCreate(
                    ['provider_id' => $prov->id, 'day_of_week' => $day],
                    ['start_time' => '08:00:00', 'end_time' => '20:00:00', 'is_available' => true]
                );
            }
        }

        // 5. Categories
        $catJasa = Category::firstOrCreate(
            ['slug' => 'jasa-mua'],
            ['name' => 'Jasa Make-Up Artist', 'type' => 'service', 'icon' => 'sparkles', 'sort_order' => 1]
        );
        $subCatWedding = Category::firstOrCreate(
            ['slug' => 'mua-wedding'],
            ['parent_id' => $catJasa->id, 'name' => 'MUA Pernikahan & Akad', 'type' => 'service', 'sort_order' => 1]
        );
        $subCatAdat = Category::firstOrCreate(
            ['slug' => 'mua-resepsi-adat'],
            ['parent_id' => $catJasa->id, 'name' => 'MUA Resepsi & Baju Adat', 'type' => 'service', 'sort_order' => 2]
        );
        $subCatWisuda = Category::firstOrCreate(
            ['slug' => 'mua-wisuda'],
            ['parent_id' => $catJasa->id, 'name' => 'MUA Wisuda & Pesta', 'type' => 'service', 'sort_order' => 3]
        );
        $subCatLamaran = Category::firstOrCreate(
            ['slug' => 'mua-lamaran-prewed'],
            ['parent_id' => $catJasa->id, 'name' => 'MUA Lamaran & Prewedding', 'type' => 'service', 'sort_order' => 4]
        );
        $subCatPhoto = Category::firstOrCreate(
            ['slug' => 'mua-photoshoot-model'],
            ['parent_id' => $catJasa->id, 'name' => 'MUA Photoshoot & Modeling', 'type' => 'service', 'sort_order' => 5]
        );

        $catProduk = Category::firstOrCreate(
            ['slug' => 'produk-kosmetik'],
            ['name' => 'Produk Kosmetik & Makeup', 'type' => 'product', 'icon' => 'heart', 'sort_order' => 2]
        );
        $subCatFace = Category::firstOrCreate(
            ['slug' => 'foundation-bedak'],
            ['parent_id' => $catProduk->id, 'name' => 'Foundation & Bedak', 'type' => 'product', 'sort_order' => 1]
        );
        $subCatLip = Category::firstOrCreate(
            ['slug' => 'lipstik-lipcream'],
            ['parent_id' => $catProduk->id, 'name' => 'Lipstik & Lipcream', 'type' => 'product', 'sort_order' => 2]
        );
        $subCatEye = Category::firstOrCreate(
            ['slug' => 'eyeshadow-mascara'],
            ['parent_id' => $catProduk->id, 'name' => 'Eyeshadow & Mascara', 'type' => 'product', 'sort_order' => 3]
        );
        $subCatBlush = Category::firstOrCreate(
            ['slug' => 'blushon-highlighter'],
            ['parent_id' => $catProduk->id, 'name' => 'Blush On & Highlighter', 'type' => 'product', 'sort_order' => 4]
        );
        $subCatTools = Category::firstOrCreate(
            ['slug' => 'alat-kuas-makeup'],
            ['parent_id' => $catProduk->id, 'name' => 'Kuas & Alat Rias', 'type' => 'product', 'sort_order' => 5]
        );

        $catRental = Category::firstOrCreate(
            ['slug' => 'sewa-perlengkapan-acara'],
            ['name' => 'Sewa Tenda & Perlengkapan Acara', 'type' => 'rental', 'icon' => 'home', 'sort_order' => 3]
        );
        $subCatTenda = Category::firstOrCreate(
            ['slug' => 'sewa-tenda-dekorasi'],
            ['parent_id' => $catRental->id, 'name' => 'Sewa Tenda Dekorasi VIP', 'type' => 'rental', 'sort_order' => 1]
        );
        $subCatPanggung = Category::firstOrCreate(
            ['slug' => 'sewa-kursi-panggung'],
            ['parent_id' => $catRental->id, 'name' => 'Sewa Kursi & Panggung', 'type' => 'rental', 'sort_order' => 2]
        );
        $subCatSound = Category::firstOrCreate(
            ['slug' => 'sewa-sound-lighting'],
            ['parent_id' => $catRental->id, 'name' => 'Sewa Sound & Lighting', 'type' => 'rental', 'sort_order' => 3]
        );
        $subCatBusana = Category::firstOrCreate(
            ['slug' => 'sewa-busana-pengantin'],
            ['parent_id' => $catRental->id, 'name' => 'Sewa Busana & Gaun Pengantin', 'type' => 'rental', 'sort_order' => 4]
        );

        // 6. Products: Services
        $svcWedding = Product::firstOrCreate(
            ['slug' => 'paket-makeup-wedding-luxury-tasya'],
            [
                'provider_id' => $provider1->id,
                'category_id' => $subCatWedding->id,
                'name' => 'Paket Makeup Pengantin Luxury Glamour',
                'description' => 'Paket rias pengantin akad + resepsi di hari yang sama. Termasuk retouch 1x, softlens, melati fresh, dan hair do / hijab do eksklusif.',
                'type' => 'service',
                'base_price' => 3500000,
                'images' => ['https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=600&auto=format&fit=crop'],
                'is_active' => true,
            ]
        );
        ServiceProfile::updateOrCreate(
            ['product_id' => $svcWedding->id],
            [
                'duration_minutes' => 180, // 3 hours
                'buffer_minutes' => 60,   // 1 hour travel/prep buffer
                'capacity_per_slot' => 1,
                'artist_name' => 'Tasya Farasya (Senior Artist)',
                'service_area' => 'Jabodetabek',
            ]
        );

        $svcWisuda = Product::firstOrCreate(
            ['slug' => 'makeup-wisuda-flawless-tasya'],
            [
                'provider_id' => $provider1->id,
                'category_id' => $subCatWisuda->id,
                'name' => 'Makeup Wisuda Flawless & Tahan Seharian',
                'description' => 'Tata rias wisuda natural flawless, tahan minyak dan keringat seharian. Termasuk pemasangan bulu mata premium dan hijab do/styling rambut.',
                'type' => 'service',
                'base_price' => 450000,
                'images' => ['https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=600&auto=format&fit=crop'],
                'is_active' => true,
            ]
        );
        ServiceProfile::updateOrCreate(
            ['product_id' => $svcWisuda->id],
            [
                'duration_minutes' => 90,
                'buffer_minutes' => 30,
                'capacity_per_slot' => 1,
                'artist_name' => 'Team Glow Studio',
                'service_area' => 'Jakarta Selatan & Studio Kemang',
            ]
        );

        // 7. Products: Physical Makeup
        $prodFoundation = Product::firstOrCreate(
            ['slug' => 'glow-hd-foundation-matte-longwear'],
            [
                'provider_id' => $provider1->id,
                'category_id' => $subCatFace->id,
                'name' => 'Glow HD Foundation Longwear SPF 30',
                'description' => 'Liquid foundation berdaya tutup tinggi dengan hasil akhir satin matte yang tampak natural dan tahan hingga 16 jam.',
                'type' => 'physical',
                'base_price' => 185000,
                'images' => ['https://images.unsplash.com/photo-1599733589046-10c005739ef9?w=600&auto=format&fit=crop'],
                'is_active' => true,
            ]
        );
        ProductVariant::updateOrCreate(
            ['product_id' => $prodFoundation->id, 'sku' => 'GLW-FND-01-IVORY'],
            ['variant_name' => 'Shade 01 - Ivory Light', 'price' => 185000, 'stock' => 25, 'is_active' => true]
        );
        ProductVariant::updateOrCreate(
            ['product_id' => $prodFoundation->id, 'sku' => 'GLW-FND-02-BEIGE'],
            ['variant_name' => 'Shade 02 - Natural Beige', 'price' => 185000, 'stock' => 15, 'is_active' => true]
        );
        ProductVariant::updateOrCreate(
            ['product_id' => $prodFoundation->id, 'sku' => 'GLW-FND-03-HONEY'],
            ['variant_name' => 'Shade 03 - Warm Honey', 'price' => 185000, 'stock' => 10, 'is_active' => true]
        );

        // 8. Products: Rental Assets
        $rentalTenda = Product::firstOrCreate(
            ['slug' => 'sewa-tenda-roder-vip-dekorasi-per-meter'],
            [
                'provider_id' => $provider2->id,
                'category_id' => $subCatTenda->id,
                'name' => 'Sewa Tenda Dekorasi VIP Plafon & Tirai (1 Unit 4x6m)',
                'description' => 'Tenda pesta ukuran 4x6 meter dengan plafon kain dekorasi kombinasi warna mewah, tirai samping kedap, dan lampu hias tengah.',
                'type' => 'rental',
                'base_price' => 1200000, // per hari
                'images' => ['https://images.unsplash.com/photo-1519167758481-83f550bb49b3?w=600&auto=format&fit=crop'],
                'is_active' => true,
            ]
        );
        RentalProfile::updateOrCreate(
            ['product_id' => $rentalTenda->id],
            [
                'total_units' => 6, // 6 units max capacity
                'deposit_amount' => 500000,
                'min_rental_days' => 1,
                'buffer_hours' => 6, // 6 jam bongkar pasang
                'unit_type' => 'unit tenda (4x6m)',
            ]
        );

        $rentalKursi = Product::firstOrCreate(
            ['slug' => 'sewa-kursi-futura-cover-pita-paket-50'],
            [
                'provider_id' => $provider2->id,
                'category_id' => $subCatPanggung->id,
                'name' => 'Sewa Kursi Futura + Cover Ketat & Pita (Paket 50 Pcs)',
                'description' => 'Paket sewa 50 kursi besi futura empuk lengkap dengan cover kain putih premium dan pita warna sesuai tema pernikahan.',
                'type' => 'rental',
                'base_price' => 650000,
                'images' => ['https://images.unsplash.com/photo-1511285560929-80b456fea0bc?w=600&auto=format&fit=crop'],
                'is_active' => true,
            ]
        );
        RentalProfile::updateOrCreate(
            ['product_id' => $rentalKursi->id],
            [
                'total_units' => 10, // 10 paket (500 kursi)
                'deposit_amount' => 250000,
                'min_rental_days' => 1,
                'buffer_hours' => 4,
                'unit_type' => 'paket (50 kursi)',
            ]
        );

        // 9. Sample Completed Order with Review
        $order = Order::firstOrCreate(
            ['order_number' => 'MUAMAR-20261020-0001'],
            [
                'user_id' => $customer1->id,
                'total_amount' => 450000,
                'total_deposit' => 0,
                'status' => 'completed',
                'payment_status' => 'paid',
                'payment_method' => 'qris',
                'shipping_address_snapshot' => [
                    'name' => 'Siti Rahmawati',
                    'phone' => '081234567891',
                    'address' => 'Jl. Tebet Barat No. 8',
                    'city' => 'Jakarta Selatan',
                    'postal_code' => '12810',
                ],
                'notes' => 'Tolong datang tepat pukul 06.00 WIB untuk wisuda UI.',
                'paid_at' => Carbon::now('UTC')->subDays(9),
            ]
        );

        $vendorOrder = VendorOrder::firstOrCreate(
            ['vendor_order_number' => 'VO-20261020-0001-GLW'],
            [
                'order_id' => $order->id,
                'provider_id' => $provider1->id,
                'subtotal' => 450000,
                'deposit_subtotal' => 0,
                'shipping_cost' => 0,
                'total_amount' => 450000,
                'status' => 'completed',
                'payment_status' => 'paid',
            ]
        );

        $orderItem = OrderItem::firstOrCreate(
            ['vendor_order_id' => $vendorOrder->id, 'product_id' => $svcWisuda->id],
            [
                'item_type' => 'service',
                'name_snapshot' => $svcWisuda->name,
                'price_snapshot' => 450000,
                'deposit_snapshot' => 0,
                'quantity' => 1,
                'subtotal' => 450000,
                'metadata' => [
                    'booking_start' => Carbon::now('UTC')->subDays(8)->setTime(1, 0)->toIso8601String(), // 08:00 WIB
                    'booking_end' => Carbon::now('UTC')->subDays(8)->setTime(2, 30)->toIso8601String(),   // 09:30 WIB
                ],
            ]
        );

        // Service Booking record
        ServiceBooking::firstOrCreate(
            ['order_item_id' => $orderItem->id],
            [
                'vendor_order_id' => $vendorOrder->id,
                'provider_id' => $provider1->id,
                'customer_id' => $customer1->id,
                'product_id' => $svcWisuda->id,
                'start_time' => Carbon::now('UTC')->subDays(8)->setTime(1, 0),
                'end_time' => Carbon::now('UTC')->subDays(8)->setTime(2, 30),
                'buffer_end_time' => Carbon::now('UTC')->subDays(8)->setTime(3, 0),
                'status' => 'completed',
                'notes' => 'Wisuda Universitas Indonesia',
            ]
        );

        // Payment record
        $payment = Payment::firstOrCreate(
            ['order_id' => $order->id],
            [
                'payment_method' => 'qris',
                'provider_reference' => 'QRIS-DEMO-202610200001',
                'qris_payload' => '00020101021226680016ID.CO.QRIS.WWW01189360050300000898320215MUA_MOCK_MERCH51440014ID.LINKAJA.WWW02159360050300000895204581453033605802ID5914GLOW BY TASYA6015JAKARTA SELATAN61051273062240120MUAMAR-20261020-00016304D1A8',
                'amount' => 450000,
                'status' => 'paid',
                'paid_at' => Carbon::now('UTC')->subDays(9),
            ]
        );

        PaymentAuditLog::firstOrCreate(
            ['payment_id' => $payment->id, 'event_type' => 'webhook_settlement_processed'],
            [
                'order_id' => $order->id,
                'payload' => ['gross_amount' => 450000, 'status' => 'settlement'],
                'ip_address' => '127.0.0.1',
            ]
        );

        // Verified Review
        Review::firstOrCreate(
            ['order_item_id' => $orderItem->id],
            [
                'user_id' => $customer1->id,
                'provider_id' => $provider1->id,
                'product_id' => $svcWisuda->id,
                'rating' => 5,
                'comment' => 'Bagus sekali! Makeup wisuda tahan dari jam 6 pagi sampai sore tidak crack dan tidak berminyak. Kakaknya juga ramah banget.',
                'provider_reply' => 'Terima kasih banyak Kak Siti atas kepercayaannya! Selamat atas kelulusannya ya kak ✨',
                'is_visible' => true,
            ]
        );

        // 10. Sample Conversation & Chat Messages
        $conv = Conversation::firstOrCreate(
            [
                'customer_id' => $customer2->id,
                'provider_id' => $provider1->id,
                'product_id' => $svcWedding->id,
            ],
            [
                'last_message_at' => Carbon::now('UTC')->subHours(2),
            ]
        );

        Message::firstOrCreate(
            ['conversation_id' => $conv->id, 'message' => 'Halo Kak Tasya, mau tanya untuk paket wedding luxury apakah bisa untuk acara di luar Jakarta (misal Bogor)?'],
            ['sender_id' => $customer2->id, 'is_read' => true, 'created_at' => Carbon::now('UTC')->subHours(3)]
        );

        Message::firstOrCreate(
            ['conversation_id' => $conv->id, 'message' => 'Halo Kak Anisa! Bisa banget ya kak, untuk area Bogor nanti hanya ada penyesuaian biaya transport kurir/artist saja. Rencana tanggal berapa kak?'],
            ['sender_id' => $providerUser1->id, 'is_read' => false, 'created_at' => Carbon::now('UTC')->subHours(2)]
        );
    }
}
