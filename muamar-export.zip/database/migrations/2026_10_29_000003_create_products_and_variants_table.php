<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('products', function (Blueprint $table) {
            $table->id();
            $table->foreignId('provider_id')->constrained('providers')->cascadeOnDelete();
            $table->foreignId('category_id')->constrained('categories')->restrictOnDelete();
            $table->string('name');
            $table->string('slug')->unique();
            $table->text('description')->nullable();
            $table->enum('type', ['physical', 'service', 'rental'])->index();
            $table->unsignedBigInteger('base_price')->default(0)->index(); // in IDR
            $table->json('images')->nullable();
            $table->boolean('is_active')->default(true)->index();
            $table->timestamps();
        });

        Schema::create('product_variants', function (Blueprint $table) {
            $table->id();
            $table->foreignId('product_id')->constrained('products')->cascadeOnDelete();
            $table->string('sku')->unique();
            $table->string('variant_name');
            $table->unsignedBigInteger('price')->default(0); // in IDR
            $table->unsignedInteger('stock')->default(0);
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        Schema::create('service_profiles', function (Blueprint $table) {
            $table->id();
            $table->foreignId('product_id')->unique()->constrained('products')->cascadeOnDelete();
            $table->unsignedInteger('duration_minutes')->default(120);
            $table->unsignedInteger('buffer_minutes')->default(30);
            $table->unsignedInteger('capacity_per_slot')->default(1);
            $table->string('artist_name')->nullable();
            $table->string('service_area')->nullable();
            $table->timestamps();
        });

        Schema::create('rental_profiles', function (Blueprint $table) {
            $table->id();
            $table->foreignId('product_id')->unique()->constrained('products')->cascadeOnDelete();
            $table->unsignedInteger('total_units')->default(1);
            $table->unsignedBigInteger('deposit_amount')->default(0); // in IDR
            $table->unsignedInteger('min_rental_days')->default(1);
            $table->unsignedInteger('buffer_hours')->default(2);
            $table->string('unit_type')->default('unit'); // unit, set, pcs
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('rental_profiles');
        Schema::dropIfExists('service_profiles');
        Schema::dropIfExists('product_variants');
        Schema::dropIfExists('products');
    }
};
