<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->id();
            $table->string('order_number')->unique();
            $table->foreignId('user_id')->constrained('users')->restrictOnDelete();
            $table->unsignedBigInteger('total_amount')->default(0); // in IDR
            $table->unsignedBigInteger('total_deposit')->default(0); // in IDR
            $table->enum('status', ['pending_payment', 'processing', 'completed', 'cancelled'])->default('pending_payment')->index();
            $table->enum('payment_status', ['unpaid', 'paid', 'refunded'])->default('unpaid')->index();
            $table->enum('payment_method', ['qris', 'cod'])->default('qris')->index();
            $table->json('shipping_address_snapshot');
            $table->text('notes')->nullable();
            $table->timestamp('paid_at')->nullable();
            $table->timestamp('cancelled_at')->nullable();
            $table->timestamps();
        });

        Schema::create('vendor_orders', function (Blueprint $table) {
            $table->id();
            $table->string('vendor_order_number')->unique();
            $table->foreignId('order_id')->constrained('orders')->cascadeOnDelete();
            $table->foreignId('provider_id')->constrained('providers')->restrictOnDelete();
            $table->unsignedBigInteger('subtotal')->default(0); // in IDR
            $table->unsignedBigInteger('deposit_subtotal')->default(0); // in IDR
            $table->unsignedBigInteger('shipping_cost')->default(0); // in IDR
            $table->unsignedBigInteger('total_amount')->default(0); // in IDR
            $table->enum('status', [
                'pending_payment',
                'processing',
                'ready_for_shipment',
                'shipped',
                'delivered',
                'completed',
                'cancelled'
            ])->default('pending_payment')->index();
            $table->enum('payment_status', ['unpaid', 'paid', 'refunded'])->default('unpaid')->index();
            $table->string('shipping_carrier')->nullable();
            $table->string('tracking_number')->nullable();
            $table->timestamp('shipped_at')->nullable();
            $table->timestamp('delivered_at')->nullable();
            $table->timestamps();
        });

        Schema::create('order_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('vendor_order_id')->constrained('vendor_orders')->cascadeOnDelete();
            $table->foreignId('product_id')->constrained('products')->restrictOnDelete();
            $table->foreignId('product_variant_id')->nullable()->constrained('product_variants')->nullOnDelete();
            $table->enum('item_type', ['physical', 'service', 'rental'])->index();
            $table->string('name_snapshot');
            $table->string('variant_name_snapshot')->nullable();
            $table->unsignedBigInteger('price_snapshot')->default(0);
            $table->unsignedBigInteger('deposit_snapshot')->default(0);
            $table->unsignedInteger('quantity')->default(1);
            $table->unsignedBigInteger('subtotal')->default(0);
            $table->json('metadata')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('order_items');
        Schema::dropIfExists('vendor_orders');
        Schema::dropIfExists('orders');
    }
};
