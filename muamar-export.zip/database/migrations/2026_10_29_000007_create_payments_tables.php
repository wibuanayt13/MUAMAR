<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('payments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('order_id')->constrained('orders')->cascadeOnDelete();
            $table->enum('payment_method', ['qris', 'cod'])->index();
            $table->string('provider_reference')->unique()->nullable();
            $table->text('qris_payload')->nullable();
            $table->text('qris_image_url')->nullable();
            $table->unsignedBigInteger('amount')->default(0); // in IDR
            $table->enum('status', ['pending', 'paid', 'expired', 'failed'])->default('pending')->index();
            $table->string('signature_hash')->nullable();
            $table->dateTime('paid_at')->nullable();
            $table->json('payload_snapshot')->nullable();
            $table->timestamps();
        });

        Schema::create('payment_audit_logs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('payment_id')->nullable()->constrained('payments')->nullOnDelete();
            $table->foreignId('order_id')->nullable()->constrained('orders')->nullOnDelete();
            $table->string('event_type')->index();
            $table->json('payload')->nullable();
            $table->string('ip_address', 45)->nullable();
            $table->timestamp('created_at')->useCurrent();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('payment_audit_logs');
        Schema::dropIfExists('payments');
    }
};
