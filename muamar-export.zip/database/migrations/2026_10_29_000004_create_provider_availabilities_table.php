<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('provider_availabilities', function (Blueprint $table) {
            $table->id();
            $table->foreignId('provider_id')->constrained('providers')->cascadeOnDelete();
            $table->unsignedTinyInteger('day_of_week'); // 0 = Sunday, 1 = Monday, ..., 6 = Saturday
            $table->time('start_time')->default('08:00:00');
            $table->time('end_time')->default('20:00:00');
            $table->boolean('is_available')->default(true);
            $table->timestamps();

            $table->unique(['provider_id', 'day_of_week']);
        });

        Schema::create('provider_schedule_overrides', function (Blueprint $table) {
            $table->id();
            $table->foreignId('provider_id')->constrained('providers')->cascadeOnDelete();
            $table->date('override_date');
            $table->boolean('is_off')->default(true);
            $table->string('reason')->nullable();
            $table->timestamps();

            $table->unique(['provider_id', 'override_date']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('provider_schedule_overrides');
        Schema::dropIfExists('provider_availabilities');
    }
};
