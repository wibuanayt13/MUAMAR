<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('service_bookings', function (Blueprint $table) {
            $table->id();
            $table->foreignId('vendor_order_id')->nullable()->constrained('vendor_orders')->nullOnDelete();
            $table->foreignId('order_item_id')->nullable()->constrained('order_items')->nullOnDelete();
            $table->foreignId('provider_id')->constrained('providers')->cascadeOnDelete();
            $table->foreignId('customer_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('product_id')->constrained('products')->cascadeOnDelete();
            $table->dateTime('start_time')->index(); // In UTC
            $table->dateTime('end_time')->index();   // In UTC
            $table->dateTime('buffer_end_time')->index(); // In UTC
            $table->enum('status', ['hold', 'confirmed', 'in_progress', 'completed', 'cancelled', 'expired'])->default('hold')->index();
            $table->dateTime('hold_expires_at')->nullable()->index(); // In UTC (10 mins hold)
            $table->text('notes')->nullable();
            $table->timestamps();

            // High-performance index for anti-conflict range queries
            $table->index(['provider_id', 'status', 'start_time', 'buffer_end_time'], 'idx_service_overlap');
        });

        Schema::create('rental_bookings', function (Blueprint $table) {
            $table->id();
            $table->foreignId('vendor_order_id')->nullable()->constrained('vendor_orders')->nullOnDelete();
            $table->foreignId('order_item_id')->nullable()->constrained('order_items')->nullOnDelete();
            $table->foreignId('provider_id')->constrained('providers')->cascadeOnDelete();
            $table->foreignId('customer_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('product_id')->constrained('products')->cascadeOnDelete();
            $table->dateTime('start_date')->index(); // In UTC
            $table->dateTime('end_date')->index();   // In UTC
            $table->dateTime('buffer_end_date')->index(); // In UTC
            $table->unsignedInteger('quantity_rented')->default(1);
            $table->unsignedBigInteger('deposit_amount')->default(0); // in IDR
            $table->enum('status', ['hold', 'confirmed', 'picked_up', 'returned', 'cancelled', 'expired'])->default('hold')->index();
            $table->dateTime('hold_expires_at')->nullable()->index(); // In UTC
            $table->dateTime('returned_at')->nullable();
            $table->dateTime('deposit_returned_at')->nullable();
            $table->timestamps();

            // High-performance index for capacity overlap calculations
            $table->index(['product_id', 'status', 'start_date', 'buffer_end_date'], 'idx_rental_overlap');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('rental_bookings');
        Schema::dropIfExists('service_bookings');
    }
};
