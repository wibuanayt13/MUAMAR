@extends('layouts.app')

@section('content')
<div class="max-w-4xl mx-auto py-10 px-4 sm:px-6 lg:px-8">
    <!-- Invoice Card -->
    <div class="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden p-6 sm:p-10">
        <!-- Invoice Header -->
        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between border-b pb-6 mb-6 gap-4">
            <div>
                <span class="text-xs font-bold uppercase tracking-wider text-brand-600">FAKTUR PESANAN RESMI</span>
                <h1 class="text-2xl font-black text-slate-900 mt-1">{{ $order->order_number }}</h1>
                <p class="text-xs text-slate-500 mt-0.5">Diterbitkan pada {{ $order->created_at->format('d F Y, H:i') }} WIB</p>
            </div>

            <div class="text-right flex flex-col items-start sm:items-end">
                <span class="px-3 py-1 rounded-full text-xs font-bold uppercase
                    @if($order->payment_status === 'paid') bg-emerald-100 text-emerald-800
                    @elseif($order->payment_status === 'refunded') bg-rose-100 text-rose-800
                    @else bg-amber-100 text-amber-800 @endif">
                    Status: {{ $order->payment_status === 'paid' ? 'LUNAS (PAID)' : 'MENUNGGU PEMBAYARAN' }}
                </span>
                <span class="text-xs text-slate-500 mt-1 uppercase font-semibold">Metode: {{ $order->payment_method }}</span>
            </div>
        </div>

        <!-- QRIS Payment Box (If Pending and QRIS) -->
        @if($order->payment_method === 'qris' && $order->payment_status !== 'paid')
            <div class="bg-gradient-to-br from-pink-50 to-rose-50 border border-pink-200 rounded-2xl p-6 mb-8 text-center">
                <h2 class="text-base font-bold text-slate-900 mb-1">Pindai QRIS untuk Melakukan Pembayaran</h2>
                <p class="text-xs text-slate-600 mb-4">Gunakan aplikasi perbankan (BCA, Mandiri, BRI, BNI) atau dompet digital (GoPay, OVO, ShopeePay, DANA).</p>

                <div class="inline-block bg-white p-4 rounded-2xl shadow-sm border border-pink-100 mb-3">
                    <img src="{{ $payment->qris_image_url ?? 'https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=MUAMAR' }}"
                         alt="QRIS Dinamis MUAMAR" class="w-56 h-56 mx-auto">
                </div>

                <div class="max-w-xs mx-auto text-xs text-slate-600 space-y-1 mb-4">
                    <p>Total Nominal: <strong class="text-slate-900 text-sm">Rp {{ number_format($order->total_amount, 0, ',', '.') }}</strong></p>
                    <p class="text-[11px] text-slate-400">Kode Transaksi: {{ $payment->provider_reference ?? 'QRIS-DEMO' }}</p>
                </div>

                <!-- Sandbox Simulation Box -->
                <div class="mt-4 pt-4 border-t border-pink-200/60 max-w-md mx-auto text-xs bg-white/70 p-3 rounded-xl">
                    <p class="font-semibold text-slate-800 mb-1">Pengujian Sandbox Webhook (Reviewer):</p>
                    <p class="text-slate-500 text-[11px] mb-2">Simulasikan pengiriman webhook resmi payment gateway untuk memverifikasi settlement instan & idempotensi:</p>
                    <form action="{{ route('api.payment.webhook') }}" method="POST" target="_blank" class="inline">
                        @csrf
                        <input type="hidden" name="order_number" value="{{ $order->order_number }}">
                        <input type="hidden" name="status_code" value="200">
                        <input type="hidden" name="gross_amount" value="{{ $order->total_amount }}">
                        <input type="hidden" name="transaction_status" value="settlement">
                        @php
                            $serverKey = env('PAYMENT_GATEWAY_WEBHOOK_SECRET', 'muamar_secret_webhook_signature_key');
                            $sig = hash('sha256', $order->order_number . '200' . $order->total_amount . $serverKey);
                        @endphp
                        <input type="hidden" name="signature_key" value="{{ $sig }}">
                        <button type="submit" class="px-4 py-1.5 bg-brand-600 hover:bg-brand-700 text-white rounded font-semibold text-xs transition">
                            Simulasikan Webhook Settlement Lunas
                        </button>
                    </form>
                </div>
            </div>
        @elseif($order->payment_method === 'cod')
            <div class="bg-amber-50 border border-amber-200 rounded-2xl p-4 mb-6 text-xs text-amber-900">
                <i class="fa-solid fa-handshake mr-1.5 text-amber-600"></i>
                <strong>Metode Bayar di Tempat (COD):</strong> Siapkan uang tunai pas sebesar <strong>Rp {{ number_format($order->total_amount, 0, ',', '.') }}</strong> saat perias atau kurir tiba di lokasi.
            </div>
        @endif

        <!-- Customer & Delivery Snapshot -->
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-6 bg-slate-50 p-5 rounded-2xl mb-8 text-xs">
            <div>
                <span class="font-bold text-slate-400 uppercase tracking-wider block mb-1">Informasi Pemesan</span>
                <p class="font-bold text-slate-900 text-sm">{{ $order->shipping_address_snapshot['name'] ?? $order->user->name }}</p>
                <p class="text-slate-600 mt-0.5">WhatsApp: {{ $order->shipping_address_snapshot['phone'] ?? $order->user->phone }}</p>
                <p class="text-slate-600">Email: {{ $order->user->email }}</p>
            </div>
            <div>
                <span class="font-bold text-slate-400 uppercase tracking-wider block mb-1">Alamat Acara / Pengiriman</span>
                <p class="text-slate-800">{{ $order->shipping_address_snapshot['address'] ?? '-' }}</p>
                <p class="text-slate-600 mt-0.5">{{ $order->shipping_address_snapshot['city'] ?? '-' }}, {{ $order->shipping_address_snapshot['postal_code'] ?? '' }}</p>
                @if($order->notes)
                    <p class="text-brand-700 mt-1 italic">Catatan: "{{ $order->notes }}"</p>
                @endif
            </div>
        </div>

        <!-- Vendor Orders Breakdown -->
        <div class="space-y-6 mb-8">
            <h2 class="text-base font-bold text-slate-900 border-b pb-2">Rincian Item Per Vendor</h2>

            @foreach($order->vendorOrders as $vo)
                <div class="border rounded-2xl p-4 bg-white text-xs">
                    <div class="flex items-center justify-between border-b pb-3 mb-3">
                        <div class="font-bold text-slate-800 text-sm">
                            <i class="fa-solid fa-store text-brand-500 mr-1"></i> {{ $vo->provider->business_name }}
                            <span class="text-slate-400 text-xs font-normal">({{ $vo->vendor_order_number }})</span>
                        </div>
                        <span class="px-2.5 py-0.5 rounded text-[10px] font-bold uppercase
                            @if($vo->status === 'completed') bg-emerald-100 text-emerald-800
                            @elseif($vo->status === 'shipped') bg-indigo-100 text-indigo-800
                            @else bg-slate-100 text-slate-800 @endif">
                            Status: {{ $vo->status }}
                        </span>
                    </div>

                    <!-- Items Table -->
                    <table class="w-full text-left">
                        <thead>
                            <tr class="text-slate-400 border-b pb-2">
                                <th class="py-1">Item / Layanan</th>
                                <th class="py-1 text-center">Qty</th>
                                <th class="py-1 text-right">Harga Satuan</th>
                                <th class="py-1 text-right">Subtotal</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100">
                            @foreach($vo->items as $item)
                                <tr>
                                    <td class="py-2.5">
                                        <span class="font-semibold text-slate-900 block">{{ $item->name_snapshot }}</span>
                                        @if($item->variant_name_snapshot)
                                            <span class="text-slate-500 block">Varian: {{ $item->variant_name_snapshot }}</span>
                                        @endif
                                        @if(isset($item->metadata['booking_start']))
                                            <span class="text-brand-600 block">
                                                Jadwal: {{ \Carbon\Carbon::parse($item->metadata['booking_start'])->format('d M Y, H:i') }}
                                            </span>
                                        @endif

                                        {{-- Rating & Review Section if completed --}}
                                        @if($vo->status === 'completed' || $order->status === 'completed')
                                            <div class="mt-2 pt-2 border-t border-slate-100">
                                                @if($item->review)
                                                    <div class="bg-amber-50/70 p-2 rounded-lg border border-amber-200">
                                                        <div class="flex items-center space-x-1 text-amber-500 text-[10px]">
                                                            @for($i = 1; $i <= 5; $i++)
                                                                <i class="fa-solid fa-star {{ $i <= $item->review->rating ? 'text-amber-400' : 'text-slate-200' }}"></i>
                                                            @endfor
                                                            <span class="font-bold text-slate-700 ml-1">Ulasan Anda</span>
                                                        </div>
                                                        <p class="text-[11px] text-slate-600 italic mt-0.5">"{{ $item->review->comment }}"</p>
                                                        @if($item->review->provider_reply)
                                                            <div class="mt-1 text-[10px] text-brand-700 border-l-2 border-brand-500 pl-1.5">
                                                                Tanggapan Toko: {{ $item->review->provider_reply }}
                                                            </div>
                                                        @endif
                                                    </div>
                                                @elseif(auth()->id() === $order->user_id)
                                                    <details class="group bg-slate-50 p-2 rounded-lg border border-slate-200">
                                                        <summary class="cursor-pointer text-[11px] font-bold text-brand-600 flex items-center space-x-1">
                                                            <i class="fa-solid fa-star text-amber-400"></i>
                                                            <span>Beri Ulasan Produk / Jasa Ini</span>
                                                        </summary>
                                                        <form action="{{ route('reviews.store') }}" method="POST" class="mt-2 space-y-2">
                                                            @csrf
                                                            <input type="hidden" name="order_item_id" value="{{ $item->id }}">
                                                            <div class="flex items-center space-x-2">
                                                                <label class="text-[10px] text-slate-500 font-bold">Rating:</label>
                                                                <select name="rating" class="text-xs border rounded px-1.5 py-0.5">
                                                                    <option value="5">⭐⭐⭐⭐⭐ (5 - Sangat Puas)</option>
                                                                    <option value="4">⭐⭐⭐⭐ (4 - Puas)</option>
                                                                    <option value="3">⭐⭐⭐ (3 - Cukup)</option>
                                                                    <option value="2">⭐⭐ (2 - Kurang)</option>
                                                                    <option value="1">⭐ (1 - Buruk)</option>
                                                                </select>
                                                            </div>
                                                            <textarea name="comment" required rows="2" placeholder="Ceritakan pengalaman Anda memakai jasa / produk ini..."
                                                                      class="w-full text-xs p-1.5 border rounded focus:ring-1 focus:ring-brand-500"></textarea>
                                                            <button type="submit" class="px-2.5 py-1 bg-brand-600 hover:bg-brand-700 text-white rounded text-[11px] font-semibold">
                                                                Kirim Ulasan
                                                            </button>
                                                        </form>
                                                    </details>
                                                @endif
                                            </div>
                                        @endif
                                    </td>
                                    <td class="py-2.5 text-center">{{ $item->quantity }}</td>
                                    <td class="py-2.5 text-right">Rp {{ number_format($item->price_snapshot, 0, ',', '.') }}</td>
                                    <td class="py-2.5 text-right font-bold text-slate-800">Rp {{ number_format($item->subtotal, 0, ',', '.') }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>

                    @if($vo->tracking_number)
                        <div class="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between bg-slate-50 p-2.5 rounded-lg text-slate-700">
                            <span>Ekspedisi: <strong>{{ $vo->shipping_carrier }}</strong></span>
                            <span>Nomor Resi: <strong>{{ $vo->tracking_number }}</strong></span>
                        </div>
                    @endif

                    <!-- Shipping History Timeline -->
                    @if($vo->shippingHistories->isNotEmpty())
                        <div class="mt-3 pt-3 border-t border-slate-100">
                            <span class="font-bold text-slate-600 text-[11px] block mb-2">Riwayat & Status Pelacakan Pengiriman:</span>
                            <div class="space-y-2 border-l-2 border-slate-200 ml-2 pl-3">
                                @foreach($vo->shippingHistories->sortByDesc('created_at') as $sh)
                                    <div class="relative text-[11px]">
                                        <div class="absolute -left-[17px] top-1 w-2 h-2 rounded-full bg-brand-500"></div>
                                        <div class="flex items-center space-x-2">
                                            <span class="font-semibold uppercase text-slate-800">{{ str_replace('_', ' ', $sh->status) }}</span>
                                            <span class="text-slate-400 text-[10px]">{{ $sh->created_at->format('d M Y, H:i') }} WIB</span>
                                        </div>
                                        @if($sh->notes)
                                            <p class="text-slate-600 mt-0.5">{{ $sh->notes }}</p>
                                        @endif
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    @endif
                </div>
            @endforeach
        </div>

        <!-- Total Bill -->
        <div class="border-t pt-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div class="text-xs text-slate-400">
                <p>Terima kasih telah mempercayakan acara spesial Anda kepada ekosistem MUAMAR.</p>
            </div>
            <div class="text-right">
                <span class="text-xs text-slate-500 block">Total Pembayaran Akhir</span>
                <span class="text-2xl font-black text-brand-600">Rp {{ number_format($order->total_amount, 0, ',', '.') }}</span>
            </div>
        </div>

        <!-- Print Action -->
        <div class="mt-8 pt-4 border-t border-slate-100 flex justify-end space-x-3">
            <a href="{{ route('order.print', $order->order_number) }}" target="_blank" class="px-4 py-2 border border-slate-300 hover:bg-slate-50 rounded-xl text-xs font-semibold text-slate-700 transition flex items-center space-x-1.5">
                <i class="fa-solid fa-file-pdf text-rose-500"></i>
                <span>Format Cetak / PDF</span>
            </a>
            <button onclick="window.print()" class="px-4 py-2 border border-slate-300 hover:bg-slate-50 rounded-xl text-xs font-semibold text-slate-700 transition">
                <i class="fa-solid fa-print mr-1.5"></i> Cetak Langsung
            </button>
            <a href="{{ route('customer.dashboard') }}" class="px-4 py-2 bg-brand-600 hover:bg-brand-700 text-white rounded-xl text-xs font-semibold transition">
                Ke Dashboard Saya
            </a>
        </div>
    </div>
</div>
@endsection
