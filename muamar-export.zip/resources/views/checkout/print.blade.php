<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice - {{ $order->order_number }} - MUAMAR</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @media print {
            body { background: white !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            .no-print { display: none !important; }
            .page-break { page-break-after: always; }
        }
    </style>
</head>
<body class="bg-slate-100 text-slate-800 font-sans p-4 sm:p-8">
    <div class="max-w-3xl mx-auto mb-4 no-print flex justify-between items-center">
        <a href="{{ route('order.invoice', $order->order_number) }}" class="text-sm font-semibold text-slate-600 hover:text-slate-900">
            &larr; Kembali ke Tampilan Web
        </a>
        <button onclick="window.print()" class="px-5 py-2 bg-pink-600 hover:bg-pink-700 text-white font-bold text-xs rounded-lg shadow transition">
            Cetak / Simpan PDF
        </button>
    </div>

    <div class="max-w-3xl mx-auto bg-white p-8 sm:p-12 rounded-xl shadow-sm border border-slate-200">
        <!-- Brand & Invoice Header -->
        <div class="flex justify-between items-start border-b border-slate-200 pb-6 mb-6">
            <div>
                <h1 class="text-2xl font-black text-pink-600 tracking-wider">MUAMAR</h1>
                <p class="text-xs text-slate-500 mt-0.5">Marketplace Make-Up Artist & Perlengkapan Acara</p>
                <p class="text-xs text-slate-400">support@muamar.test &bull; https://muamar.id</p>
            </div>
            <div class="text-right">
                <span class="text-xs uppercase font-extrabold tracking-wider text-slate-400 block">FAKTUR PESANAN</span>
                <span class="text-lg font-black text-slate-900 block mt-0.5">{{ $order->order_number }}</span>
                <span class="text-xs text-slate-500 block">Tanggal: {{ $order->created_at->format('d/m/Y H:i') }} WIB</span>
                <span class="inline-block mt-2 px-2.5 py-0.5 text-[10px] font-bold rounded uppercase
                    @if($order->payment_status === 'paid') bg-emerald-100 text-emerald-800
                    @elseif($order->payment_status === 'refunded') bg-rose-100 text-rose-800
                    @else bg-amber-100 text-amber-800 @endif">
                    {{ $order->payment_status === 'paid' ? 'LUNAS (PAID)' : 'MENUNGGU PEMBAYARAN' }}
                </span>
            </div>
        </div>

        <!-- Customer & Delivery Snapshot -->
        <div class="grid grid-cols-2 gap-6 bg-slate-50 p-4 rounded-lg mb-6 text-xs">
            <div>
                <span class="font-bold text-slate-400 uppercase tracking-wider block mb-1">Diterbitkan Untuk:</span>
                <p class="font-bold text-slate-900 text-sm">{{ $order->shipping_address_snapshot['name'] ?? $order->user->name }}</p>
                <p class="text-slate-600 mt-0.5">WhatsApp: {{ $order->shipping_address_snapshot['phone'] ?? $order->user->phone }}</p>
                <p class="text-slate-600">Email: {{ $order->user->email }}</p>
            </div>
            <div>
                <span class="font-bold text-slate-400 uppercase tracking-wider block mb-1">Lokasi Acara / Pengiriman:</span>
                <p class="text-slate-800 font-medium">{{ $order->shipping_address_snapshot['address'] ?? '-' }}</p>
                <p class="text-slate-600 mt-0.5">{{ $order->shipping_address_snapshot['city'] ?? '-' }} {{ $order->shipping_address_snapshot['postal_code'] ?? '' }}</p>
                <p class="text-slate-500 mt-1">Metode Bayar: <strong class="uppercase text-slate-800">{{ $order->payment_method }}</strong></p>
            </div>
        </div>

        <!-- Items Per Vendor -->
        <div class="space-y-6 mb-6">
            @foreach($order->vendorOrders as $vo)
                <div class="border border-slate-200 rounded-lg p-4">
                    <div class="flex justify-between items-center border-b border-slate-100 pb-2 mb-3 text-xs">
                        <span class="font-bold text-slate-800">
                            Vendor: {{ $vo->provider->business_name }} ({{ $vo->provider->city }})
                        </span>
                        <span class="text-slate-500 text-[11px]">Sub-Order: {{ $vo->vendor_order_number }}</span>
                    </div>

                    <table class="w-full text-left text-xs">
                        <thead>
                            <tr class="text-slate-400 border-b border-slate-100">
                                <th class="py-1">Deskripsi Item</th>
                                <th class="py-1 text-center">Kuantitas</th>
                                <th class="py-1 text-right">Harga Satuan</th>
                                <th class="py-1 text-right">Subtotal</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100">
                            @foreach($vo->items as $item)
                                <tr>
                                    <td class="py-2">
                                        <span class="font-semibold text-slate-800 block">{{ $item->name_snapshot }}</span>
                                        @if($item->variant_name_snapshot)
                                            <span class="text-[11px] text-slate-500 block">Varian: {{ $item->variant_name_snapshot }}</span>
                                        @endif
                                        @if(isset($item->metadata['booking_start']))
                                            <span class="text-[11px] text-pink-600 block">
                                                Jadwal: {{ \Carbon\Carbon::parse($item->metadata['booking_start'])->format('d M Y, H:i') }}
                                            </span>
                                        @endif
                                    </td>
                                    <td class="py-2 text-center">{{ $item->quantity }}</td>
                                    <td class="py-2 text-right">Rp {{ number_format($item->price_snapshot, 0, ',', '.') }}</td>
                                    <td class="py-2 text-right font-bold text-slate-900">Rp {{ number_format($item->subtotal, 0, ',', '.') }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>

                    @if($vo->deposit_subtotal > 0)
                        <div class="flex justify-between text-xs text-indigo-700 mt-2 pt-2 border-t border-slate-100">
                            <span>Uang Jaminan / Deposit Peralatan:</span>
                            <span class="font-bold">Rp {{ number_format($vo->deposit_subtotal, 0, ',', '.') }}</span>
                        </div>
                    @endif
                </div>
            @endforeach
        </div>

        <!-- Bill Summary -->
        <div class="border-t border-slate-200 pt-4 flex justify-between items-start text-xs">
            <div class="max-w-xs text-slate-400 text-[11px] leading-relaxed">
                <p>Dokumen ini adalah bukti transaksi digital resmi dari platform MUAMAR.</p>
                @if($order->notes)
                    <p class="mt-1 text-slate-600"><strong>Catatan Konsumen:</strong> "{{ $order->notes }}"</p>
                @endif
            </div>
            <div class="w-64 space-y-1 text-right">
                <div class="flex justify-between text-slate-600">
                    <span>Subtotal Barang/Jasa:</span>
                    <span class="font-semibold text-slate-800">Rp {{ number_format($order->total_amount - $order->total_deposit, 0, ',', '.') }}</span>
                </div>
                @if($order->total_deposit > 0)
                    <div class="flex justify-between text-indigo-700">
                        <span>Total Deposit Jaminan:</span>
                        <span class="font-semibold">Rp {{ number_format($order->total_deposit, 0, ',', '.') }}</span>
                    </div>
                @endif
                <div class="flex justify-between text-base font-black text-slate-900 pt-2 border-t border-slate-200">
                    <span>Total Tagihan:</span>
                    <span class="text-pink-600">Rp {{ number_format($order->total_amount, 0, ',', '.') }}</span>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
