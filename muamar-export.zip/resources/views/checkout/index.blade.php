@extends('layouts.app')

@section('content')
<div class="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
    <div class="mb-6">
        <h1 class="text-2xl font-black text-slate-900">Checkout & Pembayaran Pesanan</h1>
        <p class="text-xs text-slate-500 mt-1">Lengkapi informasi penerima / lokasi acara dan tentukan metode pembayaran.</p>
    </div>

    <form action="{{ route('checkout.process') }}" method="POST">
        @csrf
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <!-- Left: Delivery Address & Payment Method -->
            <div class="lg:col-span-2 space-y-6">
                <!-- Recipient & Address -->
                <div class="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
                    <h2 class="text-base font-bold text-slate-900 border-b pb-3 mb-4 flex items-center space-x-2">
                        <i class="fa-solid fa-location-dot text-brand-500"></i>
                        <span>1. Alamat Pengiriman / Lokasi Janji Temu Rias</span>
                    </h2>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label for="recipient_name" class="block text-xs font-semibold text-slate-700 mb-1">Nama Penerima / Pemesan <span class="text-rose-500">*</span></label>
                            <input type="text" id="recipient_name" name="recipient_name" required
                                   value="{{ old('recipient_name', $user->name) }}"
                                   class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none">
                            @error('recipient_name') <p class="text-xs text-rose-500 mt-1">{{ $message }}</p> @enderror
                        </div>

                        <div>
                            <label for="recipient_phone" class="block text-xs font-semibold text-slate-700 mb-1">Nomor WhatsApp Aktif <span class="text-rose-500">*</span></label>
                            <input type="text" id="recipient_phone" name="recipient_phone" required
                                   value="{{ old('recipient_phone', $user->phone) }}"
                                   class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none">
                            @error('recipient_phone') <p class="text-xs text-rose-500 mt-1">{{ $message }}</p> @enderror
                        </div>

                        <div class="sm:col-span-2">
                            <label for="shipping_address" class="block text-xs font-semibold text-slate-700 mb-1">Alamat Lengkap Rumah / Gedung Acara <span class="text-rose-500">*</span></label>
                            <textarea id="shipping_address" name="shipping_address" rows="3" required
                                      placeholder="Nama jalan, nomor rumah/gedung, patokan lokasi..."
                                      class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none">{{ old('shipping_address') }}</textarea>
                            @error('shipping_address') <p class="text-xs text-rose-500 mt-1">{{ $message }}</p> @enderror
                        </div>

                        <div>
                            <label for="city" class="block text-xs font-semibold text-slate-700 mb-1">Kota / Kabupaten <span class="text-rose-500">*</span></label>
                            <input type="text" id="city" name="city" required value="{{ old('city') }}" placeholder="Contoh: Jakarta Selatan"
                                   class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none">
                            @error('city') <p class="text-xs text-rose-500 mt-1">{{ $message }}</p> @enderror
                        </div>

                        <div>
                            <label for="postal_code" class="block text-xs font-semibold text-slate-700 mb-1">Kode Pos</label>
                            <input type="text" id="postal_code" name="postal_code" value="{{ old('postal_code') }}" placeholder="12810"
                                   class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none">
                        </div>

                        <div class="sm:col-span-2">
                            <label for="notes" class="block text-xs font-semibold text-slate-700 mb-1">Catatan Tambahan untuk MUA / Vendor</label>
                            <input type="text" id="notes" name="notes" value="{{ old('notes') }}" placeholder="Contoh: Tolong datang jam 5 pagi, tema rias hijab modern..."
                                   class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none">
                        </div>
                    </div>
                </div>

                <!-- Payment Method Selection -->
                <div class="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
                    <h2 class="text-base font-bold text-slate-900 border-b pb-3 mb-4 flex items-center space-x-2">
                        <i class="fa-solid fa-credit-card text-brand-500"></i>
                        <span>2. Metode Pembayaran</span>
                    </h2>

                    <div class="space-y-3">
                        <label class="cursor-pointer border rounded-2xl p-4 flex items-start space-x-3 hover:border-brand-500 transition has-[:checked]:border-brand-600 has-[:checked]:bg-brand-50/50">
                            <input type="radio" name="payment_method" value="qris" class="mt-1" checked>
                            <div class="flex-grow">
                                <div class="flex items-center space-x-2">
                                    <span class="font-bold text-slate-900 text-sm">QRIS Dinamis (Instan & Otomatis)</span>
                                    <span class="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 text-[10px] font-bold">Rekomendasi</span>
                                </div>
                                <p class="text-xs text-slate-500 mt-1">
                                    Dapat dibayar menggunakan BCA Mobile, Livin by Mandiri, GoPay, OVO, ShopeePay, DANA, LinkAja. Status pesanan langsung otomatis terverifikasi via webhook gateway resmi.
                                </p>
                            </div>
                        </label>

                        <label class="cursor-pointer border rounded-2xl p-4 flex items-start space-x-3 hover:border-brand-500 transition has-[:checked]:border-brand-600 has-[:checked]:bg-brand-50/50">
                            <input type="radio" name="payment_method" value="cod" class="mt-1" {{ old('payment_method') === 'cod' ? 'checked' : '' }}>
                            <div class="flex-grow">
                                <span class="font-bold text-slate-900 text-sm">Bayar di Tempat (COD / Tunai)</span>
                                <p class="text-xs text-slate-500 mt-1">
                                    Bayar langsung secara tunai saat perias/kurir tiba di lokasi. Catatan: Pesanan COD tidak dianggap lunas hingga dikonfirmasi secara eksplisit oleh vendor/kurir.
                                </p>
                            </div>
                        </label>
                    </div>
                </div>
            </div>

            <!-- Right: Order Summary -->
            <div class="lg:col-span-1">
                <div class="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm sticky top-20">
                    <h2 class="text-base font-bold text-slate-900 border-b pb-3 mb-4">Ringkasan Pesanan</h2>

                    <div class="space-y-3 max-h-72 overflow-y-auto pr-1 text-xs">
                        @foreach($itemsByProvider as $provId => $items)
                            <div class="border-b pb-2">
                                <p class="font-bold text-slate-800">{{ $items->first()->product->provider->business_name }}</p>
                                @foreach($items as $i)
                                    <div class="flex justify-between text-slate-600 mt-1">
                                        <span>{{ $i->quantity }}x {{ Str::limit($i->product->name, 22) }}</span>
                                        <span>Rp {{ number_format(($i->variant ? $i->variant->price : $i->product->base_price) * $i->quantity, 0, ',', '.') }}</span>
                                    </div>
                                @endforeach
                            </div>
                        @endforeach
                    </div>

                    <div class="border-t pt-4 mt-4 space-y-2 text-xs">
                        <div class="flex justify-between text-slate-600">
                            <span>Subtotal Item</span>
                            <span class="font-semibold text-slate-800">Rp {{ number_format($totalAmount - $totalDeposit, 0, ',', '.') }}</span>
                        </div>
                        @if($totalDeposit > 0)
                            <div class="flex justify-between text-indigo-600">
                                <span>Total Uang Jaminan Sewa</span>
                                <span class="font-semibold">Rp {{ number_format($totalDeposit, 0, ',', '.') }}</span>
                            </div>
                        @endif
                        <div class="flex justify-between text-sm font-black text-slate-900 pt-2 border-t">
                            <span>Total Tagihan</span>
                            <span class="text-brand-600">Rp {{ number_format($totalAmount, 0, ',', '.') }}</span>
                        </div>
                    </div>

                    <button type="submit" class="mt-6 w-full py-3 bg-brand-600 hover:bg-brand-700 text-white font-bold text-sm rounded-xl transition shadow flex items-center justify-center space-x-2">
                        <i class="fa-solid fa-lock"></i>
                        <span>Proses Pesanan Sekarang</span>
                    </button>
                    <p class="text-[10px] text-slate-400 text-center mt-2">
                        Transaksi aman terlindungi sistem garansi & scheduler anti-bentrok MUAMAR.
                    </p>
                </div>
            </div>
        </div>
    </form>
</div>
@endsection
