<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ config('app.name', 'MUAMAR') }} - Marketplace Make-Up Artist & Sewa Event</title>

    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        brand: {
                            50: '#fdf2f8',
                            100: '#fce7f3',
                            500: '#ec4899',
                            600: '#db2777',
                            700: '#be185d',
                            800: '#9d174d',
                            900: '#831843',
                        }
                    }
                }
            }
        }
    </script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        [x-cloak] { display: none !important; }
    </style>
</head>
<body class="bg-slate-50 text-slate-800 flex flex-col min-h-screen">
    <!-- Top Bar -->
    <header class="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16">
                <!-- Logo & Brand -->
                <div class="flex items-center space-x-6">
                    <a href="{{ route('home') }}" class="flex items-center space-x-2 text-brand-600 font-extrabold text-2xl tracking-wider">
                        <i class="fa-solid fa-wand-magic-sparkles text-brand-500"></i>
                        <span>MUAMAR</span>
                    </a>
                    <nav class="hidden md:flex space-x-4 text-sm font-medium text-slate-600">
                        <a href="{{ route('home') }}" class="hover:text-brand-600 transition">Beranda</a>
                        <a href="{{ route('catalog.index') }}" class="hover:text-brand-600 transition">Katalog Lengkap</a>
                        <a href="{{ route('catalog.index', ['type' => 'service']) }}" class="hover:text-brand-600 transition">Jasa MUA</a>
                        <a href="{{ route('catalog.index', ['type' => 'physical']) }}" class="hover:text-brand-600 transition">Produk Makeup</a>
                        <a href="{{ route('catalog.index', ['type' => 'rental']) }}" class="hover:text-brand-600 transition">Sewa Tenda & Event</a>
                        <a href="{{ route('providers.map') }}" class="hover:text-brand-600 transition flex items-center space-x-1">
                            <i class="fa-solid fa-map-location-dot text-brand-500"></i>
                            <span>Peta MUA</span>
                        </a>
                    </nav>
                </div>

                <!-- Right Actions -->
                <div class="flex items-center space-x-3">
                    @auth
                        <!-- Cart Link -->
                        <a href="{{ route('cart.index') }}" class="relative p-2 text-slate-600 hover:text-brand-600 transition">
                            <i class="fa-solid fa-bag-shopping text-xl"></i>
                            @php
                                $cartCount = \App\Models\CartItem::where('user_id', auth()->id())->count();
                            @endphp
                            @if($cartCount > 0)
                                <span class="absolute top-0 right-0 inline-flex items-center justify-center px-2 py-0.5 text-xs font-bold leading-none text-white bg-brand-600 rounded-full">
                                    {{ $cartCount }}
                                </span>
                            @endif
                        </a>

                        <!-- Chat Link -->
                        <a href="{{ route('chat.index') }}" class="relative p-2 text-slate-600 hover:text-brand-600 transition" title="Pesan & Konsultasi">
                            <i class="fa-solid fa-comments text-xl"></i>
                            @php
                                $unreadChatCount = \App\Models\Message::whereHas('conversation', function ($q) {
                                    $q->where('customer_id', auth()->id())
                                      ->orWhereHas('provider', fn($p) => $p->where('user_id', auth()->id()));
                                })->where('sender_id', '!=', auth()->id())->where('is_read', false)->count();
                            @endphp
                            @if($unreadChatCount > 0)
                                <span class="absolute top-0 right-0 inline-flex items-center justify-center px-1.5 py-0.5 text-[10px] font-bold leading-none text-white bg-rose-600 rounded-full">
                                    {{ $unreadChatCount }}
                                </span>
                            @endif
                        </a>

                        <!-- Notifications Bell -->
                        <a href="{{ route('notifications.index') }}" class="relative p-2 text-slate-600 hover:text-brand-600 transition" title="Pemberitahuan">
                            <i class="fa-solid fa-bell text-xl"></i>
                            @php
                                $unreadNotifCount = auth()->user()->unreadNotifications->count();
                            @endphp
                            @if($unreadNotifCount > 0)
                                <span class="absolute top-0 right-0 inline-flex items-center justify-center px-1.5 py-0.5 text-[10px] font-bold leading-none text-white bg-brand-600 rounded-full">
                                    {{ $unreadNotifCount }}
                                </span>
                            @endif
                        </a>

                        <!-- User Profile Dropdown / Badge -->
                        <div class="relative flex items-center space-x-2">
                            <span class="text-xs px-2.5 py-1 rounded-full font-semibold uppercase tracking-wider
                                @if(auth()->user()->isAdmin()) bg-purple-100 text-purple-800
                                @elseif(auth()->user()->isProvider()) bg-amber-100 text-amber-800
                                @else bg-emerald-100 text-emerald-800 @endif">
                                {{ auth()->user()->role }}
                            </span>
                            <a href="{{ auth()->user()->isAdmin() ? route('admin.dashboard') : (auth()->user()->isProvider() ? route('provider.dashboard') : route('customer.dashboard')) }}" 
                               class="text-sm font-semibold text-slate-800 hover:text-brand-600 hidden sm:inline-block">
                                {{ Str::limit(auth()->user()->name, 16) }}
                            </a>
                            <form action="{{ route('logout') }}" method="POST" class="inline">
                                @csrf
                                <button type="submit" title="Keluar" class="p-2 text-slate-400 hover:text-rose-600 transition">
                                    <i class="fa-solid fa-arrow-right-from-bracket"></i>
                                </button>
                            </form>
                        </div>
                    @else
                        <a href="{{ route('login') }}" class="text-sm font-semibold text-slate-700 hover:text-brand-600 px-3 py-2 transition">
                            Masuk
                        </a>
                        <a href="{{ route('register') }}" class="text-sm font-semibold text-white bg-brand-600 hover:bg-brand-700 px-4 py-2 rounded-lg shadow-sm transition">
                            Daftar
                        </a>
                    @endauth
                </div>
            </div>
        </div>
    </header>

    <!-- Flash Messages -->
    <main class="flex-grow">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-4">
            @if(session('success'))
                <div class="mb-4 bg-emerald-50 border-l-4 border-emerald-500 p-4 rounded-r-md flex items-center justify-between text-emerald-800 text-sm">
                    <div class="flex items-center space-x-2">
                        <i class="fa-solid fa-circle-check text-emerald-500"></i>
                        <span>{{ session('success') }}</span>
                    </div>
                </div>
            @endif

            @if(session('error'))
                <div class="mb-4 bg-rose-50 border-l-4 border-rose-500 p-4 rounded-r-md flex items-center justify-between text-rose-800 text-sm">
                    <div class="flex items-center space-x-2">
                        <i class="fa-solid fa-circle-exclamation text-rose-500"></i>
                        <span>{{ session('error') }}</span>
                    </div>
                </div>
            @endif

            @if(session('info'))
                <div class="mb-4 bg-blue-50 border-l-4 border-blue-500 p-4 rounded-r-md flex items-center justify-between text-blue-800 text-sm">
                    <div class="flex items-center space-x-2">
                        <i class="fa-solid fa-circle-info text-blue-500"></i>
                        <span>{{ session('info') }}</span>
                    </div>
                </div>
            @endif
        </div>

        @yield('content')
    </main>

    <!-- Footer -->
    <footer class="bg-white border-t border-slate-200 mt-12 py-8">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-sm text-slate-500">
            <div class="flex justify-center space-x-6 mb-4">
                <a href="{{ route('catalog.index') }}" class="hover:text-slate-800">Katalog Layanan</a>
                <a href="{{ route('providers.map') }}" class="hover:text-slate-800">Peta Lokasi MUA</a>
                <a href="{{ route('provider.onboard') }}" class="hover:text-slate-800">Daftar Jadi MUA / Vendor</a>
            </div>
            <p>&copy; {{ date('Y') }} MUAMAR - Ekosistem Marketplace Make-Up Artist & Perlengkapan Acara Indonesia. Hak cipta dilindungi.</p>
        </div>
    </footer>

    @stack('scripts')
</body>
</html>
