@extends('layouts.app')

@section('content')
<!-- Hero Section -->
<section class="bg-gradient-to-b from-brand-50 to-white py-12 md:py-20 border-b border-slate-200">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-brand-100 text-brand-700 mb-4">
            <i class="fa-solid fa-sparkles mr-1.5"></i> Marketplace Make-Up Artist & Sewa Event No. 1
        </span>
        <h1 class="text-3xl sm:text-5xl font-black text-slate-900 tracking-tight leading-tight max-w-4xl mx-auto">
            Temukan Make-Up Artist Terbaik, Produk Kosmetik, dan Sewa Perlengkapan Acara
        </h1>
        <p class="mt-4 text-base sm:text-lg text-slate-600 max-w-2xl mx-auto">
            Booking MUA anti-bentrok dengan jadwal terverifikasi, beli produk kosmetik berkualitas, dan sewa tenda hingga panggung pengantin dalam satu platform.
        </p>

        <!-- Search Bar -->
        <div class="mt-8 max-w-3xl mx-auto bg-white p-3 rounded-2xl shadow-lg border border-slate-200">
            <form action="{{ route('catalog.index') }}" method="GET" class="flex flex-col sm:flex-row gap-2">
                <div class="relative flex-grow">
                    <i class="fa-solid fa-magnifying-glass absolute left-3.5 top-3.5 text-slate-400"></i>
                    <input type="text" name="q" placeholder="Cari MUA wisuda, wedding, sewa tenda, foundation..."
                           class="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500">
                </div>

                <select name="type" class="px-4 py-2.5 rounded-xl border border-slate-200 text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-brand-500">
                    <option value="">Semua Kategori</option>
                    <option value="service">Jasa MUA</option>
                    <option value="physical">Produk Kosmetik</option>
                    <option value="rental">Sewa Perlengkapan / Tenda</option>
                </select>

                <button type="submit" class="px-6 py-2.5 bg-brand-600 hover:bg-brand-700 text-white font-semibold text-sm rounded-xl transition shadow">
                    Cari Sekarang
                </button>
            </form>
        </div>
    </div>
</section>

<!-- Categories Bar -->
<section class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
    <h2 class="text-xl font-bold text-slate-900 mb-6 flex items-center justify-between">
        <span>Kategori Utama</span>
        <a href="{{ route('catalog.index') }}" class="text-xs font-semibold text-brand-600 hover:underline">Lihat Semua &rarr;</a>
    </h2>

    <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4">
        @foreach($categories as $cat)
            <a href="{{ route('catalog.index', ['category' => $cat->slug]) }}"
               class="bg-white p-4 rounded-xl border border-slate-200 hover:border-brand-500 hover:shadow-md transition text-center group">
                <div class="w-12 h-12 mx-auto rounded-full bg-brand-50 text-brand-600 flex items-center justify-center text-xl group-hover:scale-110 transition">
                    @if($cat->type === 'service')
                        <i class="fa-solid fa-wand-magic-sparkles"></i>
                    @elseif($cat->type === 'rental')
                        <i class="fa-solid fa-campground"></i>
                    @else
                        <i class="fa-solid fa-heart"></i>
                    @endif
                </div>
                <h3 class="text-xs font-bold text-slate-800 mt-2">{{ $cat->name }}</h3>
                <span class="text-[10px] text-slate-400 capitalize">{{ $cat->type }}</span>
            </a>
        @endforeach
    </div>
</section>

<!-- Featured Services (Jasa MUA) -->
<section class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
    <div class="flex items-center justify-between mb-6">
        <div>
            <h2 class="text-xl font-bold text-slate-900">Jasa Make-Up Artist Unggulan</h2>
            <p class="text-xs text-slate-500">Booking jadwal MUA profesional secara instan dengan scheduler anti-bentrok.</p>
        </div>
        <a href="{{ route('catalog.index', ['type' => 'service']) }}" class="text-xs font-semibold text-brand-600 hover:underline">Lihat Semua Jasa &rarr;</a>
    </div>

    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        @foreach($featuredServices as $prod)
            <div class="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm hover:shadow-md transition flex flex-col">
                <img src="{{ is_array($prod->images) ? $prod->images[0] : 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=600' }}"
                     alt="{{ $prod->name }}" class="h-48 w-full object-cover">
                <div class="p-4 flex flex-col flex-grow">
                    <span class="text-[10px] font-bold uppercase tracking-wider text-brand-600 bg-brand-50 px-2 py-0.5 rounded w-max">
                        {{ $prod->category->name }}
                    </span>
                    <h3 class="font-bold text-slate-900 mt-2 text-sm line-clamp-2">
                        <a href="{{ route('catalog.show', $prod->slug) }}" class="hover:text-brand-600">{{ $prod->name }}</a>
                    </h3>
                    <p class="text-xs text-slate-500 mt-1 flex items-center">
                        <i class="fa-solid fa-store text-slate-400 mr-1"></i> {{ $prod->provider->business_name }} ({{ $prod->provider->city }})
                    </p>
                    <div class="mt-auto pt-3 border-t border-slate-100 flex items-center justify-between">
                        <div>
                            <span class="text-[10px] text-slate-400 block">Mulai dari</span>
                            <span class="font-bold text-brand-600 text-sm">Rp {{ number_format($prod->base_price, 0, ',', '.') }}</span>
                        </div>
                        <a href="{{ route('catalog.show', $prod->slug) }}" class="px-3 py-1.5 bg-brand-600 hover:bg-brand-700 text-white text-xs font-semibold rounded-lg transition">
                            Pilih Jadwal
                        </a>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
</section>

<!-- Featured Rentals (Sewa Tenda & Event) -->
<section class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
    <div class="flex items-center justify-between mb-6">
        <div>
            <h2 class="text-xl font-bold text-slate-900">Sewa Tenda & Perlengkapan Acara</h2>
            <p class="text-xs text-slate-500">Tenda dekorasi, kursi futura, panggung, dan perlengkapan pernikahan lengkap.</p>
        </div>
        <a href="{{ route('catalog.index', ['type' => 'rental']) }}" class="text-xs font-semibold text-brand-600 hover:underline">Lihat Semua Rental &rarr;</a>
    </div>

    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        @foreach($featuredRentals as $prod)
            <div class="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm hover:shadow-md transition flex flex-col">
                <img src="{{ is_array($prod->images) ? $prod->images[0] : 'https://images.unsplash.com/photo-1519167758481-83f550bb49b3?w=600' }}"
                     alt="{{ $prod->name }}" class="h-48 w-full object-cover">
                <div class="p-4 flex flex-col flex-grow">
                    <span class="text-[10px] font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded w-max">
                        Sewa / Rental
                    </span>
                    <h3 class="font-bold text-slate-900 mt-2 text-sm line-clamp-2">
                        <a href="{{ route('catalog.show', $prod->slug) }}" class="hover:text-brand-600">{{ $prod->name }}</a>
                    </h3>
                    <p class="text-xs text-slate-500 mt-1">
                        Tersedia {{ $prod->rentalProfile->total_units ?? 1 }} {{ $prod->rentalProfile->unit_type ?? 'unit' }}
                    </p>
                    <div class="mt-auto pt-3 border-t border-slate-100 flex items-center justify-between">
                        <div>
                            <span class="text-[10px] text-slate-400 block">Sewa per hari</span>
                            <span class="font-bold text-indigo-600 text-sm">Rp {{ number_format($prod->base_price, 0, ',', '.') }}</span>
                        </div>
                        <a href="{{ route('catalog.show', $prod->slug) }}" class="px-3 py-1.5 bg-slate-800 hover:bg-slate-900 text-white text-xs font-semibold rounded-lg transition">
                            Cek Tanggal
                        </a>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
</section>

<!-- Verified Providers Map Banner -->
<section class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 mb-12">
    <div class="bg-gradient-to-r from-slate-900 to-brand-900 rounded-3xl p-8 text-white flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
            <span class="text-xs font-semibold uppercase tracking-wider text-pink-300">Peta Jangkauan Interaktif</span>
            <h2 class="text-2xl font-bold mt-1">Cari MUA Terdekat dari Lokasi Acara Anda</h2>
            <p class="text-slate-300 text-sm mt-2 max-w-xl">
                Gunakan fitur peta publik MUAMAR untuk mengecek jarak studio MUA, coverage area, serta estimasi waktu kedatangan perias.
            </p>
        </div>
        <a href="{{ route('providers.map') }}" class="px-6 py-3 bg-white text-brand-700 font-bold text-sm rounded-xl hover:bg-slate-100 transition whitespace-nowrap shadow">
            <i class="fa-solid fa-map-location-dot mr-2"></i> Buka Peta Studio MUA
        </a>
    </div>
</section>
@endsection
