@extends('layouts.app')

@section('content')
<div class="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
    <!-- Header Greeting -->
    <div class="bg-white rounded-2xl p-6 mb-8 border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
            <div class="flex items-center space-x-3">
                <div class="w-12 h-12 bg-pink-100 text-brand-600 rounded-full flex items-center justify-center font-bold text-xl">
                    {{ strtoupper(substr($user->name, 0, 1)) }}
                </div>
                <div>
                    <h1 class="text-xl font-bold text-slate-900">Halo, {{ $user->name }}</h1>
                    <p class="text-sm text-slate-500">{{ $user->email }} &bull; {{ $user->phone ?? 'Nomor HP belum diisi' }}</p>
                </div>
            </div>
        </div>

        <div class="flex items-center space-x-3">
            @if(!$user->isProvider())
                <a href="{{ route('provider.onboard') }}" class="px-4 py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white font-medium text-sm rounded-lg shadow-sm transition flex items-center space-x-2">
                    <i class="fa-solid fa-store"></i>
                    <span>Buka Studio / Jadi MUA</span>
                </a>
            @else
                <a href="{{ route('provider.dashboard') }}" class="px-4 py-2 bg-brand-600 hover:bg-brand-700 text-white font-medium text-sm rounded-lg shadow-sm transition flex items-center space-x-2">
                    <i class="fa-solid fa-briefcase"></i>
                    <span>Dashboard Provider MUA</span>
                </a>
            @endif
        </div>
    </div>

    <!-- Quick Stats -->
    <div class="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-8">
        <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
            <span class="text-xs font-semibold uppercase tracking-wider text-slate-400">Total Transaksi Selesai</span>
            <p class="text-2xl font-black text-slate-900 mt-2">Rp {{ number_format($totalSpent, 0, ',', '.') }}</p>
        </div>
        <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
            <span class="text-xs font-semibold uppercase tracking-wider text-slate-400">Pesanan Aktif</span>
            <p class="text-2xl font-black text-slate-900 mt-2">{{ $orders->total() }}</p>
        </div>
        <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
            <span class="text-xs font-semibold uppercase tracking-wider text-slate-400">Jadwal Janji Temu MUA</span>
            <p class="text-2xl font-black text-slate-900 mt-2">{{ $serviceBookings->count() }}</p>
        </div>
    </div>

    <!-- Content Tabs / Sections -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Main: Riwayat Pesanan -->
        <div class="lg:col-span-2 space-y-6">
            <div class="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
                <div class="flex items-center justify-between border-b pb-4 mb-4">
                    <h2 class="text-lg font-bold text-slate-900 flex items-center space-x-2">
                        <i class="fa-solid fa-receipt text-brand-500"></i>
                        <span>Riwayat Pesanan Saya</span>
                    </h2>
                    <a href="{{ route('catalog.index') }}" class="text-xs font-semibold text-brand-600 hover:underline">
                        Mulai Belanja &rarr;
                    </a>
                </div>

                @forelse($orders as $order)
                    <div class="border rounded-xl p-4 mb-4 hover:border-slate-300 transition">
                        <div class="flex flex-wrap items-center justify-between gap-2 border-b pb-3 mb-3 text-xs">
                            <div>
                                <span class="font-bold text-slate-800">{{ $order->order_number }}</span>
                                <span class="text-slate-400 ml-2">{{ $order->created_at->format('d M Y, H:i') }}</span>
                            </div>
                            <div class="flex items-center space-x-2">
                                <span class="px-2.5 py-0.5 rounded-full font-semibold uppercase
                                    @if($order->status === 'completed') bg-emerald-100 text-emerald-800
                                    @elseif($order->status === 'cancelled') bg-rose-100 text-rose-800
                                    @else bg-amber-100 text-amber-800 @endif">
                                    {{ $order->status }}
                                </span>
                                <span class="px-2.5 py-0.5 rounded-full font-semibold uppercase
                                    @if($order->payment_status === 'paid') bg-blue-100 text-blue-800
                                    @else bg-slate-100 text-slate-800 @endif">
                                    {{ $order->payment_method }}: {{ $order->payment_status }}
                                </span>
                            </div>
                        </div>

                        <!-- Sub vendor orders list -->
                        @foreach($order->vendorOrders as $vo)
                            <div class="bg-slate-50 rounded-lg p-3 mb-2 text-xs">
                                <div class="font-semibold text-slate-700 flex items-center justify-between">
                                    <span>Vendor: {{ $vo->provider->business_name }}</span>
                                    <span>Status: <strong class="uppercase">{{ $vo->status }}</strong></span>
                                </div>
                                <ul class="mt-2 space-y-1">
                                    @foreach($vo->items as $item)
                                        <li class="flex justify-between text-slate-600">
                                            <span>{{ $item->quantity }}x {{ $item->name_snapshot }}</span>
                                            <span>Rp {{ number_format($item->subtotal, 0, ',', '.') }}</span>
                                        </li>
                                    @endforeach
                                </ul>
                                @if($vo->tracking_number)
                                    <div class="mt-2 pt-2 border-t border-slate-200 text-slate-700 flex items-center justify-between">
                                        <span>Kurir/Resi: <strong>{{ $vo->shipping_carrier }} - {{ $vo->tracking_number }}</strong></span>
                                    </div>
                                @endif
                            </div>
                        @endforeach

                        <div class="flex items-center justify-between mt-3 text-sm">
                            <span class="text-slate-500">Total Tagihan:</span>
                            <span class="font-bold text-slate-900 text-base">Rp {{ number_format($order->total_amount, 0, ',', '.') }}</span>
                        </div>
                    </div>
                @empty
                    <div class="text-center py-8 text-slate-400">
                        <i class="fa-solid fa-bag-shopping text-4xl mb-2"></i>
                        <p>Belum ada riwayat pesanan.</p>
                    </div>
                @endforelse

                <div class="mt-4">
                    {{ $orders->links() }}
                </div>
            </div>
        </div>

        <!-- Sidebar: Janji Temu MUA & Sewa Aktif -->
        <div class="space-y-6">
            <div class="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
                <h3 class="text-base font-bold text-slate-900 border-b pb-3 mb-4 flex items-center space-x-2">
                    <i class="fa-solid fa-calendar-check text-brand-500"></i>
                    <span>Jadwal Booking MUA</span>
                </h3>

                @forelse($serviceBookings as $b)
                    <div class="border rounded-xl p-3 mb-3 text-xs bg-slate-50">
                        <p class="font-bold text-slate-800">{{ $b->product->name }}</p>
                        <p class="text-slate-500 mt-1">Provider: {{ $b->provider->business_name }}</p>
                        <p class="text-brand-600 font-semibold mt-1">
                            <i class="fa-regular fa-clock"></i>
                            {{ $b->start_time->format('d M Y, H:i') }} - {{ $b->end_time->format('H:i') }} WIB
                        </p>
                        <span class="inline-block mt-2 px-2 py-0.5 rounded text-[10px] font-bold uppercase
                            @if($b->status === 'confirmed') bg-emerald-100 text-emerald-800
                            @elseif($b->status === 'hold') bg-amber-100 text-amber-800
                            @else bg-slate-200 text-slate-800 @endif">
                            {{ $b->status }}
                        </span>
                    </div>
                @empty
                    <p class="text-xs text-slate-400 text-center py-4">Tidak ada janji temu rias aktif.</p>
                @endforelse
            </div>

            <div class="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
                <h3 class="text-base font-bold text-slate-900 border-b pb-3 mb-4 flex items-center space-x-2">
                    <i class="fa-solid fa-campground text-brand-500"></i>
                    <span>Jadwal Sewa Tenda / Event</span>
                </h3>

                @forelse($rentalBookings as $rb)
                    <div class="border rounded-xl p-3 mb-3 text-xs bg-slate-50">
                        <p class="font-bold text-slate-800">{{ $rb->product->name }} ({{ $rb->quantity_rented }} Unit)</p>
                        <p class="text-slate-500 mt-1">Vendor: {{ $rb->provider->business_name }}</p>
                        <p class="text-indigo-600 font-semibold mt-1">
                            {{ $rb->start_date->format('d M Y') }} s/d {{ $rb->end_date->format('d M Y') }}
                        </p>
                        <span class="inline-block mt-2 px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-blue-100 text-blue-800">
                            {{ $rb->status }}
                        </span>
                    </div>
                @empty
                    <p class="text-xs text-slate-400 text-center py-4">Tidak ada sewa perlengkapan aktif.</p>
                @endforelse
            </div>
        </div>
    </div>
</div>
@endsection
