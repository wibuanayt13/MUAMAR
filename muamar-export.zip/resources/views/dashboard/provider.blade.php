@extends('layouts.app')

@section('content')
<div class="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
    <!-- Header Studio -->
    <div class="bg-white rounded-2xl p-6 mb-8 border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
            <div class="flex items-center space-x-3">
                <div class="w-14 h-14 bg-brand-50 text-brand-600 rounded-2xl flex items-center justify-center font-bold text-2xl border border-brand-100">
                    <i class="fa-solid fa-wand-magic-sparkles"></i>
                </div>
                <div>
                    <div class="flex items-center space-x-2">
                        <h1 class="text-xl font-bold text-slate-900">{{ $provider->business_name }}</h1>
                        @if($provider->is_verified)
                            <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-emerald-100 text-emerald-800" title="Studio Terverifikasi Resmi">
                                <i class="fa-solid fa-circle-check mr-1"></i> Terverifikasi
                            </span>
                        @else
                            <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-amber-100 text-amber-800" title="Menunggu review admin">
                                Menunggu Verifikasi
                            </span>
                        @endif
                    </div>
                    <p class="text-xs text-slate-500 mt-1">
                        <i class="fa-solid fa-location-dot text-slate-400 mr-1"></i> {{ $provider->address }}, {{ $provider->city }} &bull; WA: {{ $provider->phone }}
                    </p>
                </div>
            </div>
        </div>

        <div class="flex flex-wrap items-center gap-3 text-xs">
            <span class="px-3 py-1.5 rounded-lg border {{ $provider->qris_active ? 'border-emerald-200 bg-emerald-50 text-emerald-800' : 'border-slate-200 bg-slate-50 text-slate-500' }}">
                <i class="fa-solid fa-qrcode mr-1"></i> QRIS {{ $provider->qris_active ? 'Aktif' : 'Nonaktif' }}
            </span>
            <span class="px-3 py-1.5 rounded-lg border {{ $provider->cod_active ? 'border-blue-200 bg-blue-50 text-blue-800' : 'border-slate-200 bg-slate-50 text-slate-500' }}">
                <i class="fa-solid fa-handshake mr-1"></i> COD {{ $provider->cod_active ? 'Aktif' : 'Nonaktif' }}
            </span>
            <a href="{{ route('provider.products.create') }}" class="px-3.5 py-1.5 bg-brand-600 hover:bg-brand-700 text-white font-semibold rounded-lg shadow-sm transition flex items-center space-x-1.5">
                <i class="fa-solid fa-plus text-xs"></i>
                <span>Upload Produk / Jasa</span>
            </a>
        </div>
    </div>

    <!-- Metrics Cards -->
    <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
        <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
            <span class="text-xs font-semibold uppercase tracking-wider text-slate-400">Total Pendapatan</span>
            <p class="text-xl font-black text-slate-900 mt-1">Rp {{ number_format($totalRevenue, 0, ',', '.') }}</p>
        </div>
        <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
            <span class="text-xs font-semibold uppercase tracking-wider text-slate-400">Layanan Jasa MUA</span>
            <p class="text-xl font-black text-slate-900 mt-1">{{ $activeServicesCount }} Paket</p>
        </div>
        <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
            <span class="text-xs font-semibold uppercase tracking-wider text-slate-400">Aset Sewa / Tenda</span>
            <p class="text-xl font-black text-slate-900 mt-1">{{ $activeRentalsCount }} Item</p>
        </div>
        <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
            <span class="text-xs font-semibold uppercase tracking-wider text-slate-400">Katalog Produk Fisik</span>
            <p class="text-xl font-black text-slate-900 mt-1">{{ $activeProductsCount }} Produk</p>
        </div>
    </div>

    <!-- Management Columns -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Order Vendor List -->
        <div class="lg:col-span-2 space-y-6">
            <div class="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
                <div class="flex items-center justify-between border-b pb-4 mb-4">
                    <h2 class="text-lg font-bold text-slate-900 flex items-center space-x-2">
                        <i class="fa-solid fa-boxes-packing text-brand-500"></i>
                        <span>Pesanan Masuk ke Studio Saya</span>
                    </h2>
                </div>

                @forelse($vendorOrders as $vo)
                    <div class="border rounded-xl p-4 mb-4 hover:border-slate-300 transition text-sm">
                        <div class="flex flex-wrap items-center justify-between gap-2 border-b pb-3 mb-3">
                            <div>
                                <span class="font-bold text-slate-900">{{ $vo->vendor_order_number }}</span>
                                <span class="text-xs text-slate-500 ml-2">Pemesan: {{ $vo->order->user->name }} ({{ $vo->order->user->phone }})</span>
                            </div>
                            <div class="flex items-center space-x-2">
                                <span class="px-2.5 py-0.5 rounded-full text-xs font-semibold uppercase
                                    @if($vo->status === 'completed') bg-emerald-100 text-emerald-800
                                    @elseif($vo->status === 'shipped') bg-indigo-100 text-indigo-800
                                    @elseif($vo->status === 'cancelled') bg-rose-100 text-rose-800
                                    @else bg-amber-100 text-amber-800 @endif">
                                    {{ $vo->status }}
                                </span>
                                <span class="px-2 py-0.5 rounded text-xs font-semibold uppercase bg-slate-100 text-slate-700">
                                    {{ $vo->order->payment_method }}: {{ $vo->payment_status }}
                                </span>
                            </div>
                        </div>

                        <!-- Item details -->
                        <div class="space-y-2 mb-3">
                            @foreach($vo->items as $item)
                                <div class="flex justify-between items-center text-xs text-slate-700">
                                    <span>
                                        <strong>{{ $item->quantity }}x</strong> {{ $item->name_snapshot }}
                                        @if($item->variant_name_snapshot) <span class="text-slate-500">({{ $item->variant_name_snapshot }})</span> @endif
                                        <span class="ml-1 text-[10px] px-1.5 py-0.5 rounded bg-slate-100 uppercase">{{ $item->item_type }}</span>
                                    </span>
                                    <span class="font-semibold">Rp {{ number_format($item->subtotal, 0, ',', '.') }}</span>
                                </div>
                            @endforeach
                        </div>

                        <!-- Manual Fulfillment / Resi Form -->
                        @if($vo->status !== 'completed' && $vo->status !== 'cancelled')
                            <div class="bg-slate-50 p-3 rounded-lg border border-slate-200 mt-3 text-xs">
                                <p class="font-semibold text-slate-800 mb-2">Update Resi Pengiriman Fisik:</p>
                                <form action="{{ route('provider.orders.ship', $vo->id) }}" method="POST" class="flex flex-wrap items-center gap-2">
                                    @csrf
                                    @method('PATCH')
                                    <input type="text" name="shipping_carrier" placeholder="Ekspedisi / Kurir Lokal (JNE/SiCepat/Kurir Studio)" required
                                           value="{{ $vo->shipping_carrier }}"
                                           class="px-3 py-1.5 rounded border border-slate-300 text-xs flex-grow">
                                    <input type="text" name="tracking_number" placeholder="Nomor Resi / Surat Jalan" required
                                           value="{{ $vo->tracking_number }}"
                                           class="px-3 py-1.5 rounded border border-slate-300 text-xs flex-grow">
                                    <button type="submit" class="px-3 py-1.5 bg-slate-800 hover:bg-slate-900 text-white rounded font-medium transition">
                                        Simpan Resi & Kirim
                                    </button>
                                </form>

                                <!-- Add Tracking Milestone Update -->
                                <details class="mt-2.5 pt-2 border-t border-slate-200">
                                    <summary class="cursor-pointer text-[11px] text-slate-600 font-semibold hover:text-brand-600">
                                        + Tambah Catatan Milestone Pelacakan Pengiriman
                                    </summary>
                                    <form action="{{ route('provider.orders.tracking-update', $vo->id) }}" method="POST" class="mt-2 flex flex-wrap items-center gap-2">
                                        @csrf
                                        <select name="status" class="px-2 py-1.5 rounded border border-slate-300 text-xs">
                                            <option value="processing">Sedang Diproses Studio</option>
                                            <option value="ready_for_shipment">Siap Dikirim / Diserahkan ke Kurir</option>
                                            <option value="shipped">Dalam Perjalanan Kurir</option>
                                            <option value="delivered">Telah Diterima Pelanggan</option>
                                            <option value="completed">Selesai</option>
                                        </select>
                                        <input type="text" name="notes" placeholder="Catatan posisi paket / info kurir..." required
                                               class="px-3 py-1.5 rounded border border-slate-300 text-xs flex-grow">
                                        <button type="submit" class="px-3 py-1.5 bg-brand-600 hover:bg-brand-700 text-white rounded font-medium transition text-xs">
                                            Kirim Update
                                        </button>
                                    </form>
                                </details>

                                <!-- COD Explicit Confirmation Button -->
                                @if($vo->order->payment_method === 'cod' && $vo->payment_status !== 'paid')
                                    <div class="mt-2 pt-2 border-t border-slate-200 flex items-center justify-between">
                                        <span class="text-amber-700">Pesanan COD belum dikonfirmasi lunas oleh studio.</span>
                                        <form action="{{ route('provider.orders.confirm-cod', $vo->id) }}" method="POST" onsubmit="return confirm('Apakah Anda yakin telah menerima pembayaran tunai dari pelanggan?');">
                                            @csrf
                                            @method('PATCH')
                                            <button type="submit" class="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-xs font-semibold">
                                                Konfirmasi Terima Uang Tunai COD
                                            </button>
                                        </form>
                                    </div>
                                @endif
                            </div>
                        @endif
                    </div>
                @empty
                    <div class="text-center py-8 text-slate-400 text-sm">
                        Belum ada pesanan masuk ke studio Anda.
                    </div>
                @endforelse

                <div class="mt-4">
                    {{ $vendorOrders->links() }}
                </div>
            </div>
        </div>

        <!-- Sidebar: Agenda MUA & Ulasan Konsumen -->
        <div class="space-y-6">
            <div class="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
                <h3 class="text-base font-bold text-slate-900 border-b pb-3 mb-4 flex items-center space-x-2">
                    <i class="fa-solid fa-clock text-brand-500"></i>
                    <span>Jadwal MUA Mendatang</span>
                </h3>

                @forelse($upcomingServiceBookings as $ub)
                    <div class="border rounded-xl p-3 mb-3 text-xs bg-slate-50">
                        <p class="font-bold text-slate-900">{{ $ub->product->name }}</p>
                        <p class="text-slate-600 mt-1">Klien: {{ $ub->customer->name }} ({{ $ub->customer->phone }})</p>
                        <p class="text-brand-600 font-semibold mt-1">
                            {{ $ub->start_time->format('d M Y, H:i') }} - {{ $ub->end_time->format('H:i') }} WIB
                        </p>
                    </div>
                @empty
                    <p class="text-xs text-slate-400 text-center py-4">Belum ada agenda janji temu terdekat.</p>
                @endforelse
            </div>

            <div class="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
                <h3 class="text-base font-bold text-slate-900 border-b pb-3 mb-4 flex items-center space-x-2">
                    <i class="fa-solid fa-star text-amber-500"></i>
                    <span>Ulasan Konsumen Terbaru</span>
                </h3>

                @forelse($reviews as $rev)
                    <div class="border rounded-xl p-3 mb-3 text-xs bg-slate-50">
                        <div class="flex items-center justify-between text-amber-500">
                            <div>
                                @for($i = 1; $i <= 5; $i++)
                                    <i class="fa-solid fa-star text-[10px] {{ $i <= $rev->rating ? 'text-amber-400' : 'text-slate-200' }}"></i>
                                @endfor
                            </div>
                            <span class="text-slate-400 text-[10px]">{{ $rev->created_at->diffForHumans() }}</span>
                        </div>
                        <p class="font-semibold text-slate-800 mt-1">{{ $rev->user->name }} - <span class="font-normal text-slate-500">{{ $rev->product->name }}</span></p>
                        <p class="text-slate-600 italic mt-1">"{{ $rev->comment }}"</p>
                        @if($rev->provider_reply)
                            <div class="mt-2 pl-2 border-l-2 border-brand-500 text-brand-700">
                                Balasan Anda: {{ $rev->provider_reply }}
                            </div>
                        @else
                            <details class="mt-2 pt-2 border-t border-slate-200">
                                <summary class="cursor-pointer text-[10px] text-brand-600 font-semibold hover:underline">
                                    Balas Ulasan Konsumen Ini
                                </summary>
                                <form action="{{ route('reviews.reply', $rev->id) }}" method="POST" class="mt-2 space-y-1.5">
                                    @csrf
                                    <textarea name="provider_reply" required rows="2" placeholder="Tuliskan respon resmi studio Anda..."
                                              class="w-full text-xs p-1.5 border rounded focus:ring-1 focus:ring-brand-500"></textarea>
                                    <button type="submit" class="px-2.5 py-1 bg-brand-600 hover:bg-brand-700 text-white rounded text-[10px] font-semibold">
                                        Kirim Balasan
                                    </button>
                                </form>
                            </details>
                        @endif
                    </div>
                @empty
                    <p class="text-xs text-slate-400 text-center py-4">Belum ada ulasan yang diterima.</p>
                @endforelse
            </div>
        </div>
    </div>
</div>
@endsection
