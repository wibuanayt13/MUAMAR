@extends('layouts.app')

@section('content')
<div class="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
    <!-- Admin Header -->
    <div class="bg-slate-900 text-white rounded-3xl p-6 sm:p-8 mb-8 shadow-sm flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
            <div class="flex items-center space-x-3">
                <div class="w-12 h-12 bg-purple-600 rounded-2xl flex items-center justify-center font-bold text-xl">
                    <i class="fa-solid fa-shield-halved"></i>
                </div>
                <div>
                    <h1 class="text-xl sm:text-2xl font-black">Portal Administrasi & Moderasi MUAMAR</h1>
                    <p class="text-xs text-slate-400 mt-1">Pengawasan transaksi multi-vendor, verifikasi MUA, moderasi katalog/ulasan, dan audit keamanan.</p>
                </div>
            </div>
        </div>
        <div class="flex items-center space-x-2 text-xs">
            <span class="px-3 py-1.5 rounded-xl bg-purple-950/80 border border-purple-500/40 text-purple-300 font-semibold flex items-center space-x-1.5">
                <i class="fa-solid fa-lock text-[10px]"></i>
                <span>Super Administrator</span>
            </span>
        </div>
    </div>

    <!-- Platform Stats / GMV Overview -->
    <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
        <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
            <span class="text-[11px] font-bold uppercase tracking-wider text-slate-400">Total Transaksi GMV</span>
            <p class="text-xl sm:text-2xl font-black text-slate-900 mt-1">Rp {{ number_format($stats['total_gmv'], 0, ',', '.') }}</p>
            <span class="text-[10px] text-emerald-600 font-semibold block mt-1"><i class="fa-solid fa-arrow-trend-up"></i> Pembayaran Lunas</span>
        </div>
        <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
            <span class="text-[11px] font-bold uppercase tracking-wider text-slate-400">Total Provider MUA</span>
            <p class="text-xl sm:text-2xl font-black text-slate-900 mt-1">{{ $stats['total_providers'] }} Studio</p>
            <span class="text-[10px] text-slate-500 block mt-1">Penyedia Jasa & Sewa</span>
        </div>
        <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
            <span class="text-[11px] font-bold uppercase tracking-wider text-slate-400">Verifikasi Tertunda</span>
            <p class="text-xl sm:text-2xl font-black text-amber-600 mt-1">{{ $stats['pending_providers'] }} Provider</p>
            <span class="text-[10px] text-amber-700 font-semibold block mt-1">Butuh Review Admin</span>
        </div>
        <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
            <span class="text-[11px] font-bold uppercase tracking-wider text-slate-400">Pengguna Terdaftar</span>
            <p class="text-xl sm:text-2xl font-black text-slate-900 mt-1">{{ $stats['total_users'] }} User</p>
            <span class="text-[10px] text-slate-500 block mt-1">Customer & Merchant</span>
        </div>
    </div>

    <!-- Main Admin Grid -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        <!-- Moderasi Provider Baru -->
        <div class="bg-white rounded-3xl border border-slate-200 shadow-sm p-6">
            <div class="flex items-center justify-between border-b pb-3 mb-4">
                <h2 class="text-base font-bold text-slate-900 flex items-center space-x-2">
                    <i class="fa-solid fa-user-check text-purple-600"></i>
                    <span>Verifikasi Studio & Status Provider</span>
                </h2>
                <span class="text-xs text-slate-400">Terbaru</span>
            </div>

            <div class="space-y-3">
                @forelse($recentProviders as $prov)
                    <div class="border rounded-2xl p-3 text-xs flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 bg-slate-50">
                        <div>
                            <div class="flex items-center space-x-2">
                                <span class="font-bold text-slate-900 text-sm">{{ $prov->business_name }}</span>
                                @if($prov->is_verified)
                                    <span class="px-2 py-0.5 rounded text-[10px] bg-emerald-100 text-emerald-800 font-bold">Terverifikasi</span>
                                @else
                                    <span class="px-2 py-0.5 rounded text-[10px] bg-amber-100 text-amber-800 font-bold">Menunggu Verifikasi</span>
                                @endif
                                <span class="px-2 py-0.5 rounded text-[10px] uppercase font-bold
                                    {{ $prov->status === 'approved' ? 'bg-blue-100 text-blue-800' : 'bg-rose-100 text-rose-800' }}">
                                    {{ $prov->status }}
                                </span>
                            </div>
                            <p class="text-slate-500 mt-1">{{ $prov->city }} &bull; Kontak: {{ $prov->phone }} &bull; Pemilik: {{ $prov->user->name }}</p>
                        </div>

                        <div class="flex items-center space-x-2 self-end sm:self-center">
                            @if(!$prov->is_verified)
                                <form action="{{ route('admin.providers.verify', $prov->id) }}" method="POST">
                                    @csrf
                                    @method('PATCH')
                                    <button type="submit" class="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-semibold text-xs shadow-sm">
                                        Verifikasi Resmi
                                    </button>
                                </form>
                            @endif

                            <form action="{{ route('admin.providers.toggle-suspension', $prov->id) }}" method="POST">
                                @csrf
                                @method('PATCH')
                                <button type="submit" class="px-3 py-1.5 {{ $prov->status === 'approved' ? 'bg-rose-50 border border-rose-200 text-rose-700 hover:bg-rose-100' : 'bg-blue-600 text-white hover:bg-blue-700' }} rounded-lg font-semibold text-xs">
                                    {{ $prov->status === 'approved' ? 'Tangguhkan' : 'Aktifkan' }}
                                </button>
                            </form>
                        </div>
                    </div>
                @empty
                    <p class="text-slate-400 text-xs text-center py-6">Belum ada studio terdaftar.</p>
                @endforelse
            </div>
        </div>

        <!-- Transaksi Terkini Seluruh Vendor -->
        <div class="bg-white rounded-3xl border border-slate-200 shadow-sm p-6">
            <div class="flex items-center justify-between border-b pb-3 mb-4">
                <h2 class="text-base font-bold text-slate-900 flex items-center space-x-2">
                    <i class="fa-solid fa-receipt text-purple-600"></i>
                    <span>Transaksi Terkini Ekosistem Platform</span>
                </h2>
                <span class="text-xs text-slate-400">Total: {{ $stats['total_orders'] }}</span>
            </div>

            <div class="space-y-3">
                @forelse($recentOrders as $ro)
                    <div class="border rounded-2xl p-3 text-xs flex items-center justify-between bg-slate-50">
                        <div>
                            <span class="font-bold text-slate-900">{{ $ro->order_number }}</span>
                            <span class="text-slate-500 block mt-0.5">Pemesan: {{ $ro->user->name }} &bull; Total: <strong>Rp {{ number_format($ro->total_amount, 0, ',', '.') }}</strong></span>
                            <span class="text-[10px] text-slate-400">{{ $ro->created_at->format('d M Y, H:i') }} WIB</span>
                        </div>
                        <div class="text-right">
                            <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase
                                @if($ro->status === 'completed') bg-emerald-100 text-emerald-800
                                @elseif($ro->status === 'cancelled') bg-rose-100 text-rose-800
                                @else bg-amber-100 text-amber-800 @endif">
                                {{ $ro->status }}
                            </span>
                            <span class="block text-[10px] text-slate-500 font-semibold mt-1 uppercase">{{ $ro->payment_method }} ({{ $ro->payment_status }})</span>
                        </div>
                    </div>
                @empty
                    <p class="text-slate-400 text-xs text-center py-6">Belum ada transaksi.</p>
                @endforelse
            </div>
        </div>
    </div>

    <!-- Moderation: Listings & Reviews -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        <!-- Moderasi Listing / Katalog Produk & Jasa -->
        <div class="bg-white rounded-3xl border border-slate-200 shadow-sm p-6">
            <div class="flex items-center justify-between border-b pb-3 mb-4">
                <h2 class="text-base font-bold text-slate-900 flex items-center space-x-2">
                    <i class="fa-solid fa-wand-magic text-purple-600"></i>
                    <span>Moderasi Listing & Jasa MUA</span>
                </h2>
                <span class="text-xs text-slate-400">{{ $stats['total_products'] }} Total Item</span>
            </div>

            <div class="space-y-3">
                @forelse($recentProducts as $prod)
                    <div class="border rounded-2xl p-3 text-xs flex items-center justify-between bg-slate-50">
                        <div>
                            <div class="flex items-center space-x-2">
                                <span class="font-bold text-slate-900">{{ $prod->name }}</span>
                                <span class="px-1.5 py-0.5 rounded text-[10px] uppercase font-semibold
                                    @if($prod->type === 'service') bg-pink-100 text-pink-700
                                    @elseif($prod->type === 'rental') bg-indigo-100 text-indigo-700
                                    @else bg-emerald-100 text-emerald-700 @endif">
                                    {{ $prod->type }}
                                </span>
                            </div>
                            <p class="text-slate-500 mt-0.5">Vendor: {{ $prod->provider->business_name }} &bull; Rp {{ number_format($prod->base_price, 0, ',', '.') }}</p>
                        </div>

                        <div>
                            <form action="{{ route('admin.products.toggle', $prod->id) }}" method="POST">
                                @csrf
                                @method('PATCH')
                                <button type="submit" class="px-3 py-1 rounded text-xs font-semibold
                                    {{ $prod->is_active ? 'bg-emerald-100 text-emerald-800 hover:bg-rose-100 hover:text-rose-800' : 'bg-rose-100 text-rose-800 hover:bg-emerald-100 hover:text-emerald-800' }}">
                                    {{ $prod->is_active ? 'Aktif (Klik Suspend)' : 'Ditangguhkan (Aktifkan)' }}
                                </button>
                            </form>
                        </div>
                    </div>
                @empty
                    <p class="text-slate-400 text-xs text-center py-6">Belum ada produk/jasa.</p>
                @endforelse
            </div>
        </div>

        <!-- Moderasi Ulasan Konsumen -->
        <div class="bg-white rounded-3xl border border-slate-200 shadow-sm p-6">
            <div class="flex items-center justify-between border-b pb-3 mb-4">
                <h2 class="text-base font-bold text-slate-900 flex items-center space-x-2">
                    <i class="fa-solid fa-star-half-stroke text-amber-500"></i>
                    <span>Moderasi Ulasan & Rating Konsumen</span>
                </h2>
                <span class="text-xs text-slate-400">{{ $stats['total_reviews'] }} Ulasan Masuk</span>
            </div>

            <div class="space-y-3">
                @forelse($recentReviews as $rev)
                    <div class="border rounded-2xl p-3 text-xs bg-slate-50">
                        <div class="flex items-center justify-between">
                            <div class="flex items-center space-x-2">
                                <span class="font-bold text-slate-900">{{ $rev->user->name }}</span>
                                <span class="text-amber-500 font-bold">({{ $rev->rating }} ⭐)</span>
                                <span class="text-slate-400">&bull; {{ $rev->product->name }}</span>
                            </div>
                            <form action="{{ route('admin.reviews.toggle', $rev->id) }}" method="POST">
                                @csrf
                                @method('PATCH')
                                <button type="submit" class="px-2 py-0.5 rounded text-[10px] font-bold uppercase
                                    {{ $rev->is_visible ? 'bg-emerald-100 text-emerald-800 hover:bg-rose-100 hover:text-rose-800' : 'bg-rose-100 text-rose-800 hover:bg-emerald-100 hover:text-emerald-800' }}">
                                    {{ $rev->is_visible ? 'Tampil (Klik Sembunyikan)' : 'Disembunyikan (Klik Tampilkan)' }}
                                </button>
                            </form>
                        </div>
                        <p class="text-slate-600 mt-1 italic">"{{ $rev->comment }}"</p>
                    </div>
                @empty
                    <p class="text-slate-400 text-xs text-center py-6">Belum ada ulasan.</p>
                @endforelse
            </div>
        </div>
    </div>

    <!-- Management: Categories & Audit Trail -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <!-- Manajemen Kategori Bertingkat -->
        <div class="bg-white rounded-3xl border border-slate-200 shadow-sm p-6">
            <div class="flex items-center justify-between border-b pb-3 mb-4">
                <h2 class="text-base font-bold text-slate-900 flex items-center space-x-2">
                    <i class="fa-solid fa-folder-tree text-purple-600"></i>
                    <span>Manajemen Kategori Bertingkat</span>
                </h2>
                <details class="relative">
                    <summary class="cursor-pointer text-xs font-semibold text-purple-700 bg-purple-50 hover:bg-purple-100 px-3 py-1 rounded-lg transition list-none">
                        + Tambah Kategori
                    </summary>
                    <div class="absolute right-0 mt-2 w-72 bg-white rounded-2xl border border-slate-200 shadow-lg p-4 z-20">
                        <form action="{{ route('admin.categories.store') }}" method="POST" class="space-y-3">
                            @csrf
                            <div>
                                <label class="block text-[11px] font-bold text-slate-700 mb-1">Nama Kategori:</label>
                                <input type="text" name="name" required placeholder="Contoh: Rias Adat Sunda"
                                       class="w-full text-xs px-3 py-1.5 rounded-lg border border-slate-300">
                            </div>
                            <div>
                                <label class="block text-[11px] font-bold text-slate-700 mb-1">Kategori Induk (Opsional):</label>
                                <select name="parent_id" class="w-full text-xs px-3 py-1.5 rounded-lg border border-slate-300">
                                    <option value="">-- Kategori Utama --</option>
                                    @foreach($categories->whereNull('parent_id') as $cat)
                                        <option value="{{ $cat->id }}">{{ $cat->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <button type="submit" class="w-full py-1.5 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-xs font-semibold transition">
                                Simpan Kategori
                            </button>
                        </form>
                    </div>
                </details>
            </div>

            <div class="space-y-2 max-h-[400px] overflow-y-auto pr-1">
                @forelse($categories as $c)
                    <div class="border rounded-xl p-2.5 text-xs flex items-center justify-between bg-slate-50">
                        <div>
                            <span class="font-bold text-slate-800">{{ $c->name }}</span>
                            @if($c->parent)
                                <span class="text-slate-400 text-[10px]"> (Sub dari: {{ $c->parent->name }})</span>
                            @endif
                            <span class="text-slate-500 block text-[10px]">{{ $c->products_count }} Listing Produk/Jasa</span>
                        </div>

                        @if($c->products_count === 0)
                            <form action="{{ route('admin.categories.destroy', $c->id) }}" method="POST" onsubmit="return confirm('Hapus kategori ini?');">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="text-rose-500 hover:text-rose-700 p-1 text-xs" title="Hapus Kategori Kosong">
                                    <i class="fa-solid fa-trash"></i>
                                </button>
                            </form>
                        @endif
                    </div>
                @empty
                    <p class="text-slate-400 text-xs text-center py-6">Belum ada kategori terdaftar.</p>
                @endforelse
            </div>
        </div>

        <!-- Audit Trail Keamanan Sistem -->
        <div class="bg-white rounded-3xl border border-slate-200 shadow-sm p-6">
            <div class="flex items-center justify-between border-b pb-3 mb-4">
                <h2 class="text-base font-bold text-slate-900 flex items-center space-x-2">
                    <i class="fa-solid fa-clock-rotate-left text-purple-600"></i>
                    <span>Audit Trail Log Keamanan Platform</span>
                </h2>
                <span class="text-xs text-slate-400">10 Log Terkini</span>
            </div>

            <div class="space-y-2.5 max-h-[400px] overflow-y-auto pr-1">
                @forelse($recentAuditLogs as $log)
                    <div class="border rounded-xl p-2.5 text-[11px] bg-slate-50">
                        <div class="flex items-center justify-between">
                            <span class="font-bold text-purple-700 uppercase">{{ str_replace('_', ' ', $log->action) }}</span>
                            <span class="text-slate-400 text-[10px]">{{ $log->created_at->format('d M, H:i') }} WIB</span>
                        </div>
                        <p class="text-slate-600 mt-0.5">
                            Oleh: <strong class="text-slate-800">{{ $log->user->name ?? 'System/Webhook' }}</strong>
                            &bull; IP: {{ $log->ip_address ?? '127.0.0.1' }}
                            &bull; Entity: {{ class_basename($log->entity_type) }} #{{ $log->entity_id }}
                        </p>
                    </div>
                @empty
                    <p class="text-slate-400 text-xs text-center py-6">Belum ada catatan audit log.</p>
                @endforelse
            </div>
        </div>
    </div>
</div>
@endsection
