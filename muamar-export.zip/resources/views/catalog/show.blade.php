@extends('layouts.app')

@section('content')
<div class="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
    <div class="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm p-6 sm:p-8 mb-8">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
            <!-- Left: Image Gallery -->
            <div>
                <div class="rounded-2xl overflow-hidden border border-slate-100 bg-slate-100 h-80 sm:h-96">
                    <img src="{{ is_array($product->images) ? $product->images[0] : 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=600' }}"
                         alt="{{ $product->name }}" class="w-full h-full object-cover">
                </div>
            </div>

            <!-- Right: Product Information & Purchase/Booking Form -->
            <div class="flex flex-col">
                <div class="flex items-center space-x-2">
                    <span class="text-xs font-bold uppercase tracking-wider px-2.5 py-1 rounded-full
                        @if($product->type === 'service') bg-brand-50 text-brand-700
                        @elseif($product->type === 'rental') bg-indigo-50 text-indigo-700
                        @else bg-emerald-50 text-emerald-700 @endif">
                        {{ $product->type === 'service' ? 'Jasa Make-Up Artist' : ($product->type === 'rental' ? 'Sewa / Rental Event' : 'Produk Fisik') }}
                    </span>
                    <span class="text-xs text-slate-400">&bull; {{ $product->category->name }}</span>
                </div>

                <h1 class="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-2">{{ $product->name }}</h1>

                <!-- Provider Badge -->
                <div class="flex items-center space-x-3 mt-3 py-3 border-y border-slate-100">
                    <div class="w-10 h-10 bg-slate-100 text-brand-600 rounded-full flex items-center justify-center font-bold">
                        <i class="fa-solid fa-store"></i>
                    </div>
                    <div>
                        <p class="text-sm font-bold text-slate-900">{{ $product->provider->business_name }}</p>
                        <p class="text-xs text-slate-500 flex items-center space-x-1">
                            <span><i class="fa-solid fa-location-dot text-slate-400"></i> {{ $product->provider->city }} &bull; WA: {{ $product->provider->phone }}</span>
                            @if($product->provider->is_location_public && $product->provider->latitude)
                                <a href="{{ route('providers.map') }}" class="text-brand-600 font-semibold hover:underline ml-1" title="Lihat posisi studio pada peta">
                                    <i class="fa-solid fa-map-pin text-[10px]"></i> (Lihat Peta)
                                </a>
                            @endif
                        </p>
                    </div>
                    <!-- Chat with seller button -->
                    <form action="{{ route('chat.start') }}" method="POST" class="ml-auto">
                        @csrf
                        <input type="hidden" name="provider_id" value="{{ $product->provider_id }}">
                        <input type="hidden" name="product_id" value="{{ $product->id }}">
                        <button type="submit" class="px-3 py-1.5 border border-brand-500 text-brand-600 hover:bg-brand-50 rounded-lg text-xs font-semibold transition flex items-center space-x-1">
                            <i class="fa-regular fa-comment-dots"></i>
                            <span>Chat Penjual</span>
                        </button>
                    </form>
                </div>

                <!-- Price display -->
                <div class="mt-4">
                    <span class="text-xs text-slate-400 block">{{ $product->type === 'rental' ? 'Tarif sewa per hari' : 'Harga' }}</span>
                    <span class="text-3xl font-black text-brand-600">Rp {{ number_format($product->base_price, 0, ',', '.') }}</span>
                </div>

                <!-- Description -->
                <p class="text-sm text-slate-600 mt-4 leading-relaxed">{{ $product->description }}</p>

                <!-- Specific Action Forms: Booking / Rental / Cart -->
                <div class="mt-6 pt-6 border-t border-slate-100">
                    <form action="{{ route('cart.add') }}" method="POST">
                        @csrf
                        <input type="hidden" name="product_id" value="{{ $product->id }}">

                        <!-- Physical Product Variations -->
                        @if($product->type === 'physical')
                            @if($product->variants->count() > 0)
                                <div class="mb-4">
                                    <label class="block text-xs font-semibold text-slate-700 mb-1">Pilih Variasi / Shade:</label>
                                    <select name="product_variant_id" required class="w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none">
                                        @foreach($product->variants as $var)
                                            <option value="{{ $var->id }}">
                                                {{ $var->variant_name }} - Rp {{ number_format($var->price, 0, ',', '.') }} (Sisa Stok: {{ $var->stock }})
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                            @endif

                            <div class="mb-4">
                                <label class="block text-xs font-semibold text-slate-700 mb-1">Jumlah:</label>
                                <input type="number" name="quantity" value="1" min="1" max="50" class="w-24 px-3 py-2 rounded-lg border border-slate-300 text-sm">
                            </div>

                        <!-- Service Booking Form -->
                        @elseif($product->type === 'service')
                            <div class="bg-brand-50/50 p-4 rounded-xl border border-brand-100 mb-4 text-xs space-y-2">
                                <p class="font-semibold text-brand-900 flex items-center">
                                    <i class="fa-regular fa-clock mr-1.5"></i> Durasi Pengerjaan: {{ $product->serviceProfile->duration_minutes ?? 120 }} menit (Buffer: {{ $product->serviceProfile->buffer_minutes ?? 30 }} menit)
                                </p>
                                <p class="text-slate-600">Artis: <strong>{{ $product->serviceProfile->artist_name ?? 'Senior Makeup Artist' }}</strong></p>
                                <p class="text-slate-500 text-[11px]">*Sistem scheduler MUAMAR akan memverifikasi interval slot secara atomik agar tidak bentrok dengan konsumen lain.</p>
                            </div>

                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
                                <div>
                                    <label class="block text-xs font-semibold text-slate-700 mb-1">Pilih Waktu Mulai Rias (WIB):</label>
                                    <input type="datetime-local" name="booking_start" required
                                           class="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-2 focus:ring-brand-500">
                                </div>
                                <div class="flex items-end">
                                    <span class="text-xs text-slate-500">Waktu selesai dihitung otomatis berdasarkan durasi paket.</span>
                                </div>
                            </div>

                        <!-- Rental Asset Booking Form -->
                        @elseif($product->type === 'rental')
                            <div class="bg-indigo-50/50 p-4 rounded-xl border border-indigo-100 mb-4 text-xs space-y-2">
                                <p class="font-semibold text-indigo-900 flex items-center">
                                    <i class="fa-solid fa-boxes-stacked mr-1.5"></i> Kapasitas Maksimal: {{ $product->rentalProfile->total_units ?? 1 }} {{ $product->rentalProfile->unit_type ?? 'unit' }}
                                </p>
                                <p class="text-slate-600">Uang Jaminan / Deposit: <strong>Rp {{ number_format($product->rentalProfile->deposit_amount ?? 0, 0, ',', '.') }}</strong></p>
                                <p class="text-slate-500 text-[11px]">*Kapasitas dihitung otomatis pada interval sewa agar tidak melebihi stok unit tersedia.</p>
                            </div>

                            <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-4">
                                <div>
                                    <label class="block text-xs font-semibold text-slate-700 mb-1">Mulai Sewa:</label>
                                    <input type="date" name="booking_start" required class="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs">
                                </div>
                                <div>
                                    <label class="block text-xs font-semibold text-slate-700 mb-1">Selesai Sewa:</label>
                                    <input type="date" name="booking_end" required class="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs">
                                </div>
                                <div>
                                    <label class="block text-xs font-semibold text-slate-700 mb-1">Kuantitas Unit:</label>
                                    <input type="number" name="quantity" value="1" min="1" max="{{ $product->rentalProfile->total_units ?? 10 }}" class="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs">
                                </div>
                            </div>
                        @endif

                        <button type="submit" class="w-full py-3 bg-brand-600 hover:bg-brand-700 text-white font-bold rounded-xl shadow transition flex items-center justify-center space-x-2">
                            <i class="fa-solid fa-cart-plus"></i>
                            <span>{{ $product->type === 'service' ? 'Booking Jadwal Rias' : ($product->type === 'rental' ? 'Sewa Perlengkapan' : 'Masukkan ke Keranjang') }}</span>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Customer Reviews Section -->
    <div class="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 mb-8">
        <h2 class="text-xl font-bold text-slate-900 border-b pb-4 mb-6 flex items-center space-x-2">
            <i class="fa-solid fa-star text-amber-500"></i>
            <span>Ulasan Konsumen Terverifikasi ({{ $product->reviews_count }})</span>
        </h2>

        <div class="space-y-4">
            @forelse($product->reviews as $rev)
                <div class="border rounded-2xl p-4 bg-slate-50 text-sm">
                    <div class="flex items-center justify-between">
                        <span class="font-bold text-slate-800">{{ $rev->user->name }}</span>
                        <div class="text-amber-400">
                            @for($i = 1; $i <= 5; $i++)
                                <i class="fa-solid fa-star text-xs {{ $i <= $rev->rating ? 'text-amber-400' : 'text-slate-200' }}"></i>
                            @endfor
                        </div>
                    </div>
                    <p class="text-xs text-slate-400 mt-0.5">{{ $rev->created_at->format('d M Y, H:i') }}</p>
                    <p class="text-slate-700 mt-2">"{{ $rev->comment }}"</p>
                    @if($rev->provider_reply)
                        <div class="mt-3 pl-3 border-l-2 border-brand-500 text-xs text-brand-800 bg-brand-50/50 p-2 rounded-r-lg">
                            <strong>Respon Studio:</strong> {{ $rev->provider_reply }}
                        </div>
                    @endif
                </div>
            @empty
                <p class="text-sm text-slate-400 text-center py-6">Belum ada ulasan untuk produk/layanan ini.</p>
            @endforelse
        </div>
    </div>
</div>
@endsection
