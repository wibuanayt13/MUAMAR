@extends('layouts.app')

@section('content')
<div class="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
    <div class="mb-6">
        <h1 class="text-2xl font-black text-slate-900">Katalog Layanan & Produk MUAMAR</h1>
        <p class="text-xs text-slate-500 mt-1">Jasa Make-Up Artist, kosmetik original, serta sewa perlengkapan wedding & event.</p>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <!-- Filter Sidebar -->
        <div class="lg:col-span-1">
            <div class="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm sticky top-20">
                <div class="flex items-center justify-between border-b pb-3 mb-4">
                    <h2 class="text-sm font-bold text-slate-900 flex items-center space-x-2">
                        <i class="fa-solid fa-sliders text-brand-500"></i>
                        <span>Filter Pencarian</span>
                    </h2>
                    <a href="{{ route('catalog.index') }}" class="text-[11px] text-brand-600 hover:underline">Reset</a>
                </div>

                <form action="{{ route('catalog.index') }}" method="GET" class="space-y-4">
                    <!-- Keyword -->
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 mb-1">Kata Kunci</label>
                        <input type="text" name="q" value="{{ request('q') }}" placeholder="Cari nama atau kota..."
                               class="w-full px-3 py-2 rounded-lg border border-slate-200 text-xs focus:ring-2 focus:ring-brand-500 focus:outline-none">
                    </div>

                    <!-- Type Filter -->
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 mb-1">Tipe Listing</label>
                        <select name="type" class="w-full px-3 py-2 rounded-lg border border-slate-200 text-xs focus:ring-2 focus:ring-brand-500 focus:outline-none">
                            <option value="">Semua Tipe</option>
                            <option value="service" {{ request('type') === 'service' ? 'selected' : '' }}>Jasa MUA</option>
                            <option value="physical" {{ request('type') === 'physical' ? 'selected' : '' }}>Produk Makeup</option>
                            <option value="rental" {{ request('type') === 'rental' ? 'selected' : '' }}>Sewa Tenda & Event</option>
                        </select>
                    </div>

                    <!-- Category Filter -->
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 mb-1">Kategori</label>
                        <select name="category" class="w-full px-3 py-2 rounded-lg border border-slate-200 text-xs focus:ring-2 focus:ring-brand-500 focus:outline-none">
                            <option value="">Semua Kategori</option>
                            @foreach($categories as $parentCat)
                                <optgroup label="{{ $parentCat->name }}">
                                    @foreach($parentCat->children as $child)
                                        <option value="{{ $child->slug }}" {{ request('category') === $child->slug ? 'selected' : '' }}>
                                            {{ $child->name }}
                                        </option>
                                    @endforeach
                                </optgroup>
                            @endforeach
                        </select>
                    </div>

                    <!-- Price Filter -->
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 mb-1">Rentang Harga (IDR)</label>
                        <div class="grid grid-cols-2 gap-2">
                            <input type="number" name="min_price" value="{{ request('min_price') }}" placeholder="Min"
                                   class="px-2.5 py-1.5 rounded-lg border border-slate-200 text-xs">
                            <input type="number" name="max_price" value="{{ request('max_price') }}" placeholder="Max"
                                   class="px-2.5 py-1.5 rounded-lg border border-slate-200 text-xs">
                        </div>
                    </div>

                    <!-- Sorting -->
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 mb-1">Urutkan</label>
                        <select name="sort" class="w-full px-3 py-2 rounded-lg border border-slate-200 text-xs focus:ring-2 focus:ring-brand-500 focus:outline-none">
                            <option value="latest" {{ request('sort') === 'latest' ? 'selected' : '' }}>Terbaru</option>
                            <option value="price_asc" {{ request('sort') === 'price_asc' ? 'selected' : '' }}>Harga: Terendah ke Tertinggi</option>
                            <option value="price_desc" {{ request('sort') === 'price_desc' ? 'selected' : '' }}>Harga: Tertinggi ke Terendah</option>
                        </select>
                    </div>

                    <button type="submit" class="w-full py-2 bg-brand-600 hover:bg-brand-700 text-white rounded-lg text-xs font-semibold transition">
                        Terapkan Filter
                    </button>
                </form>
            </div>
        </div>

        <!-- Product Grid -->
        <div class="lg:col-span-3">
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                @forelse($products as $prod)
                    <div class="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm hover:shadow-md transition flex flex-col">
                        <img src="{{ is_array($prod->images) ? $prod->images[0] : 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=600' }}"
                             alt="{{ $prod->name }}" class="h-44 w-full object-cover">
                        <div class="p-4 flex flex-col flex-grow">
                            <div class="flex items-center justify-between">
                                <span class="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded
                                    @if($prod->type === 'service') bg-brand-50 text-brand-600
                                    @elseif($prod->type === 'rental') bg-indigo-50 text-indigo-600
                                    @else bg-emerald-50 text-emerald-600 @endif">
                                    {{ $prod->type }}
                                </span>
                                @if($prod->average_rating > 0)
                                    <span class="text-[11px] font-bold text-amber-500 flex items-center">
                                        <i class="fa-solid fa-star text-[10px] mr-1"></i> {{ number_format($prod->average_rating, 1) }}
                                    </span>
                                @endif
                            </div>

                            <h3 class="font-bold text-slate-900 mt-2 text-sm line-clamp-2">
                                <a href="{{ route('catalog.show', $prod->slug) }}" class="hover:text-brand-600">{{ $prod->name }}</a>
                            </h3>

                            <p class="text-xs text-slate-500 mt-1 flex items-center">
                                <i class="fa-solid fa-store text-slate-400 mr-1"></i> {{ $prod->provider->business_name }}
                            </p>

                            <div class="mt-auto pt-3 border-t border-slate-100 flex items-center justify-between">
                                <div>
                                    <span class="text-[10px] text-slate-400 block">Harga</span>
                                    <span class="font-bold text-slate-900 text-sm">Rp {{ number_format($prod->base_price, 0, ',', '.') }}</span>
                                </div>
                                <a href="{{ route('catalog.show', $prod->slug) }}" class="px-3 py-1.5 bg-brand-600 hover:bg-brand-700 text-white text-xs font-semibold rounded-lg transition">
                                    Detail
                                </a>
                            </div>
                        </div>
                    </div>
                @empty
                    <div class="sm:col-span-2 md:col-span-3 text-center py-16 bg-white rounded-2xl border border-slate-200">
                        <i class="fa-solid fa-face-frown text-slate-300 text-4xl mb-3"></i>
                        <p class="text-sm font-semibold text-slate-700">Tidak ada item yang sesuai dengan kriteria pencarian.</p>
                        <p class="text-xs text-slate-400 mt-1">Coba ubah kata kunci atau hapus beberapa filter.</p>
                        <a href="{{ route('catalog.index') }}" class="inline-block mt-4 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition">
                            Reset Semua Filter
                        </a>
                    </div>
                @endforelse
            </div>

            <div class="mt-8">
                {{ $products->links() }}
            </div>
        </div>
    </div>
</div>
@endsection
