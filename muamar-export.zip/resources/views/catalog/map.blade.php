@extends('layouts.app')

@section('content')
<div class="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
    <div class="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
            <h1 class="text-2xl font-black text-slate-900 flex items-center space-x-2">
                <i class="fa-solid fa-map-location-dot text-brand-600"></i>
                <span>Peta Lokasi Studio MUA & Vendor Acara</span>
            </h1>
            <p class="text-xs text-slate-500 mt-1">
                Jelajahi lokasi fisik studio Make-Up Artist dan vendor sewa tenda di sekitar Anda untuk kemudahan koordinasi acara.
            </p>
        </div>
        <div>
            <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800">
                <i class="fa-solid fa-lock mr-1.5"></i> Privasi Pelanggan Terlindungi (Hanya Studio Publik Terdaftar)
            </span>
        </div>
    </div>

    <!-- Map & Provider List -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Interactive Leaflet Map Container -->
        <div class="lg:col-span-2 bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm h-[550px] relative">
            <div id="map" class="w-full h-full"></div>
        </div>

        <!-- Sidebar List of Providers -->
        <div class="lg:col-span-1 space-y-4 max-h-[550px] overflow-y-auto pr-1">
            <div class="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm">
                <h2 class="text-sm font-bold text-slate-900 border-b pb-2 mb-3">
                    Daftar Studio Terdaftar ({{ $providers->count() }})
                </h2>

                <div class="space-y-3">
                    @forelse($providers as $p)
                        <div class="border rounded-xl p-3 bg-slate-50 hover:border-brand-500 transition cursor-pointer"
                             onclick="focusMap({{ $p->latitude }}, {{ $p->longitude }}, '{{ addslashes($p->business_name) }}')">
                            <div class="flex items-center justify-between">
                                <h3 class="font-bold text-slate-900 text-xs">{{ $p->business_name }}</h3>
                                @if($p->is_verified)
                                    <span class="text-[10px] text-emerald-700 font-bold"><i class="fa-solid fa-check-circle"></i> Terverifikasi</span>
                                @endif
                            </div>
                            <p class="text-[11px] text-slate-500 mt-1">{{ $p->address }}, {{ $p->city }}</p>
                            <p class="text-[11px] text-brand-600 mt-1 font-semibold">
                                <i class="fa-solid fa-phone mr-1"></i> {{ $p->phone }}
                            </p>
                            <div class="mt-2 pt-2 border-t border-slate-200 flex justify-between items-center text-[11px]">
                                <span class="text-slate-400">{{ $p->products_count }} Listing Aktif</span>
                                <a href="{{ route('catalog.index', ['q' => $p->business_name]) }}" class="text-brand-600 hover:underline font-semibold">
                                    Lihat Jasa &rarr;
                                </a>
                            </div>
                        </div>
                    @empty
                        <p class="text-xs text-slate-400 text-center py-6">Belum ada studio yang mengaktifkan lokasi peta publik.</p>
                    @endforelse
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Leaflet CDN -->
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const defaultLat = -6.2088;
        const defaultLng = 106.8456;
        const map = L.map('map').setView([defaultLat, defaultLng], 10);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19,
            attribution: '&copy; OpenStreetMap contributors'
        }).addTo(map);

        const providers = @json($providers);
        const markers = [];

        providers.forEach(p => {
            if (p.latitude && p.longitude) {
                const marker = L.marker([p.latitude, p.longitude]).addTo(map);
                marker.bindPopup(`
                    <div style="font-family: sans-serif; font-size: 12px; line-height: 1.4;">
                        <strong style="color: #db2777; font-size: 13px;">${p.business_name}</strong><br>
                        <span>${p.address}, ${p.city}</span><br>
                        <span style="color: #64748b;">Kontak: ${p.phone}</span>
                    </div>
                `);
                markers.push(marker);
            }
        });

        if (markers.length > 0) {
            const group = new L.featureGroup(markers);
            map.fitBounds(group.getBounds().pad(0.2));
        }

        window.focusMap = function(lat, lng, name) {
            map.setView([lat, lng], 14);
        };
    });
</script>
@endsection
