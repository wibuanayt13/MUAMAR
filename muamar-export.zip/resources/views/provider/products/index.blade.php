@extends('layouts.app')

@section('content')
<div class="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
    <!-- Header with Action Buttons -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between border-b pb-6 mb-6 gap-4">
        <div>
            <div class="flex items-center space-x-2 text-xs text-slate-500 mb-1">
                <a href="{{ route('provider.dashboard') }}" class="hover:underline">Dashboard Studio</a>
                <span>&rsaquo;</span>
                <span class="text-slate-800 font-semibold">Manajemen Etalase & Produk</span>
            </div>
            <h1 class="text-2xl font-black text-slate-900">Katalog & Etalase {{ $provider->business_name }}</h1>
            <p class="text-xs text-slate-500 mt-0.5">Kelola paket rias pengantin, kosmetik dengan variasi stok, dan persewaan alat/tenda.</p>
        </div>

        <div class="flex flex-wrap items-center gap-2">
            <a href="{{ route('provider.schedule.index') }}" class="px-4 py-2 border border-slate-300 hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-semibold transition flex items-center space-x-1.5">
                <i class="fa-regular fa-calendar-days text-brand-500"></i>
                <span>Kalender Ketersediaan</span>
            </a>
            <a href="{{ route('provider.profile.edit') }}" class="px-4 py-2 border border-slate-300 hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-semibold transition flex items-center space-x-1.5">
                <i class="fa-solid fa-store text-brand-500"></i>
                <span>Profil Studio</span>
            </a>
            <a href="{{ route('provider.products.create') }}" class="px-4 py-2 bg-brand-600 hover:bg-brand-700 text-white rounded-xl text-xs font-semibold transition flex items-center space-x-1.5 shadow-sm">
                <i class="fa-solid fa-plus"></i>
                <span>Tambah Produk / Layanan</span>
            </a>
        </div>
    </div>

    <!-- Filter Tabs -->
    <div class="flex space-x-2 mb-6 border-b pb-3 text-xs font-semibold">
        <a href="{{ route('provider.products.index') }}"
           class="px-3.5 py-2 rounded-lg transition {{ !request('type') ? 'bg-brand-600 text-white' : 'text-slate-600 hover:bg-slate-100' }}">
            Semua ({{ $counts['all'] }})
        </a>
        <a href="{{ route('provider.products.index', ['type' => 'service']) }}"
           class="px-3.5 py-2 rounded-lg transition {{ request('type') === 'service' ? 'bg-brand-600 text-white' : 'text-slate-600 hover:bg-slate-100' }}">
            Jasa MUA ({{ $counts['service'] }})
        </a>
        <a href="{{ route('provider.products.index', ['type' => 'physical']) }}"
           class="px-3.5 py-2 rounded-lg transition {{ request('type') === 'physical' ? 'bg-brand-600 text-white' : 'text-slate-600 hover:bg-slate-100' }}">
            Produk Fisik ({{ $counts['physical'] }})
        </a>
        <a href="{{ route('provider.products.index', ['type' => 'rental']) }}"
           class="px-3.5 py-2 rounded-lg transition {{ request('type') === 'rental' ? 'bg-brand-600 text-white' : 'text-slate-600 hover:bg-slate-100' }}">
            Sewa Tenda & Event ({{ $counts['rental'] }})
        </a>
    </div>

    <!-- Products Table -->
    <div class="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
        <table class="w-full text-left text-sm">
            <thead class="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-500 uppercase tracking-wider">
                <tr>
                    <th class="py-3.5 px-4">Item & Foto</th>
                    <th class="py-3.5 px-4">Kategori & Tipe</th>
                    <th class="py-3.5 px-4">Harga Dasar</th>
                    <th class="py-3.5 px-4">Parameter Spesifik</th>
                    <th class="py-3.5 px-4">Status</th>
                    <th class="py-3.5 px-4 text-right">Aksi</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
                @forelse($products as $prod)
                    <tr class="hover:bg-slate-50/50 transition">
                        <td class="py-3.5 px-4">
                            <div class="flex items-center space-x-3">
                                <img src="{{ is_array($prod->images) ? $prod->images[0] : 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=600' }}"
                                     alt="{{ $prod->name }}" class="w-12 h-12 rounded-xl object-cover border border-slate-200">
                                <div>
                                    <a href="{{ route('catalog.show', $prod->slug) }}" target="_blank" class="font-bold text-slate-900 hover:text-brand-600 text-xs block">
                                        {{ $prod->name }}
                                    </a>
                                    <span class="text-[10px] text-slate-400">Slug: {{ $prod->slug }}</span>
                                </div>
                            </div>
                        </td>

                        <td class="py-3.5 px-4 text-xs">
                            <span class="font-semibold text-slate-700 block">{{ $prod->category->name }}</span>
                            <span class="inline-block mt-0.5 text-[10px] px-2 py-0.5 rounded font-bold uppercase
                                @if($prod->type === 'service') bg-pink-100 text-pink-800
                                @elseif($prod->type === 'rental') bg-indigo-100 text-indigo-800
                                @else bg-emerald-100 text-emerald-800 @endif">
                                {{ $prod->type }}
                            </span>
                        </td>

                        <td class="py-3.5 px-4 font-bold text-slate-900 text-xs">
                            Rp {{ number_format($prod->base_price, 0, ',', '.') }}
                        </td>

                        <td class="py-3.5 px-4 text-xs text-slate-600">
                            @if($prod->type === 'service' && $prod->serviceProfile)
                                <span>Durasi: <strong>{{ $prod->serviceProfile->duration_minutes }}m</strong> (+buffer {{ $prod->serviceProfile->buffer_minutes }}m)</span>
                                <span class="block text-[11px] text-slate-400">Artis: {{ $prod->serviceProfile->artist_name }}</span>
                            @elseif($prod->type === 'rental' && $prod->rentalProfile)
                                <span>Kapasitas: <strong>{{ $prod->rentalProfile->total_units }} {{ $prod->rentalProfile->unit_type }}</strong></span>
                                <span class="block text-[11px] text-indigo-600">Deposit: Rp {{ number_format($prod->rentalProfile->deposit_amount, 0, ',', '.') }}</span>
                            @elseif($prod->type === 'physical')
                                <span>Variasi SKU: <strong>{{ $prod->variants->count() }}</strong></span>
                                <span class="block text-[11px] text-slate-400">Total Stok: {{ $prod->variants->sum('stock') }} unit</span>
                            @endif
                        </td>

                        <td class="py-3.5 px-4">
                            @if($prod->is_active)
                                <span class="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase bg-emerald-100 text-emerald-800">Aktif</span>
                            @else
                                <span class="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase bg-slate-100 text-slate-500">Nonaktif</span>
                            @endif
                        </td>

                        <td class="py-3.5 px-4 text-right space-x-2">
                            <a href="{{ route('provider.products.edit', $prod->id) }}" class="p-1.5 text-slate-500 hover:text-brand-600 transition" title="Edit Item">
                                <i class="fa-solid fa-pen-to-square"></i>
                            </a>
                            <form action="{{ route('provider.products.destroy', $prod->id) }}" method="POST" class="inline"
                                  onsubmit="return confirm('Apakah Anda yakin ingin menghapus item ini dari etalase?');">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="p-1.5 text-slate-400 hover:text-rose-600 transition" title="Hapus">
                                    <i class="fa-solid fa-trash-can"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="6" class="py-12 text-center text-slate-400 text-xs">
                            Belum ada produk atau layanan pada kategori ini.
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>

        <div class="p-4 border-t border-slate-200">
            {{ $products->links() }}
        </div>
    </div>
</div>
@endsection
