@extends('layouts.app')

@section('content')
<div class="max-w-4xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
    <div class="mb-6 flex items-center justify-between">
        <div>
            <div class="flex items-center space-x-2 text-xs text-slate-500 mb-1">
                <a href="{{ route('provider.products.index') }}" class="hover:underline">Manajemen Etalase</a>
                <span>&rsaquo;</span>
                <span class="text-slate-800 font-semibold">Tambah Item Baru</span>
            </div>
            <h1 class="text-2xl font-black text-slate-900">Tambah Produk / Layanan MUA</h1>
        </div>
        <a href="{{ route('provider.products.index') }}" class="text-xs font-semibold text-slate-500 hover:text-slate-800">
            &larr; Batal & Kembali
        </a>
    </div>

    <form action="{{ route('provider.products.store') }}" method="POST" enctype="multipart/form-data" class="space-y-6">
        @csrf

        <!-- General Info Card -->
        <div class="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
            <h2 class="text-sm font-bold text-slate-900 border-b pb-3 mb-4">1. Informasi Umum</h2>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div class="sm:col-span-2">
                    <label class="block text-xs font-semibold text-slate-700 mb-1">Nama Produk / Layanan <span class="text-rose-500">*</span></label>
                    <input type="text" name="name" required value="{{ old('name') }}" placeholder="Contoh: Makeup Wisuda Flawless & Tahan Lama"
                           class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none">
                    @error('name') <p class="text-xs text-rose-500 mt-1">{{ $message }}</p> @enderror
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 mb-1">Kategori <span class="text-rose-500">*</span></label>
                    <select name="category_id" required class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none">
                        <option value="">-- Pilih Kategori --</option>
                        @foreach($categories as $cat)
                            <option value="{{ $cat->id }}" {{ old('category_id') == $cat->id ? 'selected' : '' }}>
                                {{ $cat->name }} ({{ $cat->type }})
                            </option>
                        @endforeach
                    </select>
                    @error('category_id') <p class="text-xs text-rose-500 mt-1">{{ $message }}</p> @enderror
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 mb-1">Tipe Listing <span class="text-rose-500">*</span></label>
                    <select id="typeSelector" name="type" required class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none">
                        <option value="service" {{ old('type', 'service') === 'service' ? 'selected' : '' }}>Jasa Make-Up Artist</option>
                        <option value="physical" {{ old('type') === 'physical' ? 'selected' : '' }}>Produk Kosmetik Fisik</option>
                        <option value="rental" {{ old('type') === 'rental' ? 'selected' : '' }}>Sewa Tenda & Perlengkapan Acara</option>
                    </select>
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 mb-1">Harga Dasar (IDR) <span class="text-rose-500">*</span></label>
                    <input type="number" name="base_price" required value="{{ old('base_price', 0) }}" min="0" placeholder="Contoh: 350000"
                           class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none">
                    @error('base_price') <p class="text-xs text-rose-500 mt-1">{{ $message }}</p> @enderror
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 mb-1">Upload Foto Produk (Maks 3MB)</label>
                    <input type="file" name="images[]" multiple accept="image/jpeg,image/png,image/webp"
                           class="w-full text-xs text-slate-500 file:mr-4 file:py-2 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-brand-50 file:text-brand-700 hover:file:bg-brand-100">
                </div>

                <div class="sm:col-span-2">
                    <label class="block text-xs font-semibold text-slate-700 mb-1">Deskripsi Lengkap</label>
                    <textarea name="description" rows="3" placeholder="Jelaskan detail apa saja yang didapat, merek produk yang dipakai, dll..."
                              class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none">{{ old('description') }}</textarea>
                </div>
            </div>
        </div>

        <!-- Conditional Section: Jasa MUA -->
        <div id="serviceFields" class="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
            <h2 class="text-sm font-bold text-slate-900 border-b pb-3 mb-4 flex items-center space-x-2">
                <i class="fa-solid fa-wand-magic-sparkles text-pink-500"></i>
                <span>2. Parameter Scheduler Jasa MUA</span>
            </h2>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <label class="block text-xs font-semibold text-slate-700 mb-1">Durasi Pengerjaan Rias (Menit) <span class="text-rose-500">*</span></label>
                    <input type="number" name="duration_minutes" value="{{ old('duration_minutes', 120) }}" min="15" step="15"
                           class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm">
                    <span class="text-[11px] text-slate-400">Contoh: 120 menit (2 jam).</span>
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 mb-1">Jeda Waktu Perjalanan / Buffer (Menit) <span class="text-rose-500">*</span></label>
                    <input type="number" name="buffer_minutes" value="{{ old('buffer_minutes', 30) }}" min="0" step="15"
                           class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm">
                    <span class="text-[11px] text-slate-400">Waktu aman agar perias tidak bentrok jadwal dengan klien berikutnya.</span>
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 mb-1">Nama Perias / Artis Utama</label>
                    <input type="text" name="artist_name" value="{{ old('artist_name', $provider->business_name) }}"
                           class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm">
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 mb-1">Area Jangkauan Layanan</label>
                    <input type="text" name="service_area" value="{{ old('service_area', $provider->city) }}" placeholder="Contoh: Jabodetabek / Khusus Studio"
                           class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm">
                </div>
            </div>
        </div>

        <!-- Conditional Section: Produk Fisik (Varian SKU & Stok) -->
        <div id="physicalFields" class="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm hidden">
            <h2 class="text-sm font-bold text-slate-900 border-b pb-3 mb-4 flex items-center space-x-2">
                <i class="fa-solid fa-box-open text-emerald-500"></i>
                <span>2. Variasi Varian, SKU, & Kontrol Stok Fisik</span>
            </h2>

            <div class="space-y-3">
                <div class="grid grid-cols-1 sm:grid-cols-4 gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200">
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 mb-1">Nama Varian (Shade/Ukuran)</label>
                        <input type="text" name="variants[0][variant_name]" value="Default Shade" class="w-full px-3 py-1.5 rounded border border-slate-300 text-xs">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 mb-1">Kode SKU</label>
                        <input type="text" name="variants[0][sku]" value="{{ strtoupper(Str::random(6)) }}" class="w-full px-3 py-1.5 rounded border border-slate-300 text-xs">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 mb-1">Harga (IDR)</label>
                        <input type="number" name="variants[0][price]" value="100000" class="w-full px-3 py-1.5 rounded border border-slate-300 text-xs">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 mb-1">Stok Awal</label>
                        <input type="number" name="variants[0][stock]" value="10" min="0" class="w-full px-3 py-1.5 rounded border border-slate-300 text-xs">
                    </div>
                </div>
            </div>
        </div>

        <!-- Conditional Section: Sewa Tenda & Event -->
        <div id="rentalFields" class="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm hidden">
            <h2 class="text-sm font-bold text-slate-900 border-b pb-3 mb-4 flex items-center space-x-2">
                <i class="fa-solid fa-campground text-indigo-500"></i>
                <span>2. Kapasitas Unit & Uang Jaminan Sewa</span>
            </h2>

            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                    <label class="block text-xs font-semibold text-slate-700 mb-1">Total Unit Tersedia <span class="text-rose-500">*</span></label>
                    <input type="number" name="total_units" value="{{ old('total_units', 5) }}" min="1" class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm">
                    <span class="text-[11px] text-slate-400">Kapasitas maksimal yang dimiliki vendor.</span>
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 mb-1">Uang Jaminan / Deposit (IDR) <span class="text-rose-500">*</span></label>
                    <input type="number" name="deposit_amount" value="{{ old('deposit_amount', 250000) }}" min="0" class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm">
                    <span class="text-[11px] text-slate-400">Jaminan kerusakan barang sewaan.</span>
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 mb-1">Jenis Satuan</label>
                    <input type="text" name="unit_type" value="{{ old('unit_type', 'unit tenda') }}" placeholder="unit / set / paket 50 kursi"
                           class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm">
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 mb-1">Minimal Hari Sewa</label>
                    <input type="number" name="min_rental_days" value="{{ old('min_rental_days', 1) }}" min="1" class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm">
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 mb-1">Jeda Waktu Bongkar/Pasang (Jam)</label>
                    <input type="number" name="buffer_hours" value="{{ old('buffer_hours', 4) }}" min="0" class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm">
                </div>
            </div>
        </div>

        <div class="flex justify-end space-x-3 pt-4 border-t">
            <a href="{{ route('provider.products.index') }}" class="px-5 py-2.5 border border-slate-300 hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-semibold transition">
                Batal
            </a>
            <button type="submit" class="px-6 py-2.5 bg-brand-600 hover:bg-brand-700 text-white rounded-xl text-xs font-bold transition shadow-sm">
                Terbitkan ke Etalase
            </button>
        </div>
    </form>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const selector = document.getElementById('typeSelector');
        const serviceFields = document.getElementById('serviceFields');
        const physicalFields = document.getElementById('physicalFields');
        const rentalFields = document.getElementById('rentalFields');

        function updateFields() {
            const val = selector.value;
            serviceFields.classList.toggle('hidden', val !== 'service');
            physicalFields.classList.toggle('hidden', val !== 'physical');
            rentalFields.classList.toggle('hidden', val !== 'rental');
        }

        selector.addEventListener('change', updateFields);
        updateFields();
    });
</script>
@endsection
