@extends('layouts.app')

@section('content')
<div class="max-w-4xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
    <div class="mb-6 flex items-center justify-between">
        <div>
            <div class="flex items-center space-x-2 text-xs text-slate-500 mb-1">
                <a href="{{ route('provider.products.index') }}" class="hover:underline">Manajemen Etalase</a>
                <span>&rsaquo;</span>
                <span class="text-slate-800 font-semibold">Edit Produk #{{ $product->id }}</span>
            </div>
            <h1 class="text-2xl font-black text-slate-900">Perbarui Item: {{ $product->name }}</h1>
        </div>
        <a href="{{ route('provider.products.index') }}" class="text-xs font-semibold text-slate-500 hover:text-slate-800">
            &larr; Batal & Kembali
        </a>
    </div>

    <form action="{{ route('provider.products.update', $product->id) }}" method="POST" enctype="multipart/form-data" class="space-y-6">
        @csrf
        @method('PUT')

        <div class="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
            <h2 class="text-sm font-bold text-slate-900 border-b pb-3 mb-4">1. Informasi Umum</h2>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div class="sm:col-span-2">
                    <label class="block text-xs font-semibold text-slate-700 mb-1">Nama Produk / Layanan <span class="text-rose-500">*</span></label>
                    <input type="text" name="name" required value="{{ old('name', $product->name) }}"
                           class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none">
                    @error('name') <p class="text-xs text-rose-500 mt-1">{{ $message }}</p> @enderror
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 mb-1">Kategori <span class="text-rose-500">*</span></label>
                    <select name="category_id" required class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none">
                        @foreach($categories as $cat)
                            <option value="{{ $cat->id }}" {{ old('category_id', $product->category_id) == $cat->id ? 'selected' : '' }}>
                                {{ $cat->name }}
                            </option>
                        @endforeach
                    </select>
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 mb-1">Tipe Listing</label>
                    <input type="text" readonly value="{{ strtoupper($product->type) }}"
                           class="w-full px-3 py-2 rounded-lg border border-slate-200 bg-slate-100 text-slate-500 text-sm font-bold cursor-not-allowed">
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 mb-1">Harga Dasar (IDR) <span class="text-rose-500">*</span></label>
                    <input type="number" name="base_price" required value="{{ old('base_price', $product->base_price) }}" min="0"
                           class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none">
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 mb-1">Status Publikasi</label>
                    <label class="flex items-center space-x-2 mt-2 cursor-pointer">
                        <input type="checkbox" name="is_active" value="1" {{ old('is_active', $product->is_active) ? 'checked' : '' }}
                               class="h-4 w-4 rounded border-slate-300 text-brand-600 focus:ring-brand-500">
                        <span class="text-sm font-semibold text-slate-800">Aktif & Ditampilkan di Katalog</span>
                    </label>
                </div>

                <div class="sm:col-span-2">
                    <label class="block text-xs font-semibold text-slate-700 mb-1">Tambah Foto Baru (Opsional)</label>
                    <input type="file" name="images[]" multiple accept="image/jpeg,image/png,image/webp"
                           class="w-full text-xs text-slate-500 file:mr-4 file:py-2 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-brand-50 file:text-brand-700 hover:file:bg-brand-100">
                </div>

                <div class="sm:col-span-2">
                    <label class="block text-xs font-semibold text-slate-700 mb-1">Deskripsi Lengkap</label>
                    <textarea name="description" rows="3"
                              class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none">{{ old('description', $product->description) }}</textarea>
                </div>
            </div>
        </div>

        <!-- Type Specific Settings -->
        @if($product->type === 'service' && $product->serviceProfile)
            <div class="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
                <h2 class="text-sm font-bold text-slate-900 border-b pb-3 mb-4 flex items-center space-x-2">
                    <i class="fa-solid fa-wand-magic-sparkles text-pink-500"></i>
                    <span>2. Parameter Scheduler Jasa MUA</span>
                </h2>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 mb-1">Durasi Pengerjaan Rias (Menit)</label>
                        <input type="number" name="duration_minutes" value="{{ old('duration_minutes', $product->serviceProfile->duration_minutes) }}" min="15" step="15"
                               class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm">
                    </div>

                    <div>
                        <label class="block text-xs font-semibold text-slate-700 mb-1">Jeda Waktu Buffer (Menit)</label>
                        <input type="number" name="buffer_minutes" value="{{ old('buffer_minutes', $product->serviceProfile->buffer_minutes) }}" min="0" step="15"
                               class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm">
                    </div>

                    <div>
                        <label class="block text-xs font-semibold text-slate-700 mb-1">Nama Perias / Artis</label>
                        <input type="text" name="artist_name" value="{{ old('artist_name', $product->serviceProfile->artist_name) }}"
                               class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm">
                    </div>

                    <div>
                        <label class="block text-xs font-semibold text-slate-700 mb-1">Area Jangkauan Layanan</label>
                        <input type="text" name="service_area" value="{{ old('service_area', $product->serviceProfile->service_area) }}"
                               class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm">
                    </div>
                </div>
            </div>
        @elseif($product->type === 'physical')
            <div class="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
                <h2 class="text-sm font-bold text-slate-900 border-b pb-3 mb-4 flex items-center space-x-2">
                    <i class="fa-solid fa-box-open text-emerald-500"></i>
                    <span>2. Variasi Varian & Stok</span>
                </h2>

                <div class="space-y-3">
                    @foreach($product->variants as $idx => $v)
                        <div class="grid grid-cols-1 sm:grid-cols-4 gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200">
                            <input type="hidden" name="variants[{{ $idx }}][id]" value="{{ $v->id }}">
                            <div>
                                <label class="block text-xs font-semibold text-slate-700 mb-1">Nama Varian</label>
                                <input type="text" name="variants[{{ $idx }}][variant_name]" value="{{ old("variants.$idx.variant_name", $v->variant_name) }}" class="w-full px-3 py-1.5 rounded border border-slate-300 text-xs">
                            </div>
                            <div>
                                <label class="block text-xs font-semibold text-slate-700 mb-1">SKU</label>
                                <input type="text" name="variants[{{ $idx }}][sku]" value="{{ old("variants.$idx.sku", $v->sku) }}" class="w-full px-3 py-1.5 rounded border border-slate-300 text-xs">
                            </div>
                            <div>
                                <label class="block text-xs font-semibold text-slate-700 mb-1">Harga</label>
                                <input type="number" name="variants[{{ $idx }}][price]" value="{{ old("variants.$idx.price", $v->price) }}" class="w-full px-3 py-1.5 rounded border border-slate-300 text-xs">
                            </div>
                            <div>
                                <label class="block text-xs font-semibold text-slate-700 mb-1">Stok Unit</label>
                                <input type="number" name="variants[{{ $idx }}][stock]" value="{{ old("variants.$idx.stock", $v->stock) }}" min="0" class="w-full px-3 py-1.5 rounded border border-slate-300 text-xs">
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        @elseif($product->type === 'rental' && $product->rentalProfile)
            <div class="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
                <h2 class="text-sm font-bold text-slate-900 border-b pb-3 mb-4 flex items-center space-x-2">
                    <i class="fa-solid fa-campground text-indigo-500"></i>
                    <span>2. Kapasitas Unit & Uang Jaminan Sewa</span>
                </h2>

                <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 mb-1">Total Unit Tersedia</label>
                        <input type="number" name="total_units" value="{{ old('total_units', $product->rentalProfile->total_units) }}" min="1" class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm">
                    </div>

                    <div>
                        <label class="block text-xs font-semibold text-slate-700 mb-1">Uang Jaminan / Deposit (IDR)</label>
                        <input type="number" name="deposit_amount" value="{{ old('deposit_amount', $product->rentalProfile->deposit_amount) }}" min="0" class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm">
                    </div>

                    <div>
                        <label class="block text-xs font-semibold text-slate-700 mb-1">Jenis Satuan</label>
                        <input type="text" name="unit_type" value="{{ old('unit_type', $product->rentalProfile->unit_type) }}" class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm">
                    </div>
                </div>
            </div>
        @endif

        <div class="flex justify-end space-x-3 pt-4 border-t">
            <a href="{{ route('provider.products.index') }}" class="px-5 py-2.5 border border-slate-300 hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-semibold transition">
                Batal
            </a>
            <button type="submit" class="px-6 py-2.5 bg-brand-600 hover:bg-brand-700 text-white rounded-xl text-xs font-bold transition shadow-sm">
                Simpan Perubahan
            </button>
        </div>
    </form>
</div>
@endsection
