@extends('layouts.app')

@section('content')
<div class="max-w-5xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
    <div class="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between border-b pb-4 gap-4">
        <div>
            <div class="flex items-center space-x-2 text-xs text-slate-500 mb-1">
                <a href="{{ route('provider.dashboard') }}" class="hover:underline">Dashboard Studio</a>
                <span>&rsaquo;</span>
                <span class="text-slate-800 font-semibold">Kalender & Jam Ketersediaan</span>
            </div>
            <h1 class="text-2xl font-black text-slate-900">Pengaturan Kalender & Jam Operasional</h1>
            <p class="text-xs text-slate-500 mt-0.5">Tentukan jam kerja harian studio dan atur tanggal libur agar pesanan MUA tidak bentrok.</p>
        </div>

        <a href="{{ route('provider.products.index') }}" class="px-4 py-2 border border-slate-300 hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-semibold transition">
            &larr; Ke Etalase Produk
        </a>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Weekly Availability Matrix -->
        <div class="lg:col-span-2">
            <div class="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
                <h2 class="text-base font-bold text-slate-900 border-b pb-3 mb-4 flex items-center space-x-2">
                    <i class="fa-solid fa-clock text-brand-600"></i>
                    <span>Jam Operasional Mingguan</span>
                </h2>

                <form action="{{ route('provider.schedule.update') }}" method="POST">
                    @csrf
                    @method('PUT')

                    <div class="divide-y divide-slate-100">
                        @foreach($dayNames as $dayIndex => $dayName)
                            @php
                                $avail = $availabilities->firstWhere('day_of_week', $dayIndex);
                                $startTime = $avail ? substr($avail->start_time, 0, 5) : '08:00';
                                $endTime = $avail ? substr($avail->end_time, 0, 5) : '20:00';
                                $isAvailable = $avail ? $avail->is_available : true;
                            @endphp
                            <div class="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                                <input type="hidden" name="schedules[{{ $dayIndex }}][day_of_week]" value="{{ $dayIndex }}">
                                <div class="w-28 font-bold text-slate-800 flex items-center space-x-2">
                                    <label class="cursor-pointer flex items-center space-x-2">
                                        <input type="checkbox" name="schedules[{{ $dayIndex }}][is_available]" value="1" {{ $isAvailable ? 'checked' : '' }}
                                               class="h-4 w-4 rounded border-slate-300 text-brand-600 focus:ring-brand-500">
                                        <span>{{ $dayName }}</span>
                                    </label>
                                </div>

                                <div class="flex items-center space-x-2">
                                    <span class="text-slate-400">Buka:</span>
                                    <input type="time" name="schedules[{{ $dayIndex }}][start_time]" value="{{ $startTime }}"
                                           class="px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs focus:ring-2 focus:ring-brand-500">
                                    <span class="text-slate-400">s/d</span>
                                    <input type="time" name="schedules[{{ $dayIndex }}][end_time]" value="{{ $endTime }}"
                                           class="px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs focus:ring-2 focus:ring-brand-500">
                                </div>
                            </div>
                        @endforeach
                    </div>

                    <div class="mt-6 pt-4 border-t flex justify-end">
                        <button type="submit" class="px-5 py-2.5 bg-brand-600 hover:bg-brand-700 text-white rounded-xl text-xs font-bold transition shadow-sm">
                            Simpan Jam Operasional
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Overrides / Holidays -->
        <div class="lg:col-span-1 space-y-6">
            <!-- Add Holiday Form -->
            <div class="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
                <h3 class="text-sm font-bold text-slate-900 border-b pb-3 mb-3 flex items-center space-x-1.5">
                    <i class="fa-solid fa-calendar-xmark text-rose-500"></i>
                    <span>Tambah Libur Tentatif</span>
                </h3>

                <form action="{{ route('provider.schedule.override.store') }}" method="POST" class="space-y-3 text-xs">
                    @csrf
                    <div>
                        <label class="block font-semibold text-slate-700 mb-1">Tanggal Libur <span class="text-rose-500">*</span></label>
                        <input type="date" name="override_date" required min="{{ now()->toDateString() }}"
                               class="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-2 focus:ring-brand-500">
                    </div>

                    <div>
                        <label class="block font-semibold text-slate-700 mb-1">Keterangan / Alasan</label>
                        <input type="text" name="reason" placeholder="Contoh: Libur Hari Raya / Acara Keluarga"
                               class="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-2 focus:ring-brand-500">
                    </div>

                    <button type="submit" class="w-full py-2 bg-slate-800 hover:bg-slate-900 text-white font-semibold rounded-lg text-xs transition">
                        Tambahkan Hari Libur
                    </button>
                </form>
            </div>

            <!-- List of upcoming overrides -->
            <div class="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
                <h3 class="text-sm font-bold text-slate-900 border-b pb-3 mb-3">
                    Daftar Libur Mendatang ({{ $overrides->count() }})
                </h3>

                <div class="space-y-2 text-xs">
                    @forelse($overrides as $ov)
                        <div class="p-2.5 rounded-lg border border-rose-200 bg-rose-50/50 flex items-center justify-between">
                            <div>
                                <span class="font-bold text-rose-900">{{ \Carbon\Carbon::parse($ov->override_date)->format('d M Y') }}</span>
                                <span class="block text-[11px] text-slate-500">{{ $ov->reason ?? 'Studio Libur' }}</span>
                            </div>
                            <form action="{{ route('provider.schedule.override.destroy', $ov->id) }}" method="POST"
                                  onsubmit="return confirm('Hapus tanggal libur ini?');">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="text-rose-400 hover:text-rose-700 transition" title="Hapus">
                                    <i class="fa-solid fa-trash-can"></i>
                                </button>
                            </form>
                        </div>
                    @empty
                        <p class="text-slate-400 text-center py-4">Belum ada jadwal libur tentatif.</p>
                    @endforelse
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
