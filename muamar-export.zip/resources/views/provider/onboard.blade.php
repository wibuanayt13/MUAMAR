@extends('layouts.app')

@section('content')
<div class="max-w-3xl mx-auto py-10 px-4 sm:px-6 lg:px-8">
    <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div class="bg-gradient-to-r from-brand-600 to-pink-500 p-6 text-white">
            <h1 class="text-2xl font-bold">Pendaftaran Usaha & Studio MUA</h1>
            <p class="text-brand-100 text-sm mt-1">
                Lengkapi identitas usaha Anda agar jasa rias, perlengkapan sewa, dan produk makeup Anda dapat ditemukan oleh ribuan calon pelanggan.
            </p>
        </div>

        <form action="{{ route('provider.onboard.post') }}" method="POST" enctype="multipart/form-data" class="p-6 sm:p-8 space-y-6">
            @csrf

            <!-- Informasi Usaha -->
            <div>
                <h2 class="text-lg font-semibold text-slate-800 border-b pb-2 mb-4">1. Identitas Usaha / Studio</h2>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div class="sm:col-span-2">
                        <label for="business_name" class="block text-sm font-medium text-slate-700">Nama Usaha / Nama MUA Artist <span class="text-rose-500">*</span></label>
                        <input type="text" id="business_name" name="business_name" required value="{{ old('business_name') }}"
                               placeholder="Contoh: Cantika Wedding & MUA Studio"
                               class="mt-1 w-full px-4 py-2.5 rounded-lg border @error('business_name') border-rose-500 @else border-slate-300 @enderror text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none">
                        @error('business_name') <p class="text-xs text-rose-500 mt-1">{{ $message }}</p> @enderror
                    </div>

                    <div class="sm:col-span-2">
                        <label for="description" class="block text-sm font-medium text-slate-700">Deskripsi & Spesialisasi Layanan</label>
                        <textarea id="description" name="description" rows="3"
                                  placeholder="Jelaskan spesialisasi Anda (misal: MUA Wedding Adat Sunda & Solo Putri, Sewa Tenda VIP, dll)..."
                                  class="mt-1 w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none">{{ old('description') }}</textarea>
                    </div>

                    <div>
                        <label for="phone" class="block text-sm font-medium text-slate-700">Nomor WhatsApp Usaha <span class="text-rose-500">*</span></label>
                        <input type="text" id="phone" name="phone" required value="{{ old('phone', $user->phone) }}"
                               placeholder="Contoh: 081234567890"
                               class="mt-1 w-full px-4 py-2.5 rounded-lg border @error('phone') border-rose-500 @else border-slate-300 @enderror text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none">
                        @error('phone') <p class="text-xs text-rose-500 mt-1">{{ $message }}</p> @enderror
                    </div>
                </div>
            </div>

            <!-- Lokasi & Peta Publik -->
            <div>
                <h2 class="text-lg font-semibold text-slate-800 border-b pb-2 mb-4">2. Lokasi Studio & Tampilan Peta</h2>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div class="sm:col-span-2">
                        <label for="address" class="block text-sm font-medium text-slate-700">Alamat Studio / Usaha <span class="text-rose-500">*</span></label>
                        <input type="text" id="address" name="address" required value="{{ old('address') }}"
                               placeholder="Nama jalan, nomor ruko/rumah, kelurahan, kecamatan"
                               class="mt-1 w-full px-4 py-2.5 rounded-lg border @error('address') border-rose-500 @else border-slate-300 @enderror text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none">
                        @error('address') <p class="text-xs text-rose-500 mt-1">{{ $message }}</p> @enderror
                    </div>

                    <div>
                        <label for="city" class="block text-sm font-medium text-slate-700">Kota / Kabupaten <span class="text-rose-500">*</span></label>
                        <input type="text" id="city" name="city" required value="{{ old('city') }}"
                               placeholder="Contoh: Jakarta Selatan"
                               class="mt-1 w-full px-4 py-2.5 rounded-lg border @error('city') border-rose-500 @else border-slate-300 @enderror text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none">
                        @error('city') <p class="text-xs text-rose-500 mt-1">{{ $message }}</p> @enderror
                    </div>

                    <div>
                        <label for="province" class="block text-sm font-medium text-slate-700">Provinsi</label>
                        <input type="text" id="province" name="province" value="{{ old('province') }}"
                               placeholder="Contoh: DKI Jakarta"
                               class="mt-1 w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none">
                    </div>

                    <div>
                        <label for="latitude" class="block text-sm font-medium text-slate-700">Latitude (Koordinat GPS)</label>
                        <input type="text" id="latitude" name="latitude" value="{{ old('latitude', '-6.2088') }}"
                               placeholder="-6.2088"
                               class="mt-1 w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none">
                    </div>

                    <div>
                        <label for="longitude" class="block text-sm font-medium text-slate-700">Longitude (Koordinat GPS)</label>
                        <input type="text" id="longitude" name="longitude" value="{{ old('longitude', '106.8456') }}"
                               placeholder="106.8456"
                               class="mt-1 w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none">
                    </div>

                    <div class="sm:col-span-2 bg-slate-50 p-4 rounded-xl border border-slate-200">
                        <label class="flex items-start space-x-3 cursor-pointer">
                            <input type="checkbox" name="is_location_public" value="1" checked class="mt-1 h-4 w-4 rounded border-slate-300 text-brand-600 focus:ring-brand-500">
                            <div>
                                <span class="text-sm font-medium text-slate-900">Tampilkan Lokasi di Peta Publik MUAMAR</span>
                                <p class="text-xs text-slate-500">
                                    Mengizinkan calon konsumen melihat jarak dan titik studio Anda pada fitur peta pencarian MUA terdekat. (Hanya lokasi studio provider yang dipublikasikan; privasi alamat rumah pelanggan tetap terlindungi).
                                </p>
                            </div>
                        </label>
                    </div>
                </div>
            </div>

            <!-- Metode Pembayaran yang Diterima -->
            <div>
                <h2 class="text-lg font-semibold text-slate-800 border-b pb-2 mb-4">3. Opsi Pembayaran yang Disediakan</h2>
                <div class="space-y-3">
                    <label class="flex items-center space-x-3 p-3 bg-slate-50 rounded-lg border border-slate-200 cursor-pointer">
                        <input type="checkbox" name="qris_active" value="1" checked class="h-4 w-4 rounded border-slate-300 text-brand-600 focus:ring-brand-500">
                        <div>
                            <span class="text-sm font-semibold text-slate-800">Terima Pembayaran QRIS Dinamis</span>
                            <span class="text-xs text-slate-500 block">Dukungan pembayaran instan dari BCA, Mandiri, GoPay, OVO, ShopeePay, dan DANA.</span>
                        </div>
                    </label>

                    <label class="flex items-center space-x-3 p-3 bg-slate-50 rounded-lg border border-slate-200 cursor-pointer">
                        <input type="checkbox" name="cod_active" value="1" checked class="h-4 w-4 rounded border-slate-300 text-brand-600 focus:ring-brand-500">
                        <div>
                            <span class="text-sm font-semibold text-slate-800">Terima Opsi Bayar di Tempat (COD / Tunai)</span>
                            <span class="text-xs text-slate-500 block">Pembayaran tunai langsung saat janji temu atau serah terima barang sewaan. Status pesanan baru dianggap lunas setelah konfirmasi manual Anda.</span>
                        </div>
                    </label>
                </div>
            </div>

            <!-- Upload Produk / Jasa Pertama (Opsional & Praktis) -->
            <div class="bg-gradient-to-br from-pink-50/50 to-rose-50/30 p-5 rounded-2xl border border-pink-200">
                <div class="flex items-center justify-between border-b border-pink-200/80 pb-3 mb-4">
                    <div>
                        <h2 class="text-base font-bold text-slate-900 flex items-center space-x-2">
                            <i class="fa-solid fa-cloud-arrow-up text-brand-600"></i>
                            <span>4. Upload Produk / Jasa Pertama Anda (Opsional)</span>
                        </h2>
                        <p class="text-xs text-slate-500 mt-0.5">
                            Ingin langsung berjualan? Tambahkan produk kosmetik, jasa rias, atau aset sewa perdana Anda sekarang.
                        </p>
                    </div>
                </div>

                <div class="space-y-4">
                    <div>
                        <label for="initial_product_name" class="block text-xs font-bold text-slate-700">Nama Produk / Layanan Rias</label>
                        <input type="text" id="initial_product_name" name="initial_product_name" value="{{ old('initial_product_name') }}"
                               placeholder="Contoh: Paket Makeup Pengantin Solo Putri / Lip Cream Matte"
                               class="mt-1 w-full px-3.5 py-2 rounded-lg border border-slate-300 text-xs focus:ring-2 focus:ring-brand-500 focus:outline-none">
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <div>
                            <label for="initial_product_type" class="block text-xs font-bold text-slate-700">Tipe Listing</label>
                            <select id="initial_product_type" name="initial_product_type" onchange="toggleTypeFields(this.value)"
                                    class="mt-1 w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-2 focus:ring-brand-500">
                                <option value="service" {{ old('initial_product_type') === 'service' ? 'selected' : '' }}>Jasa Make-Up Artist (MUA)</option>
                                <option value="physical" {{ old('initial_product_type') === 'physical' ? 'selected' : '' }}>Produk Kosmetik / Fisik</option>
                                <option value="rental" {{ old('initial_product_type') === 'rental' ? 'selected' : '' }}>Sewa Tenda & Perlengkapan</option>
                            </select>
                        </div>

                        <div>
                            <label for="initial_category_id" class="block text-xs font-bold text-slate-700">Kategori <span class="text-rose-500">*</span></label>
                            <select id="initial_category_id" name="initial_category_id" required
                                    class="mt-1 w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-2 focus:ring-brand-500">
                                @forelse($categories as $cat)
                                    <option value="{{ $cat->id }}" data-type="{{ $cat->type }}" {{ old('initial_category_id') == $cat->id ? 'selected' : '' }}>
                                        {{ $cat->name }}
                                    </option>
                                @empty
                                    <!-- Fallback categories if database was not seeded -->
                                    <option value="1" data-type="service">MUA Pernikahan & Akad</option>
                                    <option value="2" data-type="service">MUA Wisuda & Pesta</option>
                                    <option value="3" data-type="service">MUA Resepsi & Baju Adat</option>
                                    <option value="4" data-type="service">MUA Lamaran & Prewedding</option>
                                    <option value="5" data-type="product">Foundation & Bedak</option>
                                    <option value="6" data-type="product">Lipstik & Lipcream</option>
                                    <option value="7" data-type="product">Kuas & Alat Rias</option>
                                    <option value="8" data-type="rental">Sewa Tenda Dekorasi VIP</option>
                                    <option value="9" data-type="rental">Sewa Kursi & Panggung</option>
                                @endforelse
                            </select>
                        </div>

                        <div>
                            <label for="initial_base_price" class="block text-xs font-bold text-slate-700">Harga Dasar (Rp)</label>
                            <input type="number" id="initial_base_price" name="initial_base_price" value="{{ old('initial_base_price', '500000') }}" min="0" step="5000"
                                   placeholder="500000"
                                   class="mt-1 w-full px-3.5 py-2 rounded-lg border border-slate-300 text-xs focus:ring-2 focus:ring-brand-500">
                        </div>
                    </div>

                    <!-- Dynamic Fields based on Type -->
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 bg-white/80 rounded-xl border border-pink-100">
                        <div id="service_fields">
                            <label for="initial_duration_minutes" class="block text-xs font-bold text-slate-700">Durasi Pengerjaan Rias (Menit)</label>
                            <input type="number" id="initial_duration_minutes" name="initial_duration_minutes" value="{{ old('initial_duration_minutes', '120') }}" min="15" step="15"
                                   class="mt-1 w-full px-3 py-1.5 rounded-lg border border-slate-300 text-xs">
                            <span class="text-[10px] text-slate-400">Durasi untuk scheduler anti-bentrok jadwal MUA.</span>
                        </div>

                        <div id="stock_fields" style="display: none;">
                            <label for="initial_stock" class="block text-xs font-bold text-slate-700">Jumlah Stok / Unit Tersedia</label>
                            <input type="number" id="initial_stock" name="initial_stock" value="{{ old('initial_stock', '10') }}" min="1"
                                   class="mt-1 w-full px-3 py-1.5 rounded-lg border border-slate-300 text-xs">
                        </div>

                        <div id="deposit_fields" style="display: none;">
                            <label for="initial_deposit_amount" class="block text-xs font-bold text-slate-700">Uang Jaminan / Deposit Sewa (Rp)</label>
                            <input type="number" id="initial_deposit_amount" name="initial_deposit_amount" value="{{ old('initial_deposit_amount', '200000') }}" min="0"
                                   class="mt-1 w-full px-3 py-1.5 rounded-lg border border-slate-300 text-xs">
                        </div>

                        <div>
                            <label for="initial_image" class="block text-xs font-bold text-slate-700">Foto Utama Produk / Jasa</label>
                            <input type="file" id="initial_image" name="initial_image" accept="image/jpeg,image/png,image/webp"
                                   class="mt-1 w-full text-xs file:mr-2 file:py-1 file:px-3 file:rounded-md file:border-0 file:text-xs file:font-semibold file:bg-brand-50 file:text-brand-700 hover:file:bg-brand-100">
                            <span class="text-[10px] text-slate-400">JPG, PNG, atau WebP (Maks. 2MB).</span>
                        </div>
                    </div>

                    <div>
                        <label for="initial_description" class="block text-xs font-bold text-slate-700">Keterangan / Rincian Produk / Jasa</label>
                        <textarea id="initial_description" name="initial_description" rows="2"
                                  placeholder="Rincian paket rias, fasilitas yang didapat, atau spesifikasi barang..."
                                  class="mt-1 w-full px-3.5 py-2 rounded-lg border border-slate-300 text-xs focus:ring-2 focus:ring-brand-500">{{ old('initial_description') }}</textarea>
                    </div>
                </div>
            </div>

            <script>
                function toggleTypeFields(type) {
                    const serviceDiv = document.getElementById('service_fields');
                    const stockDiv = document.getElementById('stock_fields');
                    const depositDiv = document.getElementById('deposit_fields');
                    const catSelect = document.getElementById('initial_category_id');

                    if (type === 'service') {
                        serviceDiv.style.display = 'block';
                        stockDiv.style.display = 'none';
                        depositDiv.style.display = 'none';
                    } else if (type === 'rental') {
                        serviceDiv.style.display = 'none';
                        stockDiv.style.display = 'block';
                        depositDiv.style.display = 'block';
                    } else { // physical
                        serviceDiv.style.display = 'none';
                        stockDiv.style.display = 'block';
                        depositDiv.style.display = 'none';
                    }

                    // Dynamically filter categories based on type
                    if (catSelect) {
                        const targetType = (type === 'physical') ? 'product' : type;
                        let firstVisible = null;

                        for (let i = 0; i < catSelect.options.length; i++) {
                            const opt = catSelect.options[i];
                            const optType = opt.getAttribute('data-type');
                            if (!optType || optType === targetType || optType === 'all') {
                                opt.style.display = '';
                                if (!firstVisible) firstVisible = opt;
                            } else {
                                opt.style.display = 'none';
                            }
                        }

                        // Select the first valid category if current selection is hidden
                        if (firstVisible && (!catSelect.value || catSelect.selectedOptions[0]?.style.display === 'none')) {
                            catSelect.value = firstVisible.value;
                        }
                    }
                }
                document.addEventListener('DOMContentLoaded', () => {
                    const typeSel = document.getElementById('initial_product_type');
                    if (typeSel) toggleTypeFields(typeSel.value);
                });
            </script>

            <div class="flex justify-end pt-4 border-t">
                <button type="submit" class="px-6 py-2.5 bg-brand-600 hover:bg-brand-700 text-white font-medium rounded-lg shadow-sm transition">
                    Selesaikan Pendaftaran Studio
                </button>
            </div>
        </form>
    </div>
</div>
@endsection
