@extends('layouts.app')

@section('content')
<div class="max-w-4xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
    <div class="mb-6 flex items-center justify-between">
        <div>
            <div class="flex items-center space-x-2 text-xs text-slate-500 mb-1">
                <a href="{{ route('provider.dashboard') }}" class="hover:underline">Dashboard Studio</a>
                <span>&rsaquo;</span>
                <span class="text-slate-800 font-semibold">Pengaturan Profil Studio</span>
            </div>
            <h1 class="text-2xl font-black text-slate-900">Profil Studio & Identitas Usaha</h1>
            <p class="text-xs text-slate-500 mt-0.5">Kelola identitas publik, titik koordinat peta, dan metode pembayaran yang Anda terima.</p>
        </div>

        <a href="{{ route('provider.dashboard') }}" class="text-xs font-semibold text-slate-500 hover:text-slate-800">
            &larr; Kembali ke Dashboard
        </a>
    </div>

    <form action="{{ route('provider.profile.update') }}" method="POST" enctype="multipart/form-data" class="space-y-6">
        @csrf
        @method('PUT')

        <!-- Identitas Utama -->
        <div class="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
            <h2 class="text-sm font-bold text-slate-900 border-b pb-3 mb-4">1. Identitas Studio & Kontak</h2>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div class="sm:col-span-2">
                    <label class="block text-xs font-semibold text-slate-700 mb-1">Nama Studio / Usaha MUA <span class="text-rose-500">*</span></label>
                    <input type="text" name="business_name" required value="{{ old('business_name', $provider->business_name) }}"
                           class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none">
                    @error('business_name') <p class="text-xs text-rose-500 mt-1">{{ $message }}</p> @enderror
                </div>

                <div class="sm:col-span-2">
                    <label class="block text-xs font-semibold text-slate-700 mb-1">Deskripsi & Keunggulan Layanan</label>
                    <textarea name="description" rows="3"
                              class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none">{{ old('description', $provider->description) }}</textarea>
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 mb-1">Nomor WhatsApp Usaha <span class="text-rose-500">*</span></label>
                    <input type="text" name="phone" required value="{{ old('phone', $provider->phone) }}"
                           class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none">
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 mb-1">Logo Studio (Maks 2MB)</label>
                    <input type="file" name="logo" accept="image/jpeg,image/png,image/webp"
                           class="w-full text-xs text-slate-500 file:mr-4 file:py-2 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-brand-50 file:text-brand-700 hover:file:bg-brand-100">
                </div>
            </div>
        </div>

        <!-- Lokasi & Peta -->
        <div class="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
            <h2 class="text-sm font-bold text-slate-900 border-b pb-3 mb-4">2. Lokasi Fisik & Tampilan Peta Publik</h2>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div class="sm:col-span-2">
                    <label class="block text-xs font-semibold text-slate-700 mb-1">Alamat Studio <span class="text-rose-500">*</span></label>
                    <input type="text" name="address" required value="{{ old('address', $provider->address) }}"
                           class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none">
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 mb-1">Kota / Kabupaten <span class="text-rose-500">*</span></label>
                    <input type="text" name="city" required value="{{ old('city', $provider->city) }}"
                           class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none">
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 mb-1">Provinsi</label>
                    <input type="text" name="province" value="{{ old('province', $provider->province) }}"
                           class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm">
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 mb-1">Latitude</label>
                    <input type="text" name="latitude" value="{{ old('latitude', $provider->latitude) }}"
                           class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm">
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 mb-1">Longitude</label>
                    <input type="text" name="longitude" value="{{ old('longitude', $provider->longitude) }}"
                           class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm">
                </div>

                <div class="sm:col-span-2 bg-slate-50 p-4 rounded-xl border border-slate-200">
                    <label class="flex items-start space-x-3 cursor-pointer">
                        <input type="checkbox" name="is_location_public" value="1" {{ old('is_location_public', $provider->is_location_public) ? 'checked' : '' }}
                               class="mt-1 h-4 w-4 rounded border-slate-300 text-brand-600 focus:ring-brand-500">
                        <div>
                            <span class="text-sm font-semibold text-slate-900">Publikasikan Lokasi di Peta MUAMAR</span>
                            <p class="text-xs text-slate-500">
                                Mengizinkan calon pelanggan melihat titik studio dan menghitung jarak jangkauan menuju lokasi acara.
                            </p>
                        </div>
                    </label>
                </div>
            </div>
        </div>

        <!-- Pembayaran -->
        <div class="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
            <h2 class="text-sm font-bold text-slate-900 border-b pb-3 mb-4">3. Opsi Pembayaran yang Diterima</h2>

            <div class="space-y-3">
                <label class="flex items-center space-x-3 p-3 bg-slate-50 rounded-lg border border-slate-200 cursor-pointer">
                    <input type="checkbox" name="qris_active" value="1" {{ old('qris_active', $provider->qris_active) ? 'checked' : '' }}
                           class="h-4 w-4 rounded border-slate-300 text-brand-600 focus:ring-brand-500">
                    <div>
                        <span class="text-sm font-semibold text-slate-800">Aktifkan Pembayaran QRIS Dinamis</span>
                        <span class="text-xs text-slate-500 block">Pelanggan dapat membayar via m-banking atau e-wallet nasional.</span>
                    </div>
                </label>

                <label class="flex items-center space-x-3 p-3 bg-slate-50 rounded-lg border border-slate-200 cursor-pointer">
                    <input type="checkbox" name="cod_active" value="1" {{ old('cod_active', $provider->cod_active) ? 'checked' : '' }}
                           class="h-4 w-4 rounded border-slate-300 text-brand-600 focus:ring-brand-500">
                    <div>
                        <span class="text-sm font-semibold text-slate-800">Aktifkan Pembayaran di Tempat (COD / Tunai)</span>
                        <span class="text-xs text-slate-500 block">Pelanggan dapat membayar tunai saat temu; pesanan tidak lunas sampai Anda konfirmasi.</span>
                    </div>
                </label>
            </div>
        </div>

        <div class="flex justify-end pt-4 border-t">
            <button type="submit" class="px-6 py-2.5 bg-brand-600 hover:bg-brand-700 text-white rounded-xl text-xs font-bold transition shadow-sm">
                Simpan Perubahan Profil Studio
            </button>
        </div>
    </form>
</div>
@endsection
