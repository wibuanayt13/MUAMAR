@extends('layouts.app')

@section('content')
<div class="max-w-4xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
    <div class="flex items-center justify-between mb-6">
        <div>
            <h1 class="text-2xl font-black text-slate-900 flex items-center space-x-2">
                <i class="fa-solid fa-bell text-brand-600"></i>
                <span>Pemberitahuan & Notifikasi</span>
            </h1>
            <p class="text-xs text-slate-500 mt-1">Dapatkan pembaruan status pesanan, pesan obrolan, dan informasi penting.</p>
        </div>

        @if(auth()->user()->unreadNotifications->count() > 0)
            <form action="{{ route('notifications.read-all') }}" method="POST">
                @csrf
                <button type="submit" class="text-xs font-semibold text-brand-600 hover:text-brand-700 bg-brand-50 hover:bg-brand-100 px-3 py-1.5 rounded-lg transition flex items-center space-x-1">
                    <i class="fa-solid fa-check-double"></i>
                    <span>Tandai Semua Dibaca</span>
                </button>
            </form>
        @endif
    </div>

    <div class="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm divide-y divide-slate-100">
        @forelse($notifications as $notif)
            @php
                $data = $notif->data;
                $isUnread = is_null($notif->read_at);
            @endphp
            <div class="p-4 sm:p-5 flex items-start justify-between gap-4 {{ $isUnread ? 'bg-pink-50/40' : 'bg-white' }} hover:bg-slate-50 transition">
                <div class="flex items-start space-x-3.5">
                    <div class="w-10 h-10 rounded-2xl flex items-center justify-center text-sm flex-shrink-0 mt-0.5
                        @if(($data['type'] ?? '') === 'order') bg-blue-100 text-blue-700
                        @elseif(($data['type'] ?? '') === 'chat') bg-pink-100 text-brand-600
                        @elseif(($data['type'] ?? '') === 'shipping') bg-indigo-100 text-indigo-700
                        @elseif(($data['type'] ?? '') === 'review') bg-amber-100 text-amber-700
                        @else bg-emerald-100 text-emerald-700 @endif">
                        @if(($data['type'] ?? '') === 'order') <i class="fa-solid fa-bag-shopping"></i>
                        @elseif(($data['type'] ?? '') === 'chat') <i class="fa-solid fa-comment"></i>
                        @elseif(($data['type'] ?? '') === 'shipping') <i class="fa-solid fa-truck-fast"></i>
                        @elseif(($data['type'] ?? '') === 'review') <i class="fa-solid fa-star"></i>
                        @else <i class="fa-solid fa-bell"></i> @endif
                    </div>
                    <div>
                        <div class="flex items-center space-x-2">
                            <h3 class="text-sm font-bold text-slate-900">{{ $data['title'] ?? 'Pemberitahuan' }}</h3>
                            @if($isUnread)
                                <span class="w-2 h-2 rounded-full bg-brand-600"></span>
                            @endif
                        </div>
                        <p class="text-xs text-slate-600 mt-1 leading-relaxed">{{ $data['message'] ?? '' }}</p>
                        <span class="text-[10px] text-slate-400 mt-1.5 block">
                            {{ $notif->created_at->diffForHumans() }}
                        </span>
                    </div>
                </div>

                <div class="flex-shrink-0 flex items-center space-x-2">
                    @if(!empty($data['action_url']))
                        <form action="{{ route('notifications.read', $notif->id) }}" method="POST">
                            @csrf
                            <button type="submit" class="px-3 py-1.5 bg-brand-600 hover:bg-brand-700 text-white rounded-lg text-xs font-semibold transition">
                                Lihat Rincian &rarr;
                            </button>
                        </form>
                    @endif
                </div>
            </div>
        @empty
            <div class="text-center py-12 text-slate-400">
                <i class="fa-regular fa-bell-slash text-4xl mb-2 text-slate-300"></i>
                <p class="text-sm">Belum ada notifikasi saat ini.</p>
                <p class="text-xs text-slate-400 mt-1">Aktivitas pesanan dan percakapan Anda akan muncul di sini.</p>
            </div>
        @endforelse
    </div>

    <div class="mt-4">
        {{ $notifications->links() }}
    </div>
</div>
@endsection
