@extends('layouts.app')

@section('content')
<div class="min-h-[75vh] flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
    <div class="max-w-md w-full space-y-8 bg-white p-8 rounded-2xl shadow-sm border border-slate-200">
        <div class="text-center">
            <div class="w-16 h-16 bg-brand-50 text-brand-600 rounded-full flex items-center justify-center mx-auto mb-3 text-2xl">
                <i class="fa-solid fa-user-plus"></i>
            </div>
            <h2 class="text-2xl font-bold text-slate-900">Daftar Akun Baru</h2>
            <p class="mt-2 text-sm text-slate-500">
                Pilih peran Anda untuk mulai menggunakan ekosistem MUAMAR.
            </p>
        </div>

        <form class="mt-6 space-y-4" action="{{ route('register.post') }}" method="POST">
            @csrf

            <!-- Role Selector -->
            <div>
                <label class="block text-sm font-medium text-slate-700 mb-2">Daftar Sebagai:</label>
                <div class="grid grid-cols-2 gap-3">
                    <label class="cursor-pointer border rounded-xl p-3 flex flex-col items-center text-center space-y-1 hover:border-brand-500 transition has-[:checked]:border-brand-600 has-[:checked]:bg-brand-50/50">
                        <input type="radio" name="role" value="customer" class="sr-only" checked>
                        <i class="fa-solid fa-bag-shopping text-brand-600 text-lg"></i>
                        <span class="text-sm font-semibold text-slate-800">Pelanggan</span>
                        <span class="text-xs text-slate-500">Cari jasa MUA & sewa alat</span>
                    </label>

                    <label class="cursor-pointer border rounded-xl p-3 flex flex-col items-center text-center space-y-1 hover:border-brand-500 transition has-[:checked]:border-brand-600 has-[:checked]:bg-brand-50/50">
                        <input type="radio" name="role" value="provider" class="sr-only" {{ old('role') === 'provider' ? 'checked' : '' }}>
                        <i class="fa-solid fa-wand-magic-sparkles text-brand-600 text-lg"></i>
                        <span class="text-sm font-semibold text-slate-800">MUA / Vendor</span>
                        <span class="text-xs text-slate-500">Tawarkan jasa rias & sewa</span>
                    </label>
                </div>
            </div>

            <div>
                <label for="name" class="block text-sm font-medium text-slate-700">Nama Lengkap</label>
                <input id="name" name="name" type="text" required value="{{ old('name') }}"
                       class="mt-1 w-full px-4 py-2.5 rounded-lg border @error('name') border-rose-500 @else border-slate-300 @enderror text-slate-900 focus:outline-none focus:ring-2 focus:ring-brand-500 text-sm"
                       placeholder="Nama lengkap Anda">
                @error('name')
                    <p class="mt-1 text-xs text-rose-600">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label for="email" class="block text-sm font-medium text-slate-700">Alamat Email</label>
                <input id="email" name="email" type="email" autocomplete="email" required value="{{ old('email') }}"
                       class="mt-1 w-full px-4 py-2.5 rounded-lg border @error('email') border-rose-500 @else border-slate-300 @enderror text-slate-900 focus:outline-none focus:ring-2 focus:ring-brand-500 text-sm"
                       placeholder="nama@email.com">
                @error('email')
                    <p class="mt-1 text-xs text-rose-600">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label for="phone" class="block text-sm font-medium text-slate-700">Nomor WhatsApp / HP</label>
                <input id="phone" name="phone" type="text" required value="{{ old('phone') }}"
                       class="mt-1 w-full px-4 py-2.5 rounded-lg border @error('phone') border-rose-500 @else border-slate-300 @enderror text-slate-900 focus:outline-none focus:ring-2 focus:ring-brand-500 text-sm"
                       placeholder="Contoh: 081234567890">
                @error('phone')
                    <p class="mt-1 text-xs text-rose-600">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label for="password" class="block text-sm font-medium text-slate-700">Kata Sandi (Minimal 8 Karakter)</label>
                <input id="password" name="password" type="password" required
                       class="mt-1 w-full px-4 py-2.5 rounded-lg border @error('password') border-rose-500 @else border-slate-300 @enderror text-slate-900 focus:outline-none focus:ring-2 focus:ring-brand-500 text-sm"
                       placeholder="••••••••">
                @error('password')
                    <p class="mt-1 text-xs text-rose-600">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label for="password_confirmation" class="block text-sm font-medium text-slate-700">Konfirmasi Kata Sandi</label>
                <input id="password_confirmation" name="password_confirmation" type="password" required
                       class="mt-1 w-full px-4 py-2.5 rounded-lg border border-slate-300 text-slate-900 focus:outline-none focus:ring-2 focus:ring-brand-500 text-sm"
                       placeholder="••••••••">
            </div>

            <div>
                <button type="submit"
                        class="w-full flex justify-center py-2.5 px-4 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-brand-600 hover:bg-brand-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-500 transition">
                    Daftar Sekarang
                </button>
            </div>
        </form>

        <div class="text-center text-sm text-slate-600">
            Sudah memiliki akun?
            <a href="{{ route('login') }}" class="font-semibold text-brand-600 hover:text-brand-500">Masuk di sini</a>
        </div>
    </div>
</div>
@endsection
