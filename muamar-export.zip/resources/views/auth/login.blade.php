@extends('layouts.app')

@section('content')
<div class="min-h-[75vh] flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
    <div class="max-w-md w-full space-y-8 bg-white p-8 rounded-2xl shadow-sm border border-slate-200">
        <div class="text-center">
            <div class="w-16 h-16 bg-brand-50 text-brand-600 rounded-full flex items-center justify-center mx-auto mb-3 text-2xl">
                <i class="fa-solid fa-wand-magic-sparkles"></i>
            </div>
            <h2 class="text-2xl font-bold text-slate-900">Masuk ke Akun MUAMAR</h2>
            <p class="mt-2 text-sm text-slate-500">
                Akses dashboard pemesanan jasa MUA, sewa tenda, dan produk makeup.
            </p>
        </div>

        <form class="mt-6 space-y-5" action="{{ route('login.post') }}" method="POST">
            @csrf

            <div>
                <label for="email" class="block text-sm font-medium text-slate-700">Alamat Email</label>
                <div class="mt-1 relative">
                    <input id="email" name="email" type="email" autocomplete="email" required
                           value="{{ old('email') }}"
                           class="w-full px-4 py-2.5 rounded-lg border @error('email') border-rose-500 @else border-slate-300 @enderror text-slate-900 focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-brand-500 text-sm"
                           placeholder="nama@email.com">
                </div>
                @error('email')
                    <p class="mt-1 text-xs text-rose-600">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label for="password" class="block text-sm font-medium text-slate-700">Kata Sandi</label>
                <div class="mt-1 relative">
                    <input id="password" name="password" type="password" autocomplete="current-password" required
                           class="w-full px-4 py-2.5 rounded-lg border @error('password') border-rose-500 @else border-slate-300 @enderror text-slate-900 focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-brand-500 text-sm"
                           placeholder="••••••••">
                </div>
                @error('password')
                    <p class="mt-1 text-xs text-rose-600">{{ $message }}</p>
                @enderror
            </div>

            <div class="flex items-center justify-between text-sm">
                <label class="flex items-center text-slate-600">
                    <input type="checkbox" name="remember" value="1" class="h-4 w-4 rounded border-slate-300 text-brand-600 focus:ring-brand-500">
                    <span class="ml-2">Ingat saya</span>
                </label>
            </div>

            <div>
                <button type="submit"
                        class="w-full flex justify-center py-2.5 px-4 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-brand-600 hover:bg-brand-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-500 transition">
                    Masuk Sekarang
                </button>
            </div>
        </form>

        <!-- Demo Accounts Box for quick reviewer access -->
        <div class="mt-6 border-t border-slate-100 pt-4 bg-slate-50 p-4 rounded-xl text-xs text-slate-600 space-y-2">
            <p class="font-semibold text-slate-800">Akun Pengujian / Demo Cepat (Password: <code>password</code>):</p>
            <ul class="list-disc list-inside space-y-1">
                <li><strong>Admin</strong>: <code>admin@muamar.test</code></li>
                <li><strong>MUA Vendor</strong>: <code>tasya@provider.test</code></li>
                <li><strong>Rental Vendor</strong>: <code>bella@provider.test</code></li>
                <li><strong>Customer</strong>: <code>siti@customer.test</code></li>
            </ul>
        </div>

        <div class="text-center text-sm text-slate-600">
            Belum punya akun?
            <a href="{{ route('register') }}" class="font-semibold text-brand-600 hover:text-brand-500">Daftar sekarang</a>
        </div>
    </div>
</div>
@endsection
