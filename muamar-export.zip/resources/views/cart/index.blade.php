@extends('layouts.app')

@section('content')
<div class="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
    <div class="mb-6 flex items-center justify-between">
        <h1 class="text-2xl font-black text-slate-900 flex items-center space-x-2">
            <i class="fa-solid fa-bag-shopping text-brand-600"></i>
            <span>Keranjang Belanja Multi-Vendor</span>
        </h1>
        <a href="{{ route('catalog.index') }}" class="text-xs font-semibold text-brand-600 hover:underline">
            &larr; Lanjut Eksplorasi Katalog
        </a>
    </div>

    @if($itemsByProvider->isEmpty())
        <div class="bg-white rounded-3xl border border-slate-200 p-12 text-center shadow-sm">
            <div class="w-20 h-20 bg-pink-50 text-brand-500 rounded-full flex items-center justify-center mx-auto mb-4 text-3xl">
                <i class="fa-solid fa-cart-shopping"></i>
            </div>
            <h2 class="text-lg font-bold text-slate-800">Keranjang Belanja Anda Masih Kosong</h2>
            <p class="text-xs text-slate-500 max-w-sm mx-auto mt-1">
                Jelajahi berbagai paket makeup pengantin, makeup wisuda, kosmetik, atau sewa tenda dekorasi impian Anda.
            </p>
            <a href="{{ route('catalog.index') }}" class="mt-6 inline-block px-6 py-2.5 bg-brand-600 hover:bg-brand-700 text-white font-semibold text-sm rounded-xl transition shadow">
                Mulai Belanja
            </a>
        </div>
    @else
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <!-- Items grouped by vendor -->
            <div class="lg:col-span-2 space-y-6">
                @foreach($itemsByProvider as $providerId => $items)
                    @php $provider = $items->first()->product->provider; @endphp
                    <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                        <!-- Vendor Header -->
                        <div class="bg-slate-50 px-5 py-3 border-b border-slate-200 flex items-center justify-between">
                            <div class="flex items-center space-x-2">
                                <i class="fa-solid fa-store text-brand-600 text-sm"></i>
                                <span class="font-bold text-slate-900 text-sm">{{ $provider->business_name }}</span>
                                <span class="text-xs text-slate-400">({{ $provider->city }})</span>
                            </div>
                        </div>

                        <!-- Vendor Items -->
                        <div class="divide-y divide-slate-100 p-5">
                            @foreach($items as $item)
                                @php
                                    $unitPrice = $item->variant ? $item->variant->price : $item->product->base_price;
                                    $subtotal = $unitPrice * $item->quantity;
                                    $deposit = ($item->item_type === 'rental' && $item->product->rentalProfile) ? $item->product->rentalProfile->deposit_amount * $item->quantity : 0;
                                @endphp
                                <div class="py-4 first:pt-0 last:pb-0 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                                    <div class="flex items-start space-x-4">
                                        <img src="{{ is_array($item->product->images) ? $item->product->images[0] : 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=600' }}"
                                             alt="{{ $item->product->name }}" class="w-16 h-16 rounded-xl object-cover border border-slate-200">
                                        <div>
                                            <span class="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded
                                                @if($item->item_type === 'service') bg-brand-50 text-brand-700
                                                @elseif($item->item_type === 'rental') bg-indigo-50 text-indigo-700
                                                @else bg-emerald-50 text-emerald-700 @endif">
                                                {{ $item->item_type }}
                                            </span>
                                            <h3 class="font-bold text-slate-900 text-sm mt-1">{{ $item->product->name }}</h3>
                                            @if($item->variant)
                                                <p class="text-xs text-slate-500">Varian: <strong>{{ $item->variant->variant_name }}</strong></p>
                                            @endif
                                            @if($item->booking_start)
                                                <p class="text-xs text-brand-600 mt-1 font-semibold">
                                                    <i class="fa-regular fa-clock mr-1"></i>
                                                    {{ $item->booking_start->format('d M Y, H:i') }}
                                                    @if($item->booking_end) - {{ $item->booking_end->format('d M Y, H:i') }} @endif
                                                </p>
                                            @endif
                                            @if($deposit > 0)
                                                <p class="text-xs text-indigo-600 mt-0.5">Uang Jaminan: Rp {{ number_format($deposit, 0, ',', '.') }}</p>
                                            @endif
                                        </div>
                                    </div>

                                    <div class="flex items-center justify-between sm:justify-end sm:space-x-6">
                                        <!-- Quantity Adjust Form -->
                                        @if($item->item_type !== 'service')
                                            <form action="{{ route('cart.update', $item->id) }}" method="POST" class="flex items-center space-x-1">
                                                @csrf
                                                @method('PATCH')
                                                <input type="number" name="quantity" value="{{ $item->quantity }}" min="1" max="100"
                                                       class="w-14 px-2 py-1 text-center text-xs border border-slate-300 rounded focus:ring-1 focus:ring-brand-500">
                                                <button type="submit" class="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs rounded font-medium" title="Update Jumlah">
                                                    <i class="fa-solid fa-check text-[10px]"></i>
                                                </button>
                                            </form>
                                        @else
                                            <span class="text-xs text-slate-500 font-semibold">{{ $item->quantity }} Sesi</span>
                                        @endif

                                        <div class="text-right">
                                            <span class="text-xs text-slate-400 block">@ Rp {{ number_format($unitPrice, 0, ',', '.') }}</span>
                                            <span class="font-bold text-slate-900 text-sm">Rp {{ number_format($subtotal + $deposit, 0, ',', '.') }}</span>
                                        </div>

                                        <form action="{{ route('cart.remove', $item->id) }}" method="POST">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="p-2 text-slate-400 hover:text-rose-600 transition" title="Hapus dari keranjang">
                                                <i class="fa-solid fa-trash-can"></i>
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div>
                @endforeach
            </div>

            <!-- Summary Sidebar -->
            <div class="lg:col-span-1">
                <div class="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm sticky top-20">
                    <h2 class="text-base font-bold text-slate-900 border-b pb-3 mb-4">Ringkasan Belanja</h2>

                    <div class="space-y-3 text-sm">
                        <div class="flex justify-between text-slate-600">
                            <span>Total Estimasi</span>
                            <span class="font-bold text-slate-900">Rp {{ number_format($totalEstimate, 0, ',', '.') }}</span>
                        </div>
                        <div class="flex justify-between text-xs text-slate-500">
                            <span>Biaya Pengiriman Fisik</span>
                            <span class="italic text-slate-400">Dihitung saat checkout</span>
                        </div>
                    </div>

                    <div class="border-t pt-4 mt-4">
                        <div class="flex justify-between text-base font-black text-slate-900 mb-4">
                            <span>Total Tagihan:</span>
                            <span class="text-brand-600">Rp {{ number_format($totalEstimate, 0, ',', '.') }}</span>
                        </div>

                        <a href="{{ route('checkout.show') }}" class="w-full py-3 bg-brand-600 hover:bg-brand-700 text-white font-bold text-sm rounded-xl transition shadow flex items-center justify-center space-x-2">
                            <span>Lanjut ke Pembayaran</span>
                            <i class="fa-solid fa-arrow-right"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    @endif
</div>
@endsection
