@extends('layouts.app')

@section('content')
<div class="max-w-4xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
    <div class="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm flex flex-col h-[700px]">
        <!-- Chat Header -->
        <div class="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
            <div class="flex items-center space-x-3">
                <a href="{{ route('chat.index') }}" class="p-2 text-slate-400 hover:text-slate-700 transition" title="Kembali ke Daftar Chat">
                    <i class="fa-solid fa-arrow-left"></i>
                </a>
                <div>
                    <h2 class="font-bold text-slate-900 text-sm">
                        {{ $conversation->customer_id === $user->id ? $conversation->provider->business_name : $conversation->customer->name }}
                    </h2>
                    @if($conversation->product)
                        <p class="text-xs text-brand-600">Konsultasi: {{ $conversation->product->name }}</p>
                    @endif
                </div>
            </div>

            @if($conversation->product)
                <a href="{{ route('catalog.show', $conversation->product->slug) }}" class="text-xs font-semibold text-brand-600 hover:underline">
                    Lihat Listing &rarr;
                </a>
            @endif
        </div>

        <!-- Messages Thread -->
        <div class="flex-grow p-6 overflow-y-auto space-y-4 bg-slate-50/50" id="chat-thread">
            @forelse($conversation->messages as $msg)
                @php $isMe = ($msg->sender_id === $user->id); @endphp
                <div class="flex {{ $isMe ? 'justify-end' : 'justify-start' }}">
                    <div class="max-w-md {{ $isMe ? 'bg-brand-600 text-white rounded-l-2xl rounded-tr-2xl' : 'bg-white text-slate-800 border border-slate-200 rounded-r-2xl rounded-tl-2xl' }} p-4 shadow-sm text-sm">
                        <p class="leading-relaxed">{{ $msg->message }}</p>
                        <span class="block text-[10px] mt-1.5 {{ $isMe ? 'text-pink-100 text-right' : 'text-slate-400' }}">
                            {{ $msg->created_at->format('H:i') }}
                        </span>
                    </div>
                </div>
            @empty
                <div class="text-center py-12 text-slate-400 text-xs">
                    Mulai percakapan dengan mengirim pesan pertama di bawah.
                </div>
            @endforelse
        </div>

        <!-- Chat Input Form -->
        <div class="p-4 bg-white border-t border-slate-200">
            <form action="{{ route('chat.send', $conversation->id) }}" method="POST" class="flex items-center space-x-3">
                @csrf
                <input type="text" name="message" required placeholder="Ketik pesan / pertanyaan konsultasi Anda..."
                       class="flex-grow px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none">
                <button type="submit" class="px-5 py-2.5 bg-brand-600 hover:bg-brand-700 text-white rounded-xl text-sm font-semibold transition shadow flex items-center space-x-1">
                    <span>Kirim</span>
                    <i class="fa-solid fa-paper-plane text-xs"></i>
                </button>
            </form>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const thread = document.getElementById('chat-thread');
        if (thread) {
            thread.scrollTop = thread.scrollHeight;
        }
    });
</script>
@endsection
