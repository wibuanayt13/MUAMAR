@extends('layouts.app')

@section('content')
<div class="max-w-4xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
    <div class="mb-6">
        <h1 class="text-2xl font-black text-slate-900 flex items-center space-x-2">
            <i class="fa-solid fa-comments text-brand-600"></i>
            <span>Pesan & Konsultasi Rias</span>
        </h1>
        <p class="text-xs text-slate-500 mt-1">Komunikasi langsung antara pelanggan dan studio Make-Up Artist / penyedia perlengkapan.</p>
    </div>

    <div class="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm divide-y divide-slate-100">
        @forelse($conversations as $conv)
            @php
                $isCust = ($conv->customer_id === auth()->id());
                $opponentName = $isCust ? $conv->provider->business_name : $conv->customer->name;
                $lastMsg = $conv->messages->first();
            @endphp
            <a href="{{ route('chat.show', $conv->id) }}" class="p-5 flex items-center justify-between hover:bg-slate-50 transition block">
                <div class="flex items-center space-x-4">
                    <div class="w-12 h-12 bg-pink-100 text-brand-600 rounded-2xl flex items-center justify-center font-bold text-lg">
                        <i class="fa-solid {{ $isCust ? 'fa-store' : 'fa-user' }}"></i>
                    </div>
                    <div>
                        <div class="flex items-center space-x-2">
                            <h3 class="font-bold text-slate-900 text-sm">{{ $opponentName }}</h3>
                            @if($conv->product)
                                <span class="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded">
                                    {{ Str::limit($conv->product->name, 20) }}
                                </span>
                            @endif
                        </div>
                        <p class="text-xs text-slate-500 mt-1 line-clamp-1">
                            {{ $lastMsg ? $lastMsg->message : 'Belum ada pesan.' }}
                        </p>
                    </div>
                </div>

                <div class="text-right text-xs text-slate-400">
                    <span>{{ $conv->last_message_at ? $conv->last_message_at->diffForHumans() : '' }}</span>
                </div>
            </a>
        @empty
            <div class="p-12 text-center text-slate-400 text-sm">
                <i class="fa-regular fa-comment-dots text-4xl mb-2"></i>
                <p>Belum ada percakapan aktif.</p>
                <p class="text-xs text-slate-400 mt-1">Anda dapat memulai chat dari tombol "Chat Penjual" di halaman detail produk/layanan.</p>
            </div>
        @endforelse
    </div>
</div>
@endsection
