<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class RentalBooking extends Model
{
    use HasFactory;

    protected $fillable = [
        'vendor_order_id',
        'order_item_id',
        'provider_id',
        'customer_id',
        'product_id',
        'start_date',
        'end_date',
        'buffer_end_date',
        'quantity_rented',
        'deposit_amount',
        'status',
        'hold_expires_at',
        'returned_at',
        'deposit_returned_at',
    ];

    protected function casts(): array
    {
        return [
            'start_date' => 'datetime',
            'end_date' => 'datetime',
            'buffer_end_date' => 'datetime',
            'hold_expires_at' => 'datetime',
            'returned_at' => 'datetime',
            'deposit_returned_at' => 'datetime',
            'quantity_rented' => 'integer',
            'deposit_amount' => 'integer',
        ];
    }

    public function vendorOrder(): BelongsTo
    {
        return $this->belongsTo(VendorOrder::class, 'vendor_order_id');
    }

    public function orderItem(): BelongsTo
    {
        return $this->belongsTo(OrderItem::class, 'order_item_id');
    }

    public function provider(): BelongsTo
    {
        return $this->belongsTo(Provider::class, 'provider_id');
    }

    public function customer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'customer_id');
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class, 'product_id');
    }

    public function scopeActive(Builder $query): Builder
    {
        return $query->where(function ($q) {
            $q->whereIn('status', ['confirmed', 'picked_up'])
                ->orWhere(function ($holdQuery) {
                    $holdQuery->where('status', 'hold')
                        ->where('hold_expires_at', '>', Carbon::now('UTC'));
                });
        });
    }

    public function scopeOverlapping(Builder $query, $startUtc, $endUtc): Builder
    {
        return $query->where('start_date', '<', $endUtc)
            ->where('buffer_end_date', '>', $startUtc);
    }
}
