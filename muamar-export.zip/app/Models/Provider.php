<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Provider extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'business_name',
        'slug',
        'description',
        'logo_url',
        'banner_url',
        'address',
        'city',
        'province',
        'postal_code',
        'latitude',
        'longitude',
        'is_location_public',
        'phone',
        'is_verified',
        'verification_notes',
        'status',
        'qris_active',
        'cod_active',
    ];

    protected function casts(): array
    {
        return [
            'latitude' => 'decimal:7',
            'longitude' => 'decimal:7',
            'is_location_public' => 'boolean',
            'is_verified' => 'boolean',
            'qris_active' => 'boolean',
            'cod_active' => 'boolean',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function products(): HasMany
    {
        return $this->hasMany(Product::class, 'provider_id');
    }

    public function vendorOrders(): HasMany
    {
        return $this->hasMany(VendorOrder::class, 'provider_id');
    }

    public function availabilities(): HasMany
    {
        return $this->hasMany(ProviderAvailability::class, 'provider_id');
    }

    public function scheduleOverrides(): HasMany
    {
        return $this->hasMany(ProviderScheduleOverride::class, 'provider_id');
    }

    public function conversations(): HasMany
    {
        return $this->hasMany(Conversation::class, 'provider_id');
    }

    public function reviews(): HasMany
    {
        return $this->hasMany(Review::class, 'provider_id');
    }

    public function serviceBookings(): HasMany
    {
        return $this->hasMany(ServiceBooking::class, 'provider_id');
    }

    public function rentalBookings(): HasMany
    {
        return $this->hasMany(RentalBooking::class, 'provider_id');
    }

    public function scopeApproved(Builder $query): Builder
    {
        return $query->where('status', 'approved');
    }

    public function scopePublicOnMap(Builder $query): Builder
    {
        return $query->where('status', 'approved')
            ->where('is_location_public', true)
            ->whereNotNull('latitude')
            ->whereNotNull('longitude');
    }
}
