<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class RentalProfile extends Model
{
    use HasFactory;

    protected $fillable = [
        'product_id',
        'total_units',
        'deposit_amount',
        'min_rental_days',
        'buffer_hours',
        'unit_type',
    ];

    protected function casts(): array
    {
        return [
            'total_units' => 'integer',
            'deposit_amount' => 'integer',
            'min_rental_days' => 'integer',
            'buffer_hours' => 'integer',
        ];
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class, 'product_id');
    }
}
