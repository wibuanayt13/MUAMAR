<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;

class OrderItem extends Model
{
    use HasFactory;

    protected $fillable = [
        'vendor_order_id',
        'product_id',
        'product_variant_id',
        'item_type',
        'name_snapshot',
        'variant_name_snapshot',
        'price_snapshot',
        'deposit_snapshot',
        'quantity',
        'subtotal',
        'metadata',
    ];

    protected function casts(): array
    {
        return [
            'price_snapshot' => 'integer',
            'deposit_snapshot' => 'integer',
            'quantity' => 'integer',
            'subtotal' => 'integer',
            'metadata' => 'array',
        ];
    }

    public function vendorOrder(): BelongsTo
    {
        return $this->belongsTo(VendorOrder::class, 'vendor_order_id');
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class, 'product_id');
    }

    public function variant(): BelongsTo
    {
        return $this->belongsTo(ProductVariant::class, 'product_variant_id');
    }

    public function serviceBooking(): HasOne
    {
        return $this->hasOne(ServiceBooking::class, 'order_item_id');
    }

    public function rentalBooking(): HasOne
    {
        return $this->hasOne(RentalBooking::class, 'order_item_id');
    }

    public function review(): HasOne
    {
        return $this->hasOne(Review::class, 'order_item_id');
    }
}
