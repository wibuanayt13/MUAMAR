<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ProviderScheduleOverride extends Model
{
    use HasFactory;

    protected $fillable = [
        'provider_id',
        'override_date',
        'is_off',
        'reason',
    ];

    protected function casts(): array
    {
        return [
            'override_date' => 'date',
            'is_off' => 'boolean',
        ];
    }

    public function provider(): BelongsTo
    {
        return $this->belongsTo(Provider::class, 'provider_id');
    }
}
