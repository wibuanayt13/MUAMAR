<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ServiceBooking extends Model
{
    use HasFactory;

    protected $fillable = [
        'vendor_order_id',
        'order_item_id',
        'provider_id',
        'customer_id',
        'product_id',
        'start_time',
        'end_time',
        'buffer_end_time',
        'status',
        'hold_expires_at',
        'notes',
    ];

    protected function casts(): array
    {
        return [
            'start_time' => 'datetime',
            'end_time' => 'datetime',
            'buffer_end_time' => 'datetime',
            'hold_expires_at' => 'datetime',
        ];
    }

    public function vendorOrder(): BelongsTo
    {
        return $this->belongsTo(VendorOrder::class, 'vendor_order_id');
    }

    public function orderItem(): BelongsTo
    {
        return $this->belongsTo(OrderItem::class, 'order_item_id');
    }

    public function provider(): BelongsTo
    {
        return $this->belongsTo(Provider::class, 'provider_id');
    }

    public function customer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'customer_id');
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class, 'product_id');
    }

    public function scopeActive(Builder $query): Builder
    {
        return $query->where(function ($q) {
            $q->whereIn('status', ['confirmed', 'in_progress'])
                ->orWhere(function ($holdQuery) {
                    $holdQuery->where('status', 'hold')
                        ->where('hold_expires_at', '>', Carbon::now('UTC'));
                });
        });
    }

    public function scopeOverlapping(Builder $query, $startUtc, $endUtc): Builder
    {
        return $query->where('start_time', '<', $endUtc)
            ->where('buffer_end_time', '>', $startUtc);
    }
}
