<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class VendorOrder extends Model
{
    use HasFactory;

    protected $fillable = [
        'vendor_order_number',
        'order_id',
        'provider_id',
        'subtotal',
        'deposit_subtotal',
        'shipping_cost',
        'total_amount',
        'status',
        'payment_status',
        'shipping_carrier',
        'tracking_number',
        'shipped_at',
        'delivered_at',
    ];

    protected function casts(): array
    {
        return [
            'subtotal' => 'integer',
            'deposit_subtotal' => 'integer',
            'shipping_cost' => 'integer',
            'total_amount' => 'integer',
            'shipped_at' => 'datetime',
            'delivered_at' => 'datetime',
        ];
    }

    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class, 'order_id');
    }

    public function provider(): BelongsTo
    {
        return $this->belongsTo(Provider::class, 'provider_id');
    }

    public function items(): HasMany
    {
        return $this->hasMany(OrderItem::class, 'vendor_order_id');
    }

    public function shippingHistories(): HasMany
    {
        return $this->hasMany(ShippingHistory::class, 'vendor_order_id')->orderBy('created_at', 'desc');
    }

    public function serviceBookings(): HasMany
    {
        return $this->hasMany(ServiceBooking::class, 'vendor_order_id');
    }

    public function rentalBookings(): HasMany
    {
        return $this->hasMany(RentalBooking::class, 'vendor_order_id');
    }
}
