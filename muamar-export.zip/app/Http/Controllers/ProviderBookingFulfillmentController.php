<?php

namespace App\Http\Controllers;

use App\Models\RentalBooking;
use App\Models\ServiceBooking;
use App\Services\BookingSchedulerService;
use App\Services\RentalSchedulerService;
use Exception;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class ProviderBookingFulfillmentController extends Controller
{
    public function __construct(
        protected BookingSchedulerService $bookingScheduler,
        protected RentalSchedulerService $rentalScheduler
    ) {}

    public function completeService(int $id): RedirectResponse
    {
        $booking = ServiceBooking::with('provider')->findOrFail($id);

        try {
            $this->bookingScheduler->completeBooking($booking, auth()->user());
            return back()->with('success', 'Layanan rias berhasil ditandai selesai.');
        } catch (Exception $e) {
            return back()->with('error', $e->getMessage());
        }
    }

    public function pickupRental(int $id): RedirectResponse
    {
        $rental = RentalBooking::with('provider')->findOrFail($id);

        try {
            $this->rentalScheduler->markPickedUp($rental, auth()->user());
            return back()->with('success', 'Barang sewaan berhasil diserahkan kepada penyewa.');
        } catch (Exception $e) {
            return back()->with('error', $e->getMessage());
        }
    }

    public function returnRental(Request $request, int $id): RedirectResponse
    {
        $rental = RentalBooking::with('provider')->findOrFail($id);
        $depositReturned = $request->boolean('deposit_returned', true);

        try {
            $this->rentalScheduler->markReturned($rental, auth()->user(), $depositReturned);
            return back()->with('success', 'Perlengkapan sewa telah dikembalikan dan status diperbarui.');
        } catch (Exception $e) {
            return back()->with('error', $e->getMessage());
        }
    }
}
