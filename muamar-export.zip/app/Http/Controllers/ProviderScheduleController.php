<?php

namespace App\Http\Controllers;

use App\Http\Requests\UpdateProviderScheduleRequest;
use App\Models\ProviderAvailability;
use App\Models\ProviderScheduleOverride;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class ProviderScheduleController extends Controller
{
    public function index(): View
    {
        $provider = auth()->user()->provider;
        if (!$provider) {
            abort(403, 'Akses ditolak.');
        }

        $availabilities = ProviderAvailability::where('provider_id', $provider->id)
            ->orderBy('day_of_week')
            ->get();

        $overrides = ProviderScheduleOverride::where('provider_id', $provider->id)
            ->where('override_date', '>=', now()->toDateString())
            ->orderBy('override_date')
            ->get();

        $dayNames = [
            0 => 'Minggu',
            1 => 'Senin',
            2 => 'Selasa',
            3 => 'Rabu',
            4 => 'Kamis',
            5 => 'Jumat',
            6 => 'Sabtu',
        ];

        return view('provider.schedule.index', compact('provider', 'availabilities', 'overrides', 'dayNames'));
    }

    public function updateWeekly(UpdateProviderScheduleRequest $request): RedirectResponse
    {
        $provider = auth()->user()->provider;

        foreach ($request->input('schedules') as $sched) {
            ProviderAvailability::updateOrCreate(
                [
                    'provider_id' => $provider->id,
                    'day_of_week' => (int) $sched['day_of_week'],
                ],
                [
                    'start_time' => $sched['start_time'] . ':00',
                    'end_time' => $sched['end_time'] . ':00',
                    'is_available' => !empty($sched['is_available']),
                ]
            );
        }

        return back()->with('success', 'Jadwal jam kerja mingguan berhasil diperbarui!');
    }

    public function storeOverride(Request $request): RedirectResponse
    {
        $request->validate([
            'override_date' => 'required|date|after_or_equal:today',
            'reason' => 'nullable|string|max:255',
            'is_off' => 'nullable|boolean',
        ]);

        $provider = auth()->user()->provider;

        ProviderScheduleOverride::updateOrCreate(
            [
                'provider_id' => $provider->id,
                'override_date' => $request->input('override_date'),
            ],
            [
                'is_off' => $request->boolean('is_off', true),
                'reason' => $request->string('reason'),
            ]
        );

        return back()->with('success', 'Libur tentatif / pengecualian jadwal berhasil ditambahkan.');
    }

    public function destroyOverride(int $id): RedirectResponse
    {
        $provider = auth()->user()->provider;
        $override = ProviderScheduleOverride::where('id', $id)
            ->where('provider_id', $provider->id)
            ->firstOrFail();

        $override->delete();

        return back()->with('success', 'Pengecualian jadwal berhasil dihapus.');
    }
}
