<?php

namespace App\Http\Controllers;

use App\Models\CartItem;
use App\Models\Order;
use App\Services\OrderCheckoutService;
use App\Services\PaymentGatewayService;
use Exception;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class CheckoutController extends Controller
{
    public function __construct(
        protected OrderCheckoutService $checkoutService,
        protected PaymentGatewayService $paymentGateway
    ) {}

    public function showCheckout(): View|RedirectResponse
    {
        $user = auth()->user();
        $cartItems = CartItem::where('user_id', $user->id)
            ->with(['product.provider', 'variant', 'product.rentalProfile'])
            ->get();

        if ($cartItems->isEmpty()) {
            return redirect()->route('cart.index')->with('info', 'Keranjang Anda kosong.');
        }

        $itemsByProvider = $cartItems->groupBy('product.provider_id');
        $totalAmount = 0;
        $totalDeposit = 0;

        foreach ($cartItems as $item) {
            $price = $item->variant ? $item->variant->price : $item->product->base_price;
            $deposit = ($item->item_type === 'rental' && $item->product->rentalProfile) ? $item->product->rentalProfile->deposit_amount * $item->quantity : 0;
            $totalAmount += ($price * $item->quantity) + $deposit;
            $totalDeposit += $deposit;
        }

        return view('checkout.index', compact('user', 'itemsByProvider', 'totalAmount', 'totalDeposit'));
    }

    public function processCheckout(Request $request): RedirectResponse
    {
        $request->validate([
            'recipient_name' => 'required|string|max:255',
            'recipient_phone' => 'required|string|max:25',
            'shipping_address' => 'required|string|max:500',
            'city' => 'required|string|max:100',
            'postal_code' => 'nullable|string|max:10',
            'payment_method' => 'required|in:qris,cod',
            'notes' => 'nullable|string|max:500',
        ]);

        $shippingAddress = [
            'name' => $request->string('recipient_name'),
            'phone' => $request->string('recipient_phone'),
            'address' => $request->string('shipping_address'),
            'city' => $request->string('city'),
            'postal_code' => $request->input('postal_code'),
        ];

        try {
            $order = $this->checkoutService->checkout(
                customer: auth()->user(),
                shippingAddress: $shippingAddress,
                paymentMethod: $request->input('payment_method'),
                notes: $request->input('notes')
            );

            // Generate payment details
            $this->paymentGateway->createPayment($order);

            return redirect()->route('order.invoice', $order->order_number)->with('success', 'Pesanan berhasil dibuat!');
        } catch (Exception $e) {
            return back()->with('error', $e->getMessage());
        }
    }

    public function showInvoice(string $orderNumber): View
    {
        $order = Order::where('order_number', $orderNumber)
            ->with([
                'user',
                'payments',
                'vendorOrders.provider',
                'vendorOrders.items.product',
                'vendorOrders.items.variant',
                'vendorOrders.items.review',
                'vendorOrders.shippingHistories'
            ])
            ->firstOrFail();

        // Authorization check: Customer owner, or Provider of sub-order, or Admin
        $user = auth()->user();
        $isCustomerOwner = ($order->user_id === $user->id);
        $isAdmin = $user->isAdmin();
        $isRelatedProvider = $order->vendorOrders->contains('provider_id', $user->provider?->id);

        if (!$isCustomerOwner && !$isAdmin && !$isRelatedProvider) {
            abort(403, 'Anda tidak memiliki otorisasi untuk mengakses faktur / pesanan ini.');
        }

        $payment = $order->payments->first();

        return view('checkout.invoice', compact('order', 'payment'));
    }

    public function printInvoice(string $orderNumber): View
    {
        $order = Order::where('order_number', $orderNumber)
            ->with([
                'user',
                'payments',
                'vendorOrders.provider',
                'vendorOrders.items.product',
                'vendorOrders.items.variant',
                'vendorOrders.items.review',
                'vendorOrders.shippingHistories'
            ])
            ->firstOrFail();

        $user = auth()->user();
        $isCustomerOwner = ($order->user_id === $user->id);
        $isAdmin = $user->isAdmin();
        $isRelatedProvider = $order->vendorOrders->contains('provider_id', $user->provider?->id);

        if (!$isCustomerOwner && !$isAdmin && !$isRelatedProvider) {
            abort(403, 'Akses ditolak.');
        }

        $payment = $order->payments->first();

        return view('checkout.print', compact('order', 'payment'));
    }
}
