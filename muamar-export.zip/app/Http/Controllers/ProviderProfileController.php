<?php

namespace App\Http\Controllers;

use App\Http\Requests\UpdateProviderProfileRequest;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\View\View;

class ProviderProfileController extends Controller
{
    public function edit(): View
    {
        $provider = auth()->user()->provider;
        if (!$provider) {
            abort(403, 'Akses ditolak.');
        }

        return view('provider.profile.edit', compact('provider'));
    }

    public function update(UpdateProviderProfileRequest $request): RedirectResponse
    {
        $provider = auth()->user()->provider;

        $logoUrl = $provider->logo_url;
        if ($request->hasFile('logo')) {
            $file = $request->file('logo');
            $randomName = Str::random(32) . '.' . $file->getClientOriginalExtension();
            $path = $file->storeAs('providers/logos', $randomName, 'public');
            $logoUrl = Storage::url($path);
        }

        $bannerUrl = $provider->banner_url;
        if ($request->hasFile('banner')) {
            $file = $request->file('banner');
            $randomName = Str::random(32) . '.' . $file->getClientOriginalExtension();
            $path = $file->storeAs('providers/banners', $randomName, 'public');
            $bannerUrl = Storage::url($path);
        }

        $provider->update([
            'business_name' => $request->string('business_name'),
            'description' => $request->input('description'),
            'address' => $request->string('address'),
            'city' => $request->string('city'),
            'province' => $request->input('province'),
            'postal_code' => $request->input('postal_code'),
            'latitude' => $request->filled('latitude') ? (float) $request->input('latitude') : null,
            'longitude' => $request->filled('longitude') ? (float) $request->input('longitude') : null,
            'is_location_public' => $request->boolean('is_location_public'),
            'phone' => $request->string('phone'),
            'qris_active' => $request->boolean('qris_active'),
            'cod_active' => $request->boolean('cod_active'),
            'logo_url' => $logoUrl,
            'banner_url' => $bannerUrl,
        ]);

        return back()->with('success', 'Profil studio & pengaturan pembayaran berhasil diperbarui.');
    }
}
