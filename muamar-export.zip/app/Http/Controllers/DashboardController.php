<?php

namespace App\Http\Controllers;

use App\Models\AdminAuditLog;
use App\Models\Order;
use App\Models\Product;
use App\Models\Provider;
use App\Models\RentalBooking;
use App\Models\Review;
use App\Models\ServiceBooking;
use App\Models\User;
use App\Models\VendorOrder;
use Illuminate\View\View;

class DashboardController extends Controller
{
    public function customerDashboard(): View
    {
        $user = auth()->user();

        $orders = Order::where('user_id', $user->id)
            ->with(['vendorOrders.provider', 'vendorOrders.items.product'])
            ->latest()
            ->paginate(10);

        $serviceBookings = ServiceBooking::where('customer_id', $user->id)
            ->with(['product', 'provider'])
            ->latest('start_time')
            ->take(5)
            ->get();

        $rentalBookings = RentalBooking::where('customer_id', $user->id)
            ->with(['product', 'provider'])
            ->latest('start_date')
            ->take(5)
            ->get();

        $totalSpent = Order::where('user_id', $user->id)
            ->where('payment_status', 'paid')
            ->sum('total_amount');

        return view('dashboard.customer', compact('user', 'orders', 'serviceBookings', 'rentalBookings', 'totalSpent'));
    }

    public function providerDashboard(): View
    {
        $user = auth()->user();
        $provider = $user->provider;

        if (!$provider) {
            return redirect()->route('provider.onboard');
        }

        $vendorOrders = VendorOrder::where('provider_id', $provider->id)
            ->with(['order.user', 'items.product', 'shippingHistories'])
            ->latest()
            ->paginate(10);

        $totalRevenue = VendorOrder::where('provider_id', $provider->id)
            ->where('payment_status', 'paid')
            ->sum('subtotal');

        $activeServicesCount = Product::where('provider_id', $provider->id)
            ->where('type', 'service')
            ->where('is_active', true)
            ->count();

        $activeRentalsCount = Product::where('provider_id', $provider->id)
            ->where('type', 'rental')
            ->where('is_active', true)
            ->count();

        $activeProductsCount = Product::where('provider_id', $provider->id)
            ->where('type', 'physical')
            ->where('is_active', true)
            ->count();

        $upcomingServiceBookings = ServiceBooking::where('provider_id', $provider->id)
            ->whereIn('status', ['confirmed', 'in_progress'])
            ->where('start_time', '>=', now())
            ->with(['customer', 'product'])
            ->orderBy('start_time', 'asc')
            ->take(5)
            ->get();

        $reviews = Review::where('provider_id', $provider->id)
            ->with(['user', 'product'])
            ->latest()
            ->take(5)
            ->get();

        return view('dashboard.provider', compact(
            'provider',
            'vendorOrders',
            'totalRevenue',
            'activeServicesCount',
            'activeRentalsCount',
            'activeProductsCount',
            'upcomingServiceBookings',
            'reviews'
        ));
    }

    public function adminDashboard(): View
    {
        $stats = [
            'total_users' => User::count(),
            'total_providers' => Provider::count(),
            'pending_providers' => Provider::where('is_verified', false)->count(),
            'total_orders' => Order::count(),
            'total_gmv' => Order::where('payment_status', 'paid')->sum('total_amount'),
            'total_products' => Product::count(),
            'total_reviews' => Review::count(),
        ];

        $recentProviders = Provider::with('user')
            ->latest()
            ->take(5)
            ->get();

        $recentOrders = Order::with(['user', 'vendorOrders.provider'])
            ->latest()
            ->take(8)
            ->get();

        $recentAuditLogs = AdminAuditLog::with('user')
            ->latest()
            ->take(10)
            ->get();

        $categories = \App\Models\Category::withCount('products')
            ->with('parent')
            ->orderBy('name')
            ->get();

        $recentProducts = Product::with(['provider', 'category'])
            ->latest()
            ->take(6)
            ->get();

        $recentReviews = Review::with(['user', 'product', 'provider'])
            ->latest()
            ->take(6)
            ->get();

        return view('dashboard.admin', compact(
            'stats',
            'recentProviders',
            'recentOrders',
            'recentAuditLogs',
            'categories',
            'recentProducts',
            'recentReviews'
        ));
    }
}
