<?php

namespace App\Http\Controllers;

use App\Models\CartItem;
use App\Models\Product;
use Carbon\Carbon;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class CartController extends Controller
{
    public function index(): View
    {
        $user = auth()->user();
        $cartItems = CartItem::where('user_id', $user->id)
            ->with(['product.provider', 'variant', 'product.serviceProfile', 'product.rentalProfile'])
            ->get();

        $itemsByProvider = $cartItems->groupBy('product.provider_id');
        $totalEstimate = 0;

        foreach ($cartItems as $item) {
            $price = $item->variant ? $item->variant->price : $item->product->base_price;
            $deposit = ($item->item_type === 'rental' && $item->product->rentalProfile) ? $item->product->rentalProfile->deposit_amount * $item->quantity : 0;
            $totalEstimate += ($price * $item->quantity) + $deposit;
        }

        return view('cart.index', compact('itemsByProvider', 'totalEstimate'));
    }

    public function add(Request $request): RedirectResponse
    {
        $request->validate([
            'product_id' => 'required|exists:products,id',
            'product_variant_id' => 'nullable|exists:product_variants,id',
            'quantity' => 'nullable|integer|min:1',
            'booking_start' => 'nullable|date',
            'booking_end' => 'nullable|date',
        ]);

        $product = Product::with(['variants', 'serviceProfile', 'rentalProfile'])->findOrFail($request->input('product_id'));
        $user = auth()->user();
        $qty = max(1, (int) $request->input('quantity', 1));
        $variantId = $request->input('product_variant_id');

        // 1. Validation for Physical Products
        if ($product->type === 'physical') {
            if ($product->variants->isNotEmpty()) {
                if (!$variantId) {
                    $variant = $product->variants->where('is_active', true)->first();
                    $variantId = $variant ? $variant->id : null;
                } else {
                    $variant = $product->variants->firstWhere('id', $variantId);
                    if (!$variant) {
                        return back()->with('error', 'Varian produk yang dipilih tidak valid.');
                    }
                }

                if ($variant && $variant->stock < $qty) {
                    return back()->with('error', "Stok varian {$variant->variant_name} tidak mencukupi (sisa {$variant->stock}).");
                }
            }
        }

        // 2. Validation for Services
        $bookingStart = null;
        $bookingEnd = null;
        if ($product->type === 'service') {
            if (!$request->filled('booking_start')) {
                return back()->with('error', 'Silakan pilih jadwal tanggal dan waktu mulai rias.');
            }

            $bookingStart = Carbon::parse($request->input('booking_start'));
            if ($bookingStart->isPast()) {
                return back()->with('error', 'Waktu janji temu tidak boleh di masa lampau.');
            }

            $duration = $product->serviceProfile ? $product->serviceProfile->duration_minutes : 120;
            $bookingEnd = $bookingStart->copy()->addMinutes($duration);
        }

        // 3. Validation for Rentals
        if ($product->type === 'rental') {
            if (!$request->filled('booking_start') || !$request->filled('booking_end')) {
                return back()->with('error', 'Tanggal mulai dan selesai sewa perlengkapan wajib diisi.');
            }

            $bookingStart = Carbon::parse($request->input('booking_start'));
            $bookingEnd = Carbon::parse($request->input('booking_end'));

            if ($bookingStart->isPast() && !$bookingStart->isToday()) {
                return back()->with('error', 'Tanggal mulai sewa tidak boleh di masa lampau.');
            }

            if ($bookingEnd->lessThanOrEqualTo($bookingStart)) {
                return back()->with('error', 'Tanggal selesai sewa harus setelah tanggal mulai sewa.');
            }

            $maxUnits = $product->rentalProfile ? $product->rentalProfile->total_units : 10;
            if ($qty > $maxUnits) {
                return back()->with('error', "Jumlah unit melebihi kapasitas total vendor (maks {$maxUnits} unit).");
            }
        }

        // Check if identical item already in cart for this user
        $existing = CartItem::where('user_id', $user->id)
            ->where('product_id', $product->id)
            ->where('product_variant_id', $variantId)
            ->when($product->type === 'service', fn($q) => $q->where('booking_start', $bookingStart))
            ->when($product->type === 'rental', fn($q) => $q->where('booking_start', $bookingStart)->where('booking_end', $bookingEnd))
            ->first();

        if ($existing) {
            $newQty = $existing->quantity + $qty;
            if ($product->type === 'physical' && isset($variant) && $variant->stock < $newQty) {
                return back()->with('error', "Stok tidak mencukupi untuk menambah kuantitas di keranjang.");
            }
            $existing->update(['quantity' => $newQty]);
        } else {
            CartItem::create([
                'user_id' => $user->id,
                'product_id' => $product->id,
                'product_variant_id' => $variantId,
                'item_type' => $product->type,
                'quantity' => $qty,
                'booking_start' => $bookingStart,
                'booking_end' => $bookingEnd,
            ]);
        }

        return redirect()->route('cart.index')->with('success', 'Item berhasil ditambahkan ke keranjang belanja.');
    }

    public function updateQuantity(Request $request, int $id): RedirectResponse
    {
        $request->validate([
            'quantity' => 'required|integer|min:1|max:100',
        ]);

        $cartItem = CartItem::where('id', $id)
            ->where('user_id', auth()->id())
            ->with(['variant', 'product.rentalProfile'])
            ->firstOrFail();

        $newQty = (int) $request->input('quantity');

        // Check physical stock
        if ($cartItem->item_type === 'physical' && $cartItem->variant) {
            if ($cartItem->variant->stock < $newQty) {
                return back()->with('error', "Stok varian {$cartItem->variant->variant_name} tidak mencukupi (sisa {$cartItem->variant->stock}).");
            }
        }

        // Check rental capacity
        if ($cartItem->item_type === 'rental' && $cartItem->product->rentalProfile) {
            if ($newQty > $cartItem->product->rentalProfile->total_units) {
                return back()->with('error', "Jumlah unit melebihi kapasitas vendor (maks {$cartItem->product->rentalProfile->total_units}).");
            }
        }

        $cartItem->update(['quantity' => $newQty]);

        return back()->with('success', 'Kuantitas item keranjang berhasil diperbarui.');
    }

    public function remove(int $id): RedirectResponse
    {
        $cartItem = CartItem::where('id', $id)
            ->where('user_id', auth()->id())
            ->firstOrFail();

        $cartItem->delete();

        return redirect()->route('cart.index')->with('success', 'Item berhasil dihapus dari keranjang.');
    }
}
