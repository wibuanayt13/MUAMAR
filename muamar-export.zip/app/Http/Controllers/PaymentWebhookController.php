<?php

namespace App\Http\Controllers;

use App\Services\PaymentGatewayService;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class PaymentWebhookController extends Controller
{
    public function __construct(
        protected PaymentGatewayService $paymentGateway
    ) {}

    public function handle(Request $request): JsonResponse
    {
        $payload = $request->all();
        $signature = $request->header('X-Signature') ?? $request->input('signature_key');

        // 1. Verify Signature
        if (!$this->paymentGateway->verifyWebhookSignature($payload, $signature)) {
            return response()->json([
                'status' => 'error',
                'message' => 'Invalid webhook signature.',
            ], 401);
        }

        // 2. Handle with Idempotency
        try {
            $result = $this->paymentGateway->handleWebhook($payload, $request->ip());
            return response()->json($result, 200);
        } catch (Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => $e->getMessage(),
            ], 400);
        }
    }
}
