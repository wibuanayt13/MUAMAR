<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use App\Models\Provider;
use Illuminate\Http\Request;
use Illuminate\View\View;

class CatalogController extends Controller
{
    public function index(Request $request): View
    {
        $query = Product::with(['provider', 'category', 'variants', 'serviceProfile', 'rentalProfile', 'reviews'])
            ->where('is_active', true)
            ->whereHas('provider', function ($q) {
                $q->where('status', 'approved');
            });

        // Filter: Type
        if ($request->filled('type') && in_array($request->input('type'), ['physical', 'service', 'rental'])) {
            $query->where('type', $request->input('type'));
        }

        // Filter: Category
        if ($request->filled('category')) {
            $categorySlug = $request->input('category');
            $category = Category::where('slug', $categorySlug)->first();
            if ($category) {
                $categoryIds = Category::where('id', $category->id)
                    ->orWhere('parent_id', $category->id)
                    ->pluck('id');
                $query->whereIn('category_id', $categoryIds);
            }
        }

        // Search: Keyword
        if ($request->filled('q')) {
            $search = '%' . $request->input('q') . '%';
            $query->where(function ($sub) use ($search) {
                $sub->where('name', 'like', $search)
                    ->orWhere('description', 'like', $search)
                    ->orWhereHas('provider', function ($pq) use ($search) {
                        $pq->where('business_name', 'like', $search)
                           ->orWhere('city', 'like', $search);
                    });
            });
        }

        // Filter: Price Range
        if ($request->filled('min_price')) {
            $query->where('base_price', '>=', (int) $request->input('min_price'));
        }
        if ($request->filled('max_price')) {
            $query->where('base_price', '<=', (int) $request->input('max_price'));
        }

        // Sorting
        $sort = $request->input('sort', 'latest');
        match ($sort) {
            'price_asc' => $query->orderBy('base_price', 'asc'),
            'price_desc' => $query->orderBy('base_price', 'desc'),
            default => $query->latest(),
        };

        $products = $query->paginate(12)->withQueryString();
        $categories = Category::whereNull('parent_id')->with('children')->get();

        return view('catalog.index', compact('products', 'categories'));
    }

    public function show(string $slug): View
    {
        $product = Product::with([
            'provider.availabilities',
            'category',
            'variants',
            'serviceProfile',
            'rentalProfile',
            'reviews.user'
        ])
        ->where('slug', $slug)
        ->where('is_active', true)
        ->firstOrFail();

        $relatedProducts = Product::where('category_id', $product->category_id)
            ->where('id', '!=', $product->id)
            ->where('is_active', true)
            ->take(4)
            ->get();

        return view('catalog.show', compact('product', 'relatedProducts'));
    }

    public function map(Request $request): View
    {
        $providers = Provider::query()
            ->publicOnMap()
            ->withCount(['products'])
            ->get();

        return view('catalog.map', compact('providers'));
    }
}
