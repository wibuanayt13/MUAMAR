<?php

namespace App\Http\Controllers;

use App\Models\AdminAuditLog;
use App\Models\Category;
use App\Models\Product;
use App\Models\Provider;
use App\Models\Review;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class AdminModerationController extends Controller
{
    public function verifyProvider(Request $request, int $providerId): RedirectResponse
    {
        $user = auth()->user();
        if (!$user->isAdmin()) {
            abort(403, 'Akses khusus administrator.');
        }

        $provider = Provider::findOrFail($providerId);
        $oldValues = $provider->toArray();

        $provider->update([
            'is_verified' => true,
            'status' => 'approved',
        ]);

        AdminAuditLog::create([
            'user_id' => $user->id,
            'action' => 'provider_verified',
            'entity_type' => Provider::class,
            'entity_id' => $provider->id,
            'old_values' => $oldValues,
            'new_values' => $provider->fresh()->toArray(),
            'ip_address' => $request->ip(),
        ]);

        return back()->with('success', "Studio {$provider->business_name} berhasil diverifikasi!");
    }

    public function toggleProviderSuspension(Request $request, int $providerId): RedirectResponse
    {
        $user = auth()->user();
        if (!$user->isAdmin()) {
            abort(403, 'Akses khusus administrator.');
        }

        $provider = Provider::findOrFail($providerId);
        $oldValues = $provider->toArray();

        $newStatus = ($provider->status === 'approved') ? 'suspended' : 'approved';
        $provider->update(['status' => $newStatus]);

        AdminAuditLog::create([
            'user_id' => $user->id,
            'action' => 'provider_status_toggled',
            'entity_type' => Provider::class,
            'entity_id' => $provider->id,
            'old_values' => $oldValues,
            'new_values' => $provider->fresh()->toArray(),
            'ip_address' => $request->ip(),
        ]);

        return back()->with('success', "Status studio {$provider->business_name} diubah menjadi: {$newStatus}.");
    }

    public function toggleProductStatus(Request $request, int $productId): RedirectResponse
    {
        $user = auth()->user();
        if (!$user->isAdmin()) {
            abort(403, 'Akses khusus administrator.');
        }

        $product = Product::findOrFail($productId);
        $oldValues = $product->toArray();

        $product->update(['is_active' => !$product->is_active]);

        AdminAuditLog::create([
            'user_id' => $user->id,
            'action' => 'product_status_toggled',
            'entity_type' => Product::class,
            'entity_id' => $product->id,
            'old_values' => $oldValues,
            'new_values' => $product->fresh()->toArray(),
            'ip_address' => $request->ip(),
        ]);

        $statusStr = $product->is_active ? 'diaktifkan' : 'dinonaktifkan/ditangguhkan';
        return back()->with('success', "Listing {$product->name} berhasil {$statusStr}.");
    }

    public function toggleReviewVisibility(Request $request, int $reviewId): RedirectResponse
    {
        $user = auth()->user();
        if (!$user->isAdmin()) {
            abort(403, 'Akses khusus administrator.');
        }

        $review = Review::findOrFail($reviewId);
        $oldValues = $review->toArray();

        $review->update(['is_visible' => !$review->is_visible]);

        AdminAuditLog::create([
            'user_id' => $user->id,
            'action' => 'review_visibility_toggled',
            'entity_type' => Review::class,
            'entity_id' => $review->id,
            'old_values' => $oldValues,
            'new_values' => $review->fresh()->toArray(),
            'ip_address' => $request->ip(),
        ]);

        $statusStr = $review->is_visible ? 'ditampilkan kembali' : 'disembunyikan (moderasi)';
        return back()->with('success', "Ulasan ID #{$review->id} berhasil {$statusStr}.");
    }

    public function storeCategory(Request $request): RedirectResponse
    {
        $user = auth()->user();
        if (!$user->isAdmin()) {
            abort(403, 'Akses khusus administrator.');
        }

        $request->validate([
            'name' => 'required|string|max:100',
            'parent_id' => 'nullable|exists:categories,id',
            'description' => 'nullable|string|max:500',
        ]);

        $slug = Str::slug($request->string('name'));
        if (Category::where('slug', $slug)->exists()) {
            $slug .= '-' . Str::random(4);
        }

        $category = Category::create([
            'name' => $request->string('name'),
            'slug' => $slug,
            'parent_id' => $request->input('parent_id'),
            'description' => $request->string('description'),
        ]);

        AdminAuditLog::create([
            'user_id' => $user->id,
            'action' => 'category_created',
            'entity_type' => Category::class,
            'entity_id' => $category->id,
            'old_values' => null,
            'new_values' => $category->toArray(),
            'ip_address' => $request->ip(),
        ]);

        return back()->with('success', "Kategori '{$category->name}' berhasil ditambahkan.");
    }

    public function deleteCategory(Request $request, int $categoryId): RedirectResponse
    {
        $user = auth()->user();
        if (!$user->isAdmin()) {
            abort(403, 'Akses khusus administrator.');
        }

        $category = Category::withCount('products')->findOrFail($categoryId);

        if ($category->products_count > 0) {
            return back()->with('error', "Kategori tidak dapat dihapus karena masih digunakan oleh {$category->products_count} produk/jasa.");
        }

        $oldValues = $category->toArray();
        $categoryName = $category->name;
        $category->delete();

        AdminAuditLog::create([
            'user_id' => $user->id,
            'action' => 'category_deleted',
            'entity_type' => Category::class,
            'entity_id' => $categoryId,
            'old_values' => $oldValues,
            'new_values' => null,
            'ip_address' => $request->ip(),
        ]);

        return back()->with('success', "Kategori '{$categoryName}' berhasil dihapus.");
    }
}
