<?php

namespace App\Http\Controllers;

use App\Models\OrderItem;
use App\Models\Review;
use App\Notifications\GeneralNotification;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class ReviewController extends Controller
{
    public function store(Request $request): RedirectResponse
    {
        $request->validate([
            'order_item_id' => 'required|exists:order_items,id',
            'rating' => 'required|integer|between:1,5',
            'comment' => 'required|string|min:5|max:1000',
        ]);

        $user = auth()->user();
        $orderItem = OrderItem::with(['vendorOrder.order', 'product'])
            ->findOrFail($request->input('order_item_id'));

        // 1. Authorization: Must be the buyer
        if ($orderItem->vendorOrder->order->user_id !== $user->id) {
            abort(403, 'Anda hanya dapat mengulas produk yang Anda beli sendiri.');
        }

        // 2. Status check: Must be completed
        if ($orderItem->vendorOrder->status !== 'completed' && $orderItem->vendorOrder->order->status !== 'completed') {
            return back()->with('error', 'Ulasan hanya dapat diberikan setelah pesanan berstatus Selesai.');
        }

        // 3. Duplicate check: 1 review per order item
        if (Review::where('order_item_id', $orderItem->id)->exists()) {
            return back()->with('error', 'Anda sudah memberikan ulasan untuk item pesanan ini.');
        }

        $review = Review::create([
            'user_id' => $user->id,
            'provider_id' => $orderItem->vendorOrder->provider_id,
            'product_id' => $orderItem->product_id,
            'order_item_id' => $orderItem->id,
            'rating' => (int) $request->input('rating'),
            'comment' => $request->string('comment'),
            'is_visible' => true,
        ]);

        // Notify provider about new review
        $providerUser = $orderItem->vendorOrder->provider?->user;
        if ($providerUser) {
            $providerUser->notify(new GeneralNotification(
                "Ulasan Baru ({$request->input('rating')} Bintang)",
                "{$user->name} memberikan ulasan untuk {$orderItem->name_snapshot}: \"{$request->string('comment')}\"",
                route('provider.dashboard'),
                'review'
            ));
        }

        return back()->with('success', 'Terima kasih! Ulasan Anda berhasil diterbitkan.');
    }

    public function reply(Request $request, int $reviewId): RedirectResponse
    {
        $request->validate([
            'provider_reply' => 'required|string|max:1000',
        ]);

        $user = auth()->user();
        $review = Review::with(['provider', 'user', 'product'])->findOrFail($reviewId);

        if ($review->provider->user_id !== $user->id && !$user->isAdmin()) {
            abort(403, 'Hanya pemilik studio yang dapat membalas ulasan ini.');
        }

        $review->update(['provider_reply' => $request->string('provider_reply')]);

        // Notify customer about provider reply
        if ($review->user) {
            $review->user->notify(new GeneralNotification(
                "Tanggapan Ulasan dari {$review->provider->business_name}",
                "{$review->provider->business_name} menanggapi ulasan Anda: \"{$request->string('provider_reply')}\"",
                route('catalog.show', $review->product->slug),
                'review'
            ));
        }

        return back()->with('success', 'Balasan ulasan berhasil disimpan.');
    }
}
