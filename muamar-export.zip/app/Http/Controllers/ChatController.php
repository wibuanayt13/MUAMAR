<?php

namespace App\Http\Controllers;

use App\Models\Conversation;
use App\Models\Message;
use App\Models\Provider;
use App\Notifications\GeneralNotification;
use Carbon\Carbon;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\View\View;

class ChatController extends Controller
{
    public function index(): View
    {
        $user = auth()->user();

        $conversations = Conversation::where('customer_id', $user->id)
            ->orWhereHas('provider', function ($q) use ($user) {
                $q->where('user_id', $user->id);
            })
            ->with(['customer', 'provider', 'product', 'messages' => fn($m) => $m->latest()->take(1)])
            ->orderBy('last_message_at', 'desc')
            ->get();

        return view('chat.index', compact('conversations'));
    }

    public function show(int $id): View
    {
        $user = auth()->user();
        $conversation = Conversation::with(['customer', 'provider.user', 'product', 'messages.sender'])
            ->findOrFail($id);

        // Strict authorization: must be either customer or the provider
        $isCustomer = ($conversation->customer_id === $user->id);
        $isProviderOwner = ($conversation->provider->user_id === $user->id);

        if (!$isCustomer && !$isProviderOwner && !$user->isAdmin()) {
            abort(403, 'Anda tidak memiliki hak akses ke percakapan ini.');
        }

        // Mark incoming messages as read
        Message::where('conversation_id', $conversation->id)
            ->where('sender_id', '!=', $user->id)
            ->where('is_read', false)
            ->update(['is_read' => true]);

        return view('chat.show', compact('conversation', 'user'));
    }

    public function start(Request $request): RedirectResponse
    {
        $request->validate([
            'provider_id' => 'required|exists:providers,id',
            'product_id' => 'nullable|exists:products,id',
        ]);

        $user = auth()->user();
        $provider = Provider::findOrFail($request->input('provider_id'));

        // Prevent chatting with own store
        if ($provider->user_id === $user->id) {
            return back()->with('info', 'Anda tidak dapat mengirim pesan ke studio Anda sendiri.');
        }

        $conversation = Conversation::firstOrCreate([
            'customer_id' => $user->id,
            'provider_id' => $provider->id,
            'product_id' => $request->input('product_id'),
        ], [
            'last_message_at' => Carbon::now('UTC'),
        ]);

        return redirect()->route('chat.show', $conversation->id);
    }

    public function send(Request $request, int $id): RedirectResponse
    {
        $request->validate([
            'message' => 'required|string|max:2000',
        ]);

        $user = auth()->user();
        $conversation = Conversation::with('provider')->findOrFail($id);

        $isCustomer = ($conversation->customer_id === $user->id);
        $isProviderOwner = ($conversation->provider->user_id === $user->id);

        if (!$isCustomer && !$isProviderOwner && !$user->isAdmin()) {
            abort(403, 'Akses ditolak.');
        }

        Message::create([
            'conversation_id' => $conversation->id,
            'sender_id' => $user->id,
            'message' => $request->string('message'),
            'is_read' => false,
        ]);

        $conversation->update(['last_message_at' => Carbon::now('UTC')]);

        // Send in-app notification to receiver
        $recipient = $isCustomer ? $conversation->provider->user : $conversation->customer;
        if ($recipient && $recipient->id !== $user->id) {
            $recipient->notify(new GeneralNotification(
                "Pesan Baru dari {$user->name}",
                Str::limit($request->string('message'), 80),
                route('chat.show', $conversation->id),
                'chat'
            ));
        }

        return redirect()->route('chat.show', $conversation->id);
    }
}
