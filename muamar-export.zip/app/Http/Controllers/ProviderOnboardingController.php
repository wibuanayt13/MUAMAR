<?php

namespace App\Http\Controllers;

use App\Http\Requests\ProviderOnboardRequest;
use App\Models\Category;
use App\Models\Product;
use App\Models\ProductVariant;
use App\Models\Provider;
use App\Models\ProviderAvailability;
use App\Models\RentalProfile;
use App\Models\ServiceProfile;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\View\View;

class ProviderOnboardingController extends Controller
{
    public function showOnboard(): View|RedirectResponse
    {
        $user = auth()->user();

        if ($user->provider) {
            return redirect()->route('provider.dashboard')->with('info', 'Anda sudah memiliki profil usaha MUA terdaftar.');
        }

        // Auto-seed categories if empty to guarantee category dropdown is always populated
        if (Category::count() === 0) {
            (new \Database\Seeders\DatabaseSeeder())->run();
        }

        $categories = Category::whereNotNull('parent_id')
            ->orWhereDoesntHave('children')
            ->orderBy('sort_order')
            ->orderBy('name')
            ->get();

        // If still empty (e.g. no subcategories), get all categories
        if ($categories->isEmpty()) {
            $categories = Category::orderBy('name')->get();
        }

        return view('provider.onboard', compact('user', 'categories'));
    }

    public function storeOnboard(ProviderOnboardRequest $request): RedirectResponse
    {
        $user = auth()->user();

        if ($user->provider) {
            return redirect()->route('provider.dashboard');
        }

        $hasInitialProduct = false;

        DB::transaction(function () use ($request, $user, &$hasInitialProduct) {
            $baseSlug = Str::slug($request->string('business_name'));
            $slug = $baseSlug;
            $counter = 1;
            while (Provider::where('slug', $slug)->exists()) {
                $slug = $baseSlug . '-' . $counter++;
            }

            $provider = Provider::create([
                'user_id' => $user->id,
                'business_name' => $request->string('business_name'),
                'slug' => $slug,
                'description' => $request->input('description'),
                'address' => $request->string('address'),
                'city' => $request->string('city'),
                'province' => $request->input('province'),
                'postal_code' => $request->input('postal_code'),
                'latitude' => $request->filled('latitude') ? (float) $request->input('latitude') : null,
                'longitude' => $request->filled('longitude') ? (float) $request->input('longitude') : null,
                'is_location_public' => $request->boolean('is_location_public', true),
                'phone' => $request->string('phone'),
                'is_verified' => false,
                'status' => 'approved', // Default approved for local development/sandbox; admin can suspend
                'qris_active' => $request->boolean('qris_active', true),
                'cod_active' => $request->boolean('cod_active', true),
            ]);

            // Set role to provider if not already
            if (!$user->isProvider()) {
                $user->update(['role' => 'provider']);
            }

            // Create default weekly working hours (08:00 - 20:00 every day)
            for ($day = 0; $day <= 6; $day++) {
                ProviderAvailability::create([
                    'provider_id' => $provider->id,
                    'day_of_week' => $day,
                    'start_time' => '08:00:00',
                    'end_time' => '20:00:00',
                    'is_available' => true,
                ]);
            }

            // Optional First Product/Service Upload during onboarding
            if ($request->filled('initial_product_name')) {
                $hasInitialProduct = true;
                $productBaseSlug = Str::slug($request->string('initial_product_name'));
                $productSlug = $productBaseSlug;
                $pCounter = 1;
                while (Product::where('slug', $productSlug)->exists()) {
                    $productSlug = $productBaseSlug . '-' . $pCounter++;
                }

                $images = [];
                if ($request->hasFile('initial_image')) {
                    $path = $request->file('initial_image')->store('products', 'public');
                    $images[] = '/storage/' . $path;
                }

                $productType = $request->input('initial_product_type', 'service');
                $basePrice = (int) $request->input('initial_base_price', 0);

                // Fallback category if not selected
                $categoryId = $request->input('initial_category_id');
                if (!$categoryId) {
                    $fallbackCategory = Category::first();
                    $categoryId = $fallbackCategory?->id;
                }

                $product = Product::create([
                    'provider_id' => $provider->id,
                    'category_id' => $categoryId,
                    'name' => $request->string('initial_product_name'),
                    'slug' => $productSlug,
                    'description' => $request->input('initial_description'),
                    'type' => $productType,
                    'base_price' => $basePrice,
                    'images' => $images,
                    'is_active' => true,
                ]);

                if ($productType === 'service') {
                    ServiceProfile::create([
                        'product_id' => $product->id,
                        'duration_minutes' => (int) $request->input('initial_duration_minutes', 120),
                        'buffer_minutes' => 30,
                        'capacity_per_slot' => 1,
                        'artist_name' => $provider->business_name,
                        'service_area' => $provider->city ?? 'Area Studio',
                    ]);
                } elseif ($productType === 'rental') {
                    $totalUnits = (int) $request->input('initial_stock', 5);
                    RentalProfile::create([
                        'product_id' => $product->id,
                        'total_units' => $totalUnits > 0 ? $totalUnits : 5,
                        'deposit_amount' => (int) $request->input('initial_deposit_amount', 0),
                        'min_rental_days' => 1,
                        'buffer_hours' => 4,
                        'unit_type' => 'unit',
                    ]);
                } else { // physical
                    $stock = (int) $request->input('initial_stock', 10);
                    ProductVariant::create([
                        'product_id' => $product->id,
                        'sku' => 'SKU-' . strtoupper(Str::random(6)),
                        'variant_name' => 'Standar',
                        'price' => $basePrice,
                        'stock' => $stock > 0 ? $stock : 10,
                        'is_active' => true,
                    ]);
                }
            }
        });

        $msg = $hasInitialProduct
            ? 'Pendaftaran berhasil! Studio Anda telah aktif dan produk/jasa pertama Anda berhasil diterbitkan ke katalog.'
            : 'Profil studio MUA Anda berhasil didaftarkan! Jam ketersediaan default (08:00 - 20:00) telah diaktifkan.';

        return redirect()->route('provider.dashboard')->with('success', $msg);
    }
}
