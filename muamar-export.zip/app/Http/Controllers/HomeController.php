<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use App\Models\Provider;
use Illuminate\View\View;

class HomeController extends Controller
{
    public function index(): View
    {
        $categories = Category::whereNull('parent_id')
            ->with(['children'])
            ->orderBy('sort_order')
            ->get();

        $featuredServices = Product::with(['provider', 'category', 'serviceProfile', 'reviews'])
            ->where('type', 'service')
            ->where('is_active', true)
            ->whereHas('provider', fn($q) => $q->where('status', 'approved'))
            ->latest()
            ->take(4)
            ->get();

        $featuredPhysical = Product::with(['provider', 'category', 'variants', 'reviews'])
            ->where('type', 'physical')
            ->where('is_active', true)
            ->whereHas('provider', fn($q) => $q->where('status', 'approved'))
            ->latest()
            ->take(4)
            ->get();

        $featuredRentals = Product::with(['provider', 'category', 'rentalProfile', 'reviews'])
            ->where('type', 'rental')
            ->where('is_active', true)
            ->whereHas('provider', fn($q) => $q->where('status', 'approved'))
            ->latest()
            ->take(4)
            ->get();

        $verifiedProviders = Provider::approved()
            ->where('is_verified', true)
            ->withCount('products')
            ->take(6)
            ->get();

        return view('welcome', compact('categories', 'featuredServices', 'featuredPhysical', 'featuredRentals', 'verifiedProviders'));
    }
}
