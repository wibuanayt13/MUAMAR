<?php

namespace App\Http\Controllers;

use App\Models\ShippingHistory;
use App\Models\VendorOrder;
use App\Notifications\GeneralNotification;
use App\Services\PaymentGatewayService;
use Carbon\Carbon;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class ProviderOrderController extends Controller
{
    public function __construct(
        protected PaymentGatewayService $paymentGateway
    ) {}

    public function shipOrder(Request $request, int $vendorOrderId): RedirectResponse
    {
        $request->validate([
            'shipping_carrier' => 'required|string|max:100',
            'tracking_number' => 'required|string|max:100',
        ]);

        $user = auth()->user();
        $vendorOrder = VendorOrder::with('provider')->findOrFail($vendorOrderId);

        // Vendor Isolation Check: Seller A cannot modify Seller B's order!
        if ($vendorOrder->provider->user_id !== $user->id && !$user->isAdmin()) {
            abort(403, 'Akses ditolak: Anda tidak memiliki wewenang mengelola pesanan vendor lain.');
        }

        $now = Carbon::now('UTC');
        $vendorOrder->update([
            'status' => 'shipped',
            'shipping_carrier' => $request->string('shipping_carrier'),
            'tracking_number' => $request->string('tracking_number'),
            'shipped_at' => $now,
        ]);

        ShippingHistory::create([
            'vendor_order_id' => $vendorOrder->id,
            'status' => 'shipped',
            'notes' => "Pesanan dikirim via {$request->string('shipping_carrier')} dengan resi: {$request->string('tracking_number')}",
            'updated_by' => $user->id,
            'created_at' => $now,
        ]);

        // Notify customer about shipment & tracking number
        $customer = $vendorOrder->order->user;
        if ($customer) {
            $customer->notify(new GeneralNotification(
                "Pesanan Telah Dikirim ({$vendorOrder->vendor_order_number})",
                "Pesanan Anda dari {$vendorOrder->provider->business_name} telah dikirim via {$request->string('shipping_carrier')} dengan resi {$request->string('tracking_number')}.",
                route('order.invoice', $vendorOrder->order->order_number),
                'shipping'
            ));
        }

        return back()->with('success', 'Nomor resi pengiriman berhasil diperbarui!');
    }

    public function addShippingUpdate(Request $request, int $vendorOrderId): RedirectResponse
    {
        $request->validate([
            'status' => 'required|in:processing,ready_for_shipment,shipped,delivered,completed',
            'notes' => 'required|string|max:500',
        ]);

        $user = auth()->user();
        $vendorOrder = VendorOrder::with(['provider', 'order.user'])->findOrFail($vendorOrderId);

        if ($vendorOrder->provider->user_id !== $user->id && !$user->isAdmin()) {
            abort(403, 'Akses ditolak.');
        }

        $now = Carbon::now('UTC');
        $vendorOrder->update([
            'status' => $request->string('status'),
            'delivered_at' => ($request->input('status') === 'delivered') ? $now : $vendorOrder->delivered_at,
        ]);

        ShippingHistory::create([
            'vendor_order_id' => $vendorOrder->id,
            'status' => $request->string('status'),
            'notes' => $request->string('notes'),
            'updated_by' => $user->id,
            'created_at' => $now,
        ]);

        $customer = $vendorOrder->order->user;
        if ($customer) {
            $customer->notify(new GeneralNotification(
                "Pembaruan Pengiriman ({$vendorOrder->vendor_order_number})",
                $request->string('notes'),
                route('order.invoice', $vendorOrder->order->order_number),
                'shipping'
            ));
        }

        return back()->with('success', 'Status pengiriman berhasil diperbarui.');
    }

    public function confirmCod(int $vendorOrderId): RedirectResponse
    {
        $user = auth()->user();
        $vendorOrder = VendorOrder::with(['provider', 'order'])->findOrFail($vendorOrderId);

        // Vendor Isolation Check
        if ($vendorOrder->provider->user_id !== $user->id && !$user->isAdmin()) {
            abort(403, 'Akses ditolak.');
        }

        $this->paymentGateway->confirmCodPayment($vendorOrder->order, $vendorOrder->provider_id);

        return back()->with('success', 'Pembayaran tunai COD berhasil dikonfirmasi lunas.');
    }

    public function rejectCod(Request $request, int $vendorOrderId): RedirectResponse
    {
        $request->validate([
            'reason' => 'required|string|max:255',
        ]);

        $user = auth()->user();
        $vendorOrder = VendorOrder::with(['provider', 'order'])->findOrFail($vendorOrderId);

        // Vendor Isolation Check
        if ($vendorOrder->provider->user_id !== $user->id && !$user->isAdmin()) {
            abort(403, 'Akses ditolak.');
        }

        $this->paymentGateway->rejectCodPayment(
            $vendorOrder->order,
            $vendorOrder->provider_id,
            $request->string('reason')
        );

        return back()->with('success', 'Pesanan COD telah dibatalkan dan inventaris/slot dilepaskan kembali.');
    }
}
