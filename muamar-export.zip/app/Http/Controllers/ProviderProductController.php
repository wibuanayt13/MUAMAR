<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreProductRequest;
use App\Http\Requests\UpdateProductRequest;
use App\Models\Category;
use App\Models\Product;
use App\Models\ProductVariant;
use App\Models\RentalProfile;
use App\Models\ServiceProfile;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\View\View;

class ProviderProductController extends Controller
{
    public function index(Request $request): View
    {
        $provider = auth()->user()->provider;
        if (!$provider) {
            abort(403, 'Profil studio provider belum dibuat.');
        }

        $query = Product::where('provider_id', $provider->id)
            ->with(['category', 'variants', 'serviceProfile', 'rentalProfile']);

        if ($request->filled('type')) {
            $query->where('type', $request->input('type'));
        }

        $products = $query->latest()->paginate(10);

        $counts = [
            'all' => Product::where('provider_id', $provider->id)->count(),
            'service' => Product::where('provider_id', $provider->id)->where('type', 'service')->count(),
            'physical' => Product::where('provider_id', $provider->id)->where('type', 'physical')->count(),
            'rental' => Product::where('provider_id', $provider->id)->where('type', 'rental')->count(),
        ];

        return view('provider.products.index', compact('products', 'counts', 'provider'));
    }

    public function create(): View
    {
        $provider = auth()->user()->provider;
        $categories = Category::where('is_active', true)->get();

        return view('provider.products.create', compact('provider', 'categories'));
    }

    public function store(StoreProductRequest $request): RedirectResponse
    {
        $provider = auth()->user()->provider;
        if (!$provider) {
            abort(403, 'Akses ditolak.');
        }

        DB::transaction(function () use ($request, $provider) {
            $baseSlug = Str::slug($request->string('name'));
            $slug = $baseSlug;
            $counter = 1;
            while (Product::where('slug', $slug)->exists()) {
                $slug = $baseSlug . '-' . $counter++;
            }

            // Secure Upload Images
            $imagePaths = [];
            if ($request->hasFile('images')) {
                foreach ($request->file('images') as $file) {
                    $randomName = Str::random(32) . '.' . $file->getClientOriginalExtension();
                    $path = $file->storeAs('products', $randomName, 'public');
                    $imagePaths[] = Storage::url($path);
                }
            }

            $product = Product::create([
                'provider_id' => $provider->id,
                'category_id' => $request->input('category_id'),
                'name' => $request->string('name'),
                'slug' => $slug,
                'description' => $request->input('description'),
                'type' => $request->input('type'),
                'base_price' => (int) $request->input('base_price'),
                'images' => !empty($imagePaths) ? $imagePaths : null,
                'is_active' => true,
            ]);

            // Create Profile depending on type
            if ($product->type === 'physical') {
                if ($request->filled('variants')) {
                    foreach ($request->input('variants') as $v) {
                        ProductVariant::create([
                            'product_id' => $product->id,
                            'sku' => $v['sku'],
                            'variant_name' => $v['variant_name'],
                            'price' => (int) $v['price'],
                            'stock' => (int) $v['stock'],
                            'is_active' => true,
                        ]);
                    }
                } else {
                    // Default single variant if none provided
                    ProductVariant::create([
                        'product_id' => $product->id,
                        'sku' => strtoupper(Str::random(8)),
                        'variant_name' => 'Standar',
                        'price' => $product->base_price,
                        'stock' => (int) $request->input('stock', 10),
                        'is_active' => true,
                    ]);
                }
            } elseif ($product->type === 'service') {
                ServiceProfile::create([
                    'product_id' => $product->id,
                    'duration_minutes' => (int) $request->input('duration_minutes', 120),
                    'buffer_minutes' => (int) $request->input('buffer_minutes', 30),
                    'capacity_per_slot' => (int) $request->input('capacity_per_slot', 1),
                    'artist_name' => $request->input('artist_name') ?? $provider->business_name,
                    'service_area' => $request->input('service_area') ?? $provider->city,
                ]);
            } elseif ($product->type === 'rental') {
                RentalProfile::create([
                    'product_id' => $product->id,
                    'total_units' => (int) $request->input('total_units', 1),
                    'deposit_amount' => (int) $request->input('deposit_amount', 0),
                    'min_rental_days' => (int) $request->input('min_rental_days', 1),
                    'buffer_hours' => (int) $request->input('buffer_hours', 2),
                    'unit_type' => $request->input('unit_type', 'unit'),
                ]);
            }
        });

        return redirect()->route('provider.products.index')->with('success', 'Produk / layanan baru berhasil ditambahkan ke etalase!');
    }

    public function edit(int $id): View
    {
        $product = Product::with(['variants', 'serviceProfile', 'rentalProfile'])->findOrFail($id);
        $user = auth()->user();

        // Vendor Isolation check
        if ($user->provider?->id !== $product->provider_id && !$user->isAdmin()) {
            abort(403, 'Akses ditolak: Anda tidak memiliki wewenang mengedit produk vendor lain.');
        }

        $categories = Category::where('is_active', true)->get();

        return view('provider.products.edit', compact('product', 'categories'));
    }

    public function update(UpdateProductRequest $request, int $id): RedirectResponse
    {
        $product = Product::findOrFail($id);
        $user = auth()->user();

        // Vendor Isolation check
        if ($user->provider?->id !== $product->provider_id && !$user->isAdmin()) {
            abort(403, 'Akses ditolak: Anda tidak memiliki wewenang mengedit produk vendor lain.');
        }

        DB::transaction(function () use ($request, $product) {
            $images = $product->images ?? [];

            if ($request->hasFile('images')) {
                foreach ($request->file('images') as $file) {
                    $randomName = Str::random(32) . '.' . $file->getClientOriginalExtension();
                    $path = $file->storeAs('products', $randomName, 'public');
                    $images[] = Storage::url($path);
                }
            }

            $product->update([
                'category_id' => $request->input('category_id'),
                'name' => $request->string('name'),
                'description' => $request->input('description'),
                'base_price' => (int) $request->input('base_price'),
                'images' => $images,
                'is_active' => $request->boolean('is_active', true),
            ]);

            if ($product->type === 'physical' && $request->filled('variants')) {
                foreach ($request->input('variants') as $v) {
                    if (isset($v['id'])) {
                        ProductVariant::where('id', $v['id'])
                            ->where('product_id', $product->id)
                            ->update([
                                'sku' => $v['sku'],
                                'variant_name' => $v['variant_name'],
                                'price' => (int) $v['price'],
                                'stock' => (int) $v['stock'],
                            ]);
                    } else {
                        ProductVariant::create([
                            'product_id' => $product->id,
                            'sku' => $v['sku'],
                            'variant_name' => $v['variant_name'],
                            'price' => (int) $v['price'],
                            'stock' => (int) $v['stock'],
                            'is_active' => true,
                        ]);
                    }
                }
            } elseif ($product->type === 'service') {
                ServiceProfile::updateOrCreate(
                    ['product_id' => $product->id],
                    [
                        'duration_minutes' => (int) $request->input('duration_minutes', 120),
                        'buffer_minutes' => (int) $request->input('buffer_minutes', 30),
                        'capacity_per_slot' => (int) $request->input('capacity_per_slot', 1),
                        'artist_name' => $request->input('artist_name'),
                        'service_area' => $request->input('service_area'),
                    ]
                );
            } elseif ($product->type === 'rental') {
                RentalProfile::updateOrCreate(
                    ['product_id' => $product->id],
                    [
                        'total_units' => (int) $request->input('total_units', 1),
                        'deposit_amount' => (int) $request->input('deposit_amount', 0),
                        'min_rental_days' => (int) $request->input('min_rental_days', 1),
                        'buffer_hours' => (int) $request->input('buffer_hours', 2),
                        'unit_type' => $request->input('unit_type', 'unit'),
                    ]
                );
            }
        });

        return redirect()->route('provider.products.index')->with('success', 'Produk berhasil diperbarui.');
    }

    public function destroy(int $id): RedirectResponse
    {
        $product = Product::findOrFail($id);
        $user = auth()->user();

        // Vendor Isolation check
        if ($user->provider?->id !== $product->provider_id && !$user->isAdmin()) {
            abort(403, 'Akses ditolak: Anda tidak memiliki wewenang menghapus produk vendor lain.');
        }

        $product->delete();

        return redirect()->route('provider.products.index')->with('success', 'Produk berhasil dihapus dari etalase.');
    }
}
