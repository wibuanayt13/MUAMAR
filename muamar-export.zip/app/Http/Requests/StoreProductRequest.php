<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreProductRequest extends FormRequest
{
    public function authorize(): bool
    {
        return auth()->check() && (auth()->user()->isProvider() || auth()->user()->isAdmin());
    }

    public function rules(): array
    {
        $rules = [
            'name' => ['required', 'string', 'max:255'],
            'category_id' => ['required', 'exists:categories,id'],
            'type' => ['required', 'in:physical,service,rental'],
            'base_price' => ['required', 'integer', 'min:0'],
            'description' => ['nullable', 'string', 'max:5000'],
            'images.*' => ['nullable', 'image', 'mimes:jpeg,png,webp', 'max:3072'], // Max 3MB safe images
        ];

        if ($this->input('type') === 'physical') {
            $rules['variants'] = ['nullable', 'array'];
            $rules['variants.*.variant_name'] = ['required_with:variants', 'string', 'max:100'];
            $rules['variants.*.sku'] = ['required_with:variants', 'string', 'max:50', 'distinct'];
            $rules['variants.*.price'] = ['required_with:variants', 'integer', 'min:0'];
            $rules['variants.*.stock'] = ['required_with:variants', 'integer', 'min:0'];
        } elseif ($this->input('type') === 'service') {
            $rules['duration_minutes'] = ['required', 'integer', 'min:15', 'max:1440'];
            $rules['buffer_minutes'] = ['required', 'integer', 'min:0', 'max:360'];
            $rules['capacity_per_slot'] = ['nullable', 'integer', 'min:1', 'max:10'];
            $rules['artist_name'] = ['nullable', 'string', 'max:100'];
            $rules['service_area'] = ['nullable', 'string', 'max:255'];
        } elseif ($this->input('type') === 'rental') {
            $rules['total_units'] = ['required', 'integer', 'min:1', 'max:1000'];
            $rules['deposit_amount'] = ['required', 'integer', 'min:0'];
            $rules['min_rental_days'] = ['nullable', 'integer', 'min:1', 'max:30'];
            $rules['buffer_hours'] = ['nullable', 'integer', 'min:0', 'max:48'];
            $rules['unit_type'] = ['nullable', 'string', 'max:50'];
        }

        return $rules;
    }

    public function messages(): array
    {
        return [
            'name.required' => 'Nama produk / layanan wajib diisi.',
            'category_id.required' => 'Kategori wajib dipilih.',
            'type.required' => 'Tipe produk/layanan wajib dipilih.',
            'base_price.required' => 'Harga dasar wajib diisi.',
            'images.*.image' => 'File harus berupa gambar yang valid (JPEG, PNG, WebP).',
            'images.*.max' => 'Ukuran gambar maksimal adalah 3MB.',
            'duration_minutes.required' => 'Durasi pengerjaan layanan wajib diisi.',
            'total_units.required' => 'Total unit tersedia untuk disewa wajib diisi.',
        ];
    }
}
