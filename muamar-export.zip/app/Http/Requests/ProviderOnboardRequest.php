<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ProviderOnboardRequest extends FormRequest
{
    public function authorize(): bool
    {
        return auth()->check();
    }

    public function rules(): array
    {
        return [
            'business_name' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string', 'max:1500'],
            'address' => ['required', 'string', 'max:500'],
            'city' => ['required', 'string', 'max:100'],
            'province' => ['nullable', 'string', 'max:100'],
            'postal_code' => ['nullable', 'string', 'max:10'],
            'latitude' => ['nullable', 'numeric', 'between:-90,90'],
            'longitude' => ['nullable', 'numeric', 'between:-180,180'],
            'is_location_public' => ['nullable', 'boolean'],
            'phone' => ['required', 'string', 'max:25'],
            'qris_active' => ['nullable', 'boolean'],
            'cod_active' => ['nullable', 'boolean'],

            // Optional First Product/Service Listing Fields
            'initial_product_name' => ['nullable', 'string', 'max:255'],
            'initial_product_type' => ['nullable', 'in:service,physical,rental'],
            'initial_category_id' => ['nullable', 'exists:categories,id'],
            'initial_base_price' => ['nullable', 'numeric', 'min:0'],
            'initial_description' => ['nullable', 'string', 'max:2000'],
            'initial_image' => ['nullable', 'image', 'mimes:jpeg,png,jpg,webp', 'max:2048'],
            'initial_duration_minutes' => ['nullable', 'integer', 'min:15', 'max:720'],
            'initial_stock' => ['nullable', 'integer', 'min:1', 'max:10000'],
            'initial_deposit_amount' => ['nullable', 'numeric', 'min:0'],
        ];
    }

    public function messages(): array
    {
        return [
            'business_name.required' => 'Nama studio / usaha MUA wajib diisi.',
            'address.required' => 'Alamat lengkap wajib diisi.',
            'city.required' => 'Kota/Kabupaten wajib diisi.',
            'phone.required' => 'Nomor kontak usaha wajib diisi.',
        ];
    }
}
