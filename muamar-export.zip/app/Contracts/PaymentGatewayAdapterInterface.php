<?php

namespace App\Contracts;

use App\Models\Order;

interface PaymentGatewayAdapterInterface
{
    /**
     * Get human-readable gateway driver name.
     */
    public function getGatewayName(): string;

    /**
     * Check whether official credentials have been properly configured.
     */
    public function isConfigured(): bool;

    /**
     * Generate dynamic QRIS string and image for the order.
     *
     * @return array{
     *     reference: string,
     *     qris_payload: string,
     *     qris_image_url: string,
     *     expires_at: \Carbon\Carbon
     * }
     */
    public function generateQris(Order $order): array;

    /**
     * Verify authenticity and signature of the incoming webhook.
     */
    public function verifySignature(array $payload, ?string $signature): bool;

    /**
     * Parse and standardize webhook payload into normalized array.
     *
     * @return array{
     *     order_number: string,
     *     transaction_id: string,
     *     status: string, // settlement, expired, failed, pending
     *     gross_amount: int,
     *     payment_type: string,
     *     raw: array
     * }
     */
    public function parseNotification(array $payload): array;
}
