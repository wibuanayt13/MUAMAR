<?php

namespace App\Services;

use App\Contracts\PaymentGatewayAdapterInterface;
use App\Models\Order;
use App\Models\Payment;
use App\Models\PaymentAuditLog;
use Carbon\Carbon;
use Exception;
use Illuminate\Support\Facades\DB;

class PaymentGatewayService
{
    public function __construct(
        protected PaymentGatewayAdapterInterface $adapter
    ) {}

    /**
     * Get the active gateway adapter instance.
     */
    public function getAdapter(): PaymentGatewayAdapterInterface
    {
        return $this->adapter;
    }

    /**
     * Create payment record and generate QRIS payload via adapter.
     */
    public function createPayment(Order $order): Payment
    {
        $existing = Payment::where('order_id', $order->id)->first();
        if ($existing) {
            return $existing;
        }

        $qrisData = $this->adapter->generateQris($order);

        $payment = Payment::create([
            'order_id' => $order->id,
            'payment_method' => $order->payment_method,
            'provider_reference' => $qrisData['reference'],
            'qris_payload' => $qrisData['qris_payload'],
            'qris_image_url' => $qrisData['qris_image_url'],
            'amount' => $order->total_amount,
            'status' => 'pending',
        ]);

        PaymentAuditLog::create([
            'order_id' => $order->id,
            'payment_id' => $payment->id,
            'event_type' => 'payment_created',
            'payload' => [
                'provider_reference' => $payment->provider_reference,
                'gateway_driver' => $this->adapter->getGatewayName(),
                'amount' => $order->total_amount,
            ],
            'ip_address' => request()->ip() ?? '127.0.0.1',
        ]);

        return $payment;
    }

    /**
     * Verify Webhook Signature via adapter.
     */
    public function verifyWebhookSignature(array $payload, ?string $signature): bool
    {
        return $this->adapter->verifySignature($payload, $signature);
    }

    /**
     * Process Webhook with strict idempotency, amount checking, and state transition guards.
     */
    public function handleWebhook(array $payload, string $ipAddress): array
    {
        $parsed = $this->adapter->parseNotification($payload);
        $orderNumber = $parsed['order_number'];

        $order = Order::where('order_number', $orderNumber)->first();

        if (!$order) {
            PaymentAuditLog::create([
                'event_type' => 'webhook_order_not_found',
                'payload' => $payload,
                'ip_address' => $ipAddress,
            ]);
            throw new Exception("Order not found: {$orderNumber}");
        }

        $payment = Payment::where('order_id', $order->id)->first();

        // 1. Check Amount Tampering
        if ($parsed['gross_amount'] !== (int) $order->total_amount) {
            PaymentAuditLog::create([
                'order_id' => $order->id,
                'payment_id' => $payment?->id,
                'event_type' => 'amount_mismatch_rejected',
                'payload' => $payload,
                'ip_address' => $ipAddress,
            ]);
            throw new Exception("Amount mismatch. Expected {$order->total_amount}, got {$parsed['gross_amount']}.");
        }

        // 2. Idempotency Check: If already in identical state, avoid duplicate mutations
        if ($order->payment_status === 'paid' && $parsed['status'] === 'settlement') {
            PaymentAuditLog::create([
                'order_id' => $order->id,
                'payment_id' => $payment?->id,
                'event_type' => 'idempotent_duplicate_skipped',
                'payload' => $payload,
                'ip_address' => $ipAddress,
            ]);

            return ['status' => 'skipped', 'message' => 'Duplicate webhook ignored. Order already paid.'];
        }

        // 3. Prevent Illegal Transition: Already Paid order cannot be moved to failed/expired via webhook
        if ($order->payment_status === 'paid' && in_array($parsed['status'], ['expired', 'failed'])) {
            PaymentAuditLog::create([
                'order_id' => $order->id,
                'payment_id' => $payment?->id,
                'event_type' => 'illegal_transition_blocked',
                'payload' => $payload,
                'ip_address' => $ipAddress,
            ]);

            return ['status' => 'ignored', 'message' => 'Cannot revert paid order to expired/failed via webhook.'];
        }

        // 4. Process Status Transition atomically
        return DB::transaction(function () use ($order, $payment, $parsed, $payload, $ipAddress) {
            $now = Carbon::now('UTC');

            if ($parsed['status'] === 'settlement') {
                $order->update([
                    'status' => 'processing',
                    'payment_status' => 'paid',
                    'paid_at' => $now,
                ]);

                if ($payment) {
                    $payment->update([
                        'status' => 'paid',
                        'paid_at' => $now,
                        'payload_snapshot' => $payload,
                    ]);
                }

                // Update sub vendor orders to processing & paid
                $order->vendorOrders()->update([
                    'status' => 'processing',
                    'payment_status' => 'paid',
                ]);

                // Confirm all held service bookings and rentals
                $order->vendorOrders->each(function ($vo) {
                    $vo->serviceBookings()->where('status', 'hold')->update(['status' => 'confirmed']);
                    $vo->rentalBookings()->where('status', 'hold')->update(['status' => 'confirmed']);
                });

                PaymentAuditLog::create([
                    'order_id' => $order->id,
                    'payment_id' => $payment?->id,
                    'event_type' => 'webhook_settlement_processed',
                    'payload' => $payload,
                    'ip_address' => $ipAddress,
                ]);

                return ['status' => 'success', 'message' => 'Payment settled successfully.'];
            }

            if (in_array($parsed['status'], ['expired', 'failed'])) {
                $terminalPaymentStatus = $parsed['status'] === 'expired' ? 'expired' : 'failed';

                $order->update([
                    'status' => 'cancelled',
                    'cancelled_at' => $now,
                ]);

                if ($payment) {
                    $payment->update([
                        'status' => $terminalPaymentStatus,
                        'payload_snapshot' => $payload,
                    ]);
                }

                $order->vendorOrders()->update([
                    'status' => 'cancelled',
                ]);

                // Release bookings and restore physical stock
                $order->vendorOrders->each(function ($vo) {
                    $vo->serviceBookings()->where('status', 'hold')->update(['status' => 'cancelled']);
                    $vo->rentalBookings()->where('status', 'hold')->update(['status' => 'cancelled']);

                    // Restore stock for physical items
                    foreach ($vo->items as $item) {
                        if ($item->item_type === 'physical' && $item->product_variant_id) {
                            $item->variant?->increment('stock', $item->quantity);
                        }
                    }
                });

                PaymentAuditLog::create([
                    'order_id' => $order->id,
                    'payment_id' => $payment?->id,
                    'event_type' => "webhook_{$terminalPaymentStatus}_processed",
                    'payload' => $payload,
                    'ip_address' => $ipAddress,
                ]);

                return ['status' => 'success', 'message' => "Order marked as {$terminalPaymentStatus}."];
            }

            return ['status' => 'pending', 'message' => 'Notification recorded.'];
        });
    }

    /**
     * Explicit COD Payment Confirmation by Provider.
     */
    public function confirmCodPayment(Order $order, int $providerId): void
    {
        DB::transaction(function () use ($order, $providerId) {
            $vendorOrder = $order->vendorOrders()->where('provider_id', $providerId)->firstOrFail();

            $vendorOrder->update([
                'payment_status' => 'paid',
                'status' => 'completed',
            ]);

            // If all vendor orders in this order are paid, mark master order as paid
            $allPaid = $order->vendorOrders()->where('payment_status', '!=', 'paid')->count() === 0;
            if ($allPaid) {
                $order->update([
                    'payment_status' => 'paid',
                    'status' => 'completed',
                    'paid_at' => Carbon::now('UTC'),
                ]);
            }

            PaymentAuditLog::create([
                'order_id' => $order->id,
                'event_type' => 'cod_confirmed_by_provider',
                'payload' => [
                    'provider_id' => $providerId,
                    'vendor_order_number' => $vendorOrder->vendor_order_number,
                    'collected_amount' => $vendorOrder->total_amount,
                ],
                'ip_address' => request()->ip() ?? '127.0.0.1',
            ]);
        });
    }

    /**
     * Explicit COD Rejection / Cancellation by Provider (e.g. buyer refused delivery/payment).
     */
    public function rejectCodPayment(Order $order, int $providerId, string $reason): void
    {
        DB::transaction(function () use ($order, $providerId, $reason) {
            $vendorOrder = $order->vendorOrders()->where('provider_id', $providerId)->firstOrFail();

            $vendorOrder->update([
                'status' => 'cancelled',
            ]);

            // Release bookings and restore inventory for this vendor order
            $vendorOrder->serviceBookings()->whereIn('status', ['hold', 'confirmed'])->update(['status' => 'cancelled']);
            $vendorOrder->rentalBookings()->whereIn('status', ['hold', 'confirmed'])->update(['status' => 'cancelled']);

            foreach ($vendorOrder->items as $item) {
                if ($item->item_type === 'physical' && $item->product_variant_id) {
                    $item->variant?->increment('stock', $item->quantity);
                }
            }

            // Check if all vendor orders are cancelled
            $allCancelled = $order->vendorOrders()->where('status', '!=', 'cancelled')->count() === 0;
            if ($allCancelled) {
                $order->update([
                    'status' => 'cancelled',
                    'cancelled_at' => Carbon::now('UTC'),
                ]);
            }

            PaymentAuditLog::create([
                'order_id' => $order->id,
                'event_type' => 'cod_rejected_by_provider',
                'payload' => [
                    'provider_id' => $providerId,
                    'vendor_order_number' => $vendorOrder->vendor_order_number,
                    'reason' => $reason,
                ],
                'ip_address' => request()->ip() ?? '127.0.0.1',
            ]);
        });
    }
}
