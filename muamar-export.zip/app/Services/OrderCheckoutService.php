<?php

namespace App\Services;

use App\Models\CartItem;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\ProductVariant;
use App\Models\ShippingHistory;
use App\Models\User;
use App\Models\VendorOrder;
use App\Notifications\GeneralNotification;
use Carbon\Carbon;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class OrderCheckoutService
{
    public function __construct(
        protected BookingSchedulerService $bookingScheduler,
        protected RentalSchedulerService $rentalScheduler
    ) {}

    /**
     * Perform multi-vendor checkout with atomic stock lock and order splitting.
     */
    public function checkout(User $customer, array $shippingAddress, string $paymentMethod, ?string $notes = null): Order
    {
        return DB::transaction(function () use ($customer, $shippingAddress, $paymentMethod, $notes) {
            $cartItems = CartItem::where('user_id', $customer->id)
                ->with(['product.provider', 'variant', 'product.serviceProfile', 'product.rentalProfile'])
                ->get();

            if ($cartItems->isEmpty()) {
                throw new Exception("Keranjang belanja kosong.");
            }

            // Group cart items by provider
            $itemsByProvider = $cartItems->groupBy('product.provider_id');

            $totalAmount = 0;
            $totalDeposit = 0;
            $orderNumber = 'MUAMAR-' . date('Ymd') . '-' . strtoupper(Str::random(6));

            // Create Master Order
            $order = Order::create([
                'order_number' => $orderNumber,
                'user_id' => $customer->id,
                'total_amount' => 0, // Will update after summing vendor orders
                'total_deposit' => 0,
                'status' => 'pending_payment',
                'payment_status' => 'unpaid',
                'payment_method' => $paymentMethod,
                'shipping_address_snapshot' => $shippingAddress,
                'notes' => $notes,
            ]);

            foreach ($itemsByProvider as $providerId => $items) {
                $vendorOrderNumber = 'VO-' . date('Ymd') . '-' . $providerId . '-' . strtoupper(Str::random(4));
                $vendorSubtotal = 0;
                $vendorDeposit = 0;

                $vendorOrder = VendorOrder::create([
                    'vendor_order_number' => $vendorOrderNumber,
                    'order_id' => $order->id,
                    'provider_id' => $providerId,
                    'subtotal' => 0,
                    'deposit_subtotal' => 0,
                    'shipping_cost' => 0,
                    'total_amount' => 0,
                    'status' => 'pending_payment',
                    'payment_status' => 'unpaid',
                ]);

                foreach ($items as $cartItem) {
                    $product = $cartItem->product;
                    $itemType = $cartItem->item_type;
                    $qty = $cartItem->quantity;
                    $unitPrice = $product->base_price;
                    $deposit = 0;
                    $variantName = null;

                    // 1. Physical Product Stock Lock
                    if ($itemType === 'physical') {
                        $variant = null;
                        if ($cartItem->product_variant_id) {
                            $variant = ProductVariant::where('id', $cartItem->product_variant_id)
                                ->lockForUpdate()
                                ->firstOrFail();
                        } elseif ($product->variants()->exists()) {
                            $variant = ProductVariant::where('product_id', $product->id)
                                ->where('is_active', true)
                                ->lockForUpdate()
                                ->first();
                        }

                        if ($variant) {
                            if ($variant->stock < $qty) {
                                throw new Exception("Stok untuk varian {$variant->variant_name} tidak mencukupi. Sisa stok: {$variant->stock}.");
                            }

                            $variant->decrement('stock', $qty);
                            $unitPrice = $variant->price;
                            $variantName = $variant->variant_name;
                        }
                    }

                    // 2. Service Booking
                    if ($itemType === 'service') {
                        $startUtc = $cartItem->booking_start ? Carbon::parse($cartItem->booking_start)->utc() : Carbon::now('UTC')->addDays(1);
                        $holdBooking = $this->bookingScheduler->holdSlot($product, $customer, $startUtc, $notes);
                        $holdBooking->update(['vendor_order_id' => $vendorOrder->id]);
                    }

                    // 3. Rental Booking
                    if ($itemType === 'rental') {
                        $startUtc = $cartItem->booking_start ? Carbon::parse($cartItem->booking_start)->utc() : Carbon::now('UTC')->addDays(1);
                        $endUtc = $cartItem->booking_end ? Carbon::parse($cartItem->booking_end)->utc() : Carbon::now('UTC')->addDays(2);
                        $holdRental = $this->rentalScheduler->holdRental($product, $customer, $startUtc, $endUtc, $qty);
                        $holdRental->update(['vendor_order_id' => $vendorOrder->id]);

                        $deposit = ($product->rentalProfile->deposit_amount ?? 0) * $qty;
                    }

                    $itemSubtotal = $unitPrice * $qty;
                    $vendorSubtotal += $itemSubtotal;
                    $vendorDeposit += $deposit;

                    // Create Order Item snapshot
                    $orderItem = OrderItem::create([
                        'vendor_order_id' => $vendorOrder->id,
                        'product_id' => $product->id,
                        'product_variant_id' => $cartItem->product_variant_id,
                        'item_type' => $itemType,
                        'name_snapshot' => $product->name,
                        'variant_name_snapshot' => $variantName,
                        'price_snapshot' => $unitPrice,
                        'deposit_snapshot' => $deposit,
                        'quantity' => $qty,
                        'subtotal' => $itemSubtotal,
                        'metadata' => [
                            'booking_start' => $cartItem->booking_start?->toIso8601String(),
                            'booking_end' => $cartItem->booking_end?->toIso8601String(),
                        ],
                    ]);

                    if (isset($holdBooking)) {
                        $holdBooking->update(['order_item_id' => $orderItem->id]);
                    }
                    if (isset($holdRental)) {
                        $holdRental->update(['order_item_id' => $orderItem->id]);
                    }
                }

                $vendorTotal = $vendorSubtotal + $vendorDeposit;
                $vendorOrder->update([
                    'subtotal' => $vendorSubtotal,
                    'deposit_subtotal' => $vendorDeposit,
                    'total_amount' => $vendorTotal,
                ]);

                ShippingHistory::create([
                    'vendor_order_id' => $vendorOrder->id,
                    'status' => 'pending_payment',
                    'notes' => 'Pesanan berhasil dibuat, menunggu pembayaran pelanggan.',
                    'updated_by' => $customer->id,
                    'created_at' => Carbon::now('UTC'),
                ]);

                $totalAmount += $vendorTotal;
                $totalDeposit += $vendorDeposit;
            }

            // Update master order total
            $order->update([
                'total_amount' => $totalAmount,
                'total_deposit' => $totalDeposit,
            ]);

            // Clear Cart
            CartItem::where('user_id', $customer->id)->delete();

            // Notify Customer
            $customer->notify(new GeneralNotification(
                "Pesanan Berhasil Dibuat ({$order->order_number})",
                "Pesanan Anda senilai Rp " . number_format($totalAmount, 0, ',', '.') . " berhasil dibuat. Silakan selesaikan pembayaran.",
                route('order.invoice', $order->order_number),
                'order'
            ));

            // Notify each Provider
            $order->load('vendorOrders.provider.user');
            foreach ($order->vendorOrders as $vo) {
                $providerUser = $vo->provider->user;
                if ($providerUser) {
                    $providerUser->notify(new GeneralNotification(
                        "Pesanan Baru Masuk ({$vo->vendor_order_number})",
                        "Anda menerima pesanan baru dari {$customer->name} senilai Rp " . number_format($vo->total_amount, 0, ',', '.') . ".",
                        route('provider.dashboard'),
                        'order'
                    ));
                }
            }

            return $order;
        });
    }
}
