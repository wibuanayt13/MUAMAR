<?php

namespace App\Services;

use App\Models\Product;
use App\Models\RentalBooking;
use App\Models\RentalProfile;
use App\Models\User;
use Carbon\Carbon;
use Exception;
use Illuminate\Support\Facades\DB;

class RentalSchedulerService
{
    /**
     * Check if requested rental units are available across the specified date interval.
     */
    public function isCapacityAvailable(Product $product, Carbon $startDateUtc, Carbon $endDateUtc, int $requestedQuantity): bool
    {
        $profile = $product->rentalProfile;
        if (!$profile) {
            return false;
        }

        $totalUnits = $profile->total_units;
        $bufferHours = $profile->buffer_hours;
        $bufferEndDateUtc = $endDateUtc->copy()->addHours($bufferHours);

        // Calculate sum of active rented quantities in overlapping intervals
        $rentedSum = RentalBooking::where('product_id', $product->id)
            ->where(function ($q) {
                $q->whereIn('status', ['confirmed', 'picked_up'])
                    ->orWhere(function ($holdQuery) {
                        $holdQuery->where('status', 'hold')
                            ->where('hold_expires_at', '>', Carbon::now('UTC'));
                    });
            })
            ->where('start_date', '<', $bufferEndDateUtc)
            ->where('buffer_end_date', '>', $startDateUtc)
            ->sum('quantity_rented');

        return ($rentedSum + $requestedQuantity) <= $totalUnits;
    }

    /**
     * Get remaining available units for a rental item on a date range.
     */
    public function getRemainingCapacity(Product $product, Carbon $startDateUtc, Carbon $endDateUtc): int
    {
        $profile = $product->rentalProfile;
        if (!$profile) {
            return 0;
        }

        $totalUnits = $profile->total_units;
        $bufferHours = $profile->buffer_hours;
        $bufferEndDateUtc = $endDateUtc->copy()->addHours($bufferHours);

        $rentedSum = RentalBooking::where('product_id', $product->id)
            ->where(function ($q) {
                $q->whereIn('status', ['confirmed', 'picked_up'])
                    ->orWhere(function ($holdQuery) {
                        $holdQuery->where('status', 'hold')
                            ->where('hold_expires_at', '>', Carbon::now('UTC'));
                    });
            })
            ->where('start_date', '<', $bufferEndDateUtc)
            ->where('buffer_end_date', '>', $startDateUtc)
            ->sum('quantity_rented');

        return max(0, $totalUnits - $rentedSum);
    }

    /**
     * Reserve rental units with atomic locking on the rental profile row.
     */
    public function holdRental(Product $product, User $customer, Carbon $startDateUtc, Carbon $endDateUtc, int $quantity): RentalBooking
    {
        return DB::transaction(function () use ($product, $customer, $startDateUtc, $endDateUtc, $quantity) {
            // 1. Lock the rental profile to prevent race conditions on capacity calculation
            $profile = RentalProfile::where('product_id', $product->id)->lockForUpdate()->firstOrFail();

            $totalUnits = $profile->total_units;
            $bufferHours = $profile->buffer_hours;
            $bufferEndDateUtc = $endDateUtc->copy()->addHours($bufferHours);

            $rentedSum = RentalBooking::where('product_id', $product->id)
                ->where(function ($q) {
                    $q->whereIn('status', ['confirmed', 'picked_up'])
                        ->orWhere(function ($holdQuery) {
                            $holdQuery->where('status', 'hold')
                                ->where('hold_expires_at', '>', Carbon::now('UTC'));
                        });
                })
                ->where('start_date', '<', $bufferEndDateUtc)
                ->where('buffer_end_date', '>', $startDateUtc)
                ->sum('quantity_rented');

            if (($rentedSum + $quantity) > $totalUnits) {
                $remaining = max(0, $totalUnits - $rentedSum);
                throw new Exception("Kapasitas sewa perlengkapan tidak mencukupi untuk tanggal tersebut. Sisa unit tersedia: {$remaining} {$profile->unit_type}.");
            }

            return RentalBooking::create([
                'provider_id' => $product->provider_id,
                'customer_id' => $customer->id,
                'product_id' => $product->id,
                'start_date' => $startDateUtc,
                'end_date' => $endDateUtc,
                'buffer_end_date' => $bufferEndDateUtc,
                'quantity_rented' => $quantity,
                'deposit_amount' => $profile->deposit_amount * $quantity,
                'status' => 'hold',
                'hold_expires_at' => Carbon::now('UTC')->addMinutes(10),
            ]);
        });
    }

    /**
     * Release expired rental holds.
     */
    public function releaseExpiredHolds(): int
    {
        return RentalBooking::where('status', 'hold')
            ->where('hold_expires_at', '<=', Carbon::now('UTC'))
            ->update(['status' => 'expired']);
    }

    /**
     * Mark rental as picked up / handed over to customer.
     */
    public function markPickedUp(RentalBooking $rental, User $user): void
    {
        if ($rental->provider->user_id !== $user->id && !$user->isAdmin()) {
            throw new Exception("Akses ditolak.");
        }

        $rental->update(['status' => 'picked_up']);
    }

    /**
     * Mark rental as returned and optionally return deposit.
     */
    public function markReturned(RentalBooking $rental, User $user, bool $depositReturned = true): void
    {
        if ($rental->provider->user_id !== $user->id && !$user->isAdmin()) {
            throw new Exception("Akses ditolak.");
        }

        $now = Carbon::now('UTC');
        $rental->update([
            'status' => 'returned',
            'returned_at' => $now,
            'deposit_returned_at' => $depositReturned ? $now : null,
        ]);
    }

    /**
     * Cancel rental booking.
     */
    public function cancelRental(RentalBooking $rental, User $user, string $reason): void
    {
        $isCustomer = ($rental->customer_id === $user->id);
        $isProvider = ($rental->provider->user_id === $user->id);

        if (!$isCustomer && !$isProvider && !$user->isAdmin()) {
            throw new Exception("Akses ditolak.");
        }

        $rental->update(['status' => 'cancelled']);
    }
}
