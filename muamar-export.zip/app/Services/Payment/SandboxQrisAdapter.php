<?php

namespace App\Services\Payment;

use App\Contracts\PaymentGatewayAdapterInterface;
use App\Models\Order;
use Carbon\Carbon;
use Illuminate\Support\Str;

class SandboxQrisAdapter implements PaymentGatewayAdapterInterface
{
    protected string $secretKey;
    protected string $merchantId;

    public function __construct()
    {
        $this->secretKey = config('services.payment.webhook_secret') ?? env('PAYMENT_GATEWAY_WEBHOOK_SECRET', 'muamar_secret_webhook_signature_key');
        $this->merchantId = config('services.payment.merchant_id') ?? env('PAYMENT_GATEWAY_MERCHANT_ID', 'MUA_MOCK_MERCHANT_01');
    }

    public function getGatewayName(): string
    {
        return 'Sandbox Mock QRIS Adapter (ASPI Compliant)';
    }

    public function isConfigured(): bool
    {
        return true;
    }

    public function generateQris(Order $order): array
    {
        $providerRef = 'QRIS-SND-' . date('Ymd') . '-' . strtoupper(Str::random(8));

        // Format ASPI standard QRIS payload string
        $qrisPayload = "00020101021226680016ID.CO.QRIS.WWW01189360050300000898320215{$this->merchantId}51440014ID.LINKAJA.WWW02159360050300000895204581453033605802ID5906MUAMAR6015JAKARTA SELATAN61051273062240120" . $order->order_number . "6304" . strtoupper(substr(md5($order->order_number), 0, 4));

        return [
            'reference' => $providerRef,
            'qris_payload' => $qrisPayload,
            'qris_image_url' => 'https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=' . urlencode($qrisPayload),
            'expires_at' => Carbon::now('UTC')->addMinutes(15),
        ];
    }

    public function verifySignature(array $payload, ?string $signature): bool
    {
        $orderNumber = $payload['order_number'] ?? '';
        $statusCode = (string) ($payload['status_code'] ?? '200');
        $grossAmount = (string) ($payload['gross_amount'] ?? 0);

        $expectedSignature = hash('sha256', $orderNumber . $statusCode . $grossAmount . $this->secretKey);

        return hash_equals($expectedSignature, (string) $signature);
    }

    public function parseNotification(array $payload): array
    {
        $rawStatus = strtolower($payload['transaction_status'] ?? $payload['status'] ?? 'pending');

        $status = match ($rawStatus) {
            'settlement', 'capture', 'paid', 'success' => 'settlement',
            'expire', 'expired' => 'expired',
            'deny', 'cancel', 'failed' => 'failed',
            default => 'pending',
        };

        return [
            'order_number' => (string) ($payload['order_number'] ?? ''),
            'transaction_id' => (string) ($payload['transaction_id'] ?? ('TXN-' . Str::random(10))),
            'status' => $status,
            'gross_amount' => (int) ($payload['gross_amount'] ?? 0),
            'payment_type' => (string) ($payload['payment_type'] ?? 'qris'),
            'raw' => $payload,
        ];
    }
}
