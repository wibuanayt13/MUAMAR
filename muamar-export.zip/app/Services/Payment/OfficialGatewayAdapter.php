<?php

namespace App\Services\Payment;

use App\Contracts\PaymentGatewayAdapterInterface;
use App\Models\Order;
use Exception;

class OfficialGatewayAdapter implements PaymentGatewayAdapterInterface
{
    protected ?string $merchantId;
    protected ?string $serverKey;
    protected ?string $clientKey;
    protected ?string $webhookSecret;

    public function __construct()
    {
        $this->merchantId = env('PAYMENT_GATEWAY_MERCHANT_ID');
        $this->serverKey = env('PAYMENT_GATEWAY_SERVER_KEY');
        $this->clientKey = env('PAYMENT_GATEWAY_CLIENT_KEY');
        $this->webhookSecret = env('PAYMENT_GATEWAY_WEBHOOK_SECRET');
    }

    public function getGatewayName(): string
    {
        return 'Official Production Payment Gateway Adapter';
    }

    public function isConfigured(): bool
    {
        return !empty($this->merchantId) && !empty($this->serverKey) && !empty($this->webhookSecret);
    }

    public function generateQris(Order $order): array
    {
        if (!$this->isConfigured()) {
            throw new Exception(
                "Kredensial payment gateway resmi belum dikonfigurasi pada file .env (PAYMENT_GATEWAY_MERCHANT_ID, PAYMENT_GATEWAY_SERVER_KEY, PAYMENT_GATEWAY_WEBHOOK_SECRET). " .
                "Gunakan PAYMENT_GATEWAY_DRIVER=sandbox untuk pengujian lokal."
            );
        }

        /**
         * TODO: Pasang SDK resmi payment gateway yang dipilih (misal: Midtrans CoreApi / Xendit API).
         * Contoh Midtrans CoreApi:
         * \Midtrans\Config::$serverKey = $this->serverKey;
         * \Midtrans\Config::$isProduction = app()->isProduction();
         * $params = [
         *     'payment_type' => 'qris',
         *     'transaction_details' => [
         *         'order_id' => $order->order_number,
         *         'gross_amount' => $order->total_amount,
         *     ],
         *     'qris' => ['acquirer' => 'gopay']
         * ];
         * $response = \Midtrans\CoreApi::charge($params);
         */
        throw new Exception("TODO: Masukkan kredensial dan aktifkan SDK resmi payment gateway produksi.");
    }

    public function verifySignature(array $payload, ?string $signature): bool
    {
        if (!$this->isConfigured()) {
            return false;
        }

        $orderNumber = $payload['order_number'] ?? '';
        $statusCode = (string) ($payload['status_code'] ?? '200');
        $grossAmount = (string) ($payload['gross_amount'] ?? 0);

        // Standard official signature calculation: SHA512 or SHA256 of order_id + status_code + gross_amount + server_key
        $expectedSignature = hash('sha256', $orderNumber . $statusCode . $grossAmount . $this->serverKey);

        return hash_equals($expectedSignature, (string) $signature);
    }

    public function parseNotification(array $payload): array
    {
        $rawStatus = strtolower($payload['transaction_status'] ?? $payload['status'] ?? 'pending');

        $status = match ($rawStatus) {
            'settlement', 'capture', 'paid' => 'settlement',
            'expire', 'expired' => 'expired',
            'deny', 'cancel', 'failed' => 'failed',
            default => 'pending',
        };

        return [
            'order_number' => (string) ($payload['order_number'] ?? ''),
            'transaction_id' => (string) ($payload['transaction_id'] ?? ''),
            'status' => $status,
            'gross_amount' => (int) ($payload['gross_amount'] ?? 0),
            'payment_type' => (string) ($payload['payment_type'] ?? 'qris'),
            'raw' => $payload,
        ];
    }
}
