<?php

namespace App\Services;

use App\Models\Product;
use App\Models\Provider;
use App\Models\ProviderAvailability;
use App\Models\ProviderScheduleOverride;
use App\Models\ServiceBooking;
use App\Models\User;
use Carbon\Carbon;
use Exception;
use Illuminate\Support\Facades\DB;

class BookingSchedulerService
{
    /**
     * Check if a specific service slot is available.
     * Checks provider weekly working hours, overrides, and overlapping bookings.
     */
    public function isSlotAvailable(Product $product, Carbon $startUtc, ?int $ignoreBookingId = null): bool
    {
        $serviceProfile = $product->serviceProfile;
        $durationMinutes = $serviceProfile ? $serviceProfile->duration_minutes : 120;
        $bufferMinutes = $serviceProfile ? $serviceProfile->buffer_minutes : 30;

        $endUtc = $startUtc->copy()->addMinutes($durationMinutes);
        $bufferEndUtc = $endUtc->copy()->addMinutes($bufferMinutes);

        // Check if provider has active overlapping bookings [startUtc, bufferEndUtc)
        $query = ServiceBooking::where('provider_id', $product->provider_id)
            ->where(function ($q) {
                $q->whereIn('status', ['confirmed', 'in_progress'])
                    ->orWhere(function ($holdQuery) {
                        $holdQuery->where('status', 'hold')
                            ->where('hold_expires_at', '>', Carbon::now('UTC'));
                    });
            })
            ->where('start_time', '<', $bufferEndUtc)
            ->where('buffer_end_time', '>', $startUtc);

        if ($ignoreBookingId) {
            $query->where('id', '!=', $ignoreBookingId);
        }

        return $query->count() === 0;
    }

    /**
     * Calculate and return available time slots for a service product on a specific date.
     *
     * @return array<int, array{time: string, start_utc: string, is_available: bool}>
     */
    public function getAvailableSlots(Product $product, Carbon $date): array
    {
        $provider = $product->provider;
        if (!$provider) {
            return [];
        }

        $dateString = $date->toDateString();

        // 1. Check if provider has a schedule override (holiday / closed) on this date
        $override = ProviderScheduleOverride::where('provider_id', $provider->id)
            ->where('override_date', $dateString)
            ->first();

        if ($override && $override->is_off) {
            return [];
        }

        // 2. Check weekly availability
        $dayOfWeek = $date->dayOfWeek; // 0 = Sunday, 1 = Monday, ..., 6 = Saturday
        $availability = ProviderAvailability::where('provider_id', $provider->id)
            ->where('day_of_week', $dayOfWeek)
            ->first();

        if (!$availability || !$availability->is_available) {
            return [];
        }

        $serviceProfile = $product->serviceProfile;
        $durationMinutes = $serviceProfile ? $serviceProfile->duration_minutes : 120;
        $bufferMinutes = $serviceProfile ? $serviceProfile->buffer_minutes : 30;
        $totalSlotBlock = $durationMinutes + $bufferMinutes;

        $startTime = Carbon::parse("{$dateString} {$availability->start_time}", 'Asia/Jakarta');
        $endTime = Carbon::parse("{$dateString} {$availability->end_time}", 'Asia/Jakarta');

        $slots = [];
        $current = $startTime->copy();

        while ($current->copy()->addMinutes($durationMinutes)->lessThanOrEqualTo($endTime)) {
            $slotStartUtc = $current->copy()->utc();
            $available = $this->isSlotAvailable($product, $slotStartUtc);

            $slots[] = [
                'time' => $current->format('H:i'),
                'start_utc' => $slotStartUtc->toIso8601String(),
                'is_available' => $available,
            ];

            // Step by duration or convenient interval
            $current->addMinutes($totalSlotBlock > 0 ? $totalSlotBlock : 120);
        }

        return $slots;
    }

    /**
     * Hold a slot for 10 minutes with atomic row locking on provider.
     * Prevents race conditions / double bookings.
     */
    public function holdSlot(Product $product, User $customer, Carbon $startUtc, ?string $notes = null): ServiceBooking
    {
        return DB::transaction(function () use ($product, $customer, $startUtc, $notes) {
            // 1. Lock the provider row to prevent concurrent booking conflicts
            Provider::where('id', $product->provider_id)->lockForUpdate()->first();

            $serviceProfile = $product->serviceProfile;
            $durationMinutes = $serviceProfile ? $serviceProfile->duration_minutes : 120;
            $bufferMinutes = $serviceProfile ? $serviceProfile->buffer_minutes : 30;

            $endUtc = $startUtc->copy()->addMinutes($durationMinutes);
            $bufferEndUtc = $endUtc->copy()->addMinutes($bufferMinutes);

            // 2. Verify no overlapping active/hold booking exists
            $overlapCount = ServiceBooking::where('provider_id', $product->provider_id)
                ->where(function ($q) {
                    $q->whereIn('status', ['confirmed', 'in_progress'])
                        ->orWhere(function ($holdQuery) {
                            $holdQuery->where('status', 'hold')
                                ->where('hold_expires_at', '>', Carbon::now('UTC'));
                        });
                })
                ->where('start_time', '<', $bufferEndUtc)
                ->where('buffer_end_time', '>', $startUtc)
                ->count();

            if ($overlapCount > 0) {
                throw new Exception("Slot jadwal MUA pada waktu tersebut sudah terisi atau sedang di-hold pelanggan lain. Silakan pilih jadwal lain.");
            }

            // 3. Create hold booking record (expires in 10 minutes)
            return ServiceBooking::create([
                'provider_id' => $product->provider_id,
                'customer_id' => $customer->id,
                'product_id' => $product->id,
                'start_time' => $startUtc,
                'end_time' => $endUtc,
                'buffer_end_time' => $bufferEndUtc,
                'status' => 'hold',
                'hold_expires_at' => Carbon::now('UTC')->addMinutes(10),
                'notes' => $notes,
            ]);
        });
    }

    /**
     * Release expired holds (can be run via cron scheduler or command).
     */
    public function releaseExpiredHolds(): int
    {
        return ServiceBooking::where('status', 'hold')
            ->where('hold_expires_at', '<=', Carbon::now('UTC'))
            ->update(['status' => 'expired']);
    }

    /**
     * Provider marks service booking as completed.
     */
    public function completeBooking(ServiceBooking $booking, User $user): void
    {
        if ($booking->provider->user_id !== $user->id && !$user->isAdmin()) {
            throw new Exception("Akses ditolak: Hanya studio penyedia jasa yang dapat menandai layanan selesai.");
        }

        $booking->update(['status' => 'completed']);
    }

    /**
     * Cancel service booking.
     */
    public function cancelBooking(ServiceBooking $booking, User $user, string $reason): void
    {
        $isCustomer = ($booking->customer_id === $user->id);
        $isProvider = ($booking->provider->user_id === $user->id);

        if (!$isCustomer && !$isProvider && !$user->isAdmin()) {
            throw new Exception("Akses ditolak.");
        }

        $booking->update([
            'status' => 'cancelled',
            'notes' => ($booking->notes ? $booking->notes . ' | ' : '') . "Dibatalkan: {$reason}",
        ]);
    }
}
