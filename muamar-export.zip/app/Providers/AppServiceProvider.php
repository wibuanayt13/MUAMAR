<?php

namespace App\Providers;

use App\Contracts\PaymentGatewayAdapterInterface;
use App\Services\Payment\OfficialGatewayAdapter;
use App\Services\Payment\SandboxQrisAdapter;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        $this->app->bind(PaymentGatewayAdapterInterface::class, function () {
            $driver = env('PAYMENT_GATEWAY_DRIVER', 'sandbox');

            return match ($driver) {
                'official', 'production' => new OfficialGatewayAdapter(),
                default => new SandboxQrisAdapter(),
            };
        });
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        //
    }
}
