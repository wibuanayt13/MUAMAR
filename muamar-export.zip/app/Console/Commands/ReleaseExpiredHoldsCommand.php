<?php

namespace App\Console\Commands;

use App\Services\BookingSchedulerService;
use App\Services\RentalSchedulerService;
use Illuminate\Console\Command;

class ReleaseExpiredHoldsCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'muamar:release-holds';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Release expired 10-minute hold bookings and rentals to free up slots for other customers';

    /**
     * Execute the console command.
     */
    public function handle(
        BookingSchedulerService $bookingScheduler,
        RentalSchedulerService $rentalScheduler
    ): int {
        $serviceCount = $bookingScheduler->releaseExpiredHolds();
        $rentalCount = $rentalScheduler->releaseExpiredHolds();

        $this->info("Successfully released {$serviceCount} expired service hold(s) and {$rentalCount} expired rental hold(s).");

        return Command::SUCCESS;
    }
}
