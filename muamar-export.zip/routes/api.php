<?php

use App\Http\Controllers\PaymentWebhookController;
use App\Models\Product;
use App\Services\BookingSchedulerService;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::middleware(['throttle:120,1'])->group(function () {
    Route::post('/payments/webhook', [PaymentWebhookController::class, 'handle'])
        ->name('api.payment.webhook');

    Route::get('/services/{id}/availability', function (int $id, Request $request, BookingSchedulerService $scheduler) {
        $product = Product::with('serviceProfile')->findOrFail($id);
        $dateStr = $request->input('date', now()->format('Y-m-d'));
        $timeStr = $request->input('time', '09:00:00');

        $startUtc = Carbon::parse("{$dateStr} {$timeStr}", 'Asia/Jakarta')->utc();
        $isAvailable = $scheduler->isSlotAvailable($product, $startUtc);

        return response()->json([
            'product_id' => $product->id,
            'start_utc' => $startUtc->toIso8601String(),
            'is_available' => $isAvailable,
        ]);
    })->name('api.services.availability');

    Route::get('/services/{id}/slots', function (int $id, Request $request, BookingSchedulerService $scheduler) {
        $product = Product::with(['serviceProfile', 'provider'])->findOrFail($id);
        $dateStr = $request->input('date', now()->addDay()->format('Y-m-d'));
        $date = Carbon::parse($dateStr, 'Asia/Jakarta');

        $slots = $scheduler->getAvailableSlots($product, $date);

        return response()->json([
            'product_id' => $product->id,
            'date' => $date->format('Y-m-d'),
            'slots' => $slots,
        ]);
    })->name('api.services.slots');

    Route::get('/rentals/{id}/capacity', function (int $id, Request $request, \App\Services\RentalSchedulerService $scheduler) {
        $product = Product::with('rentalProfile')->findOrFail($id);
        $startDateStr = $request->input('start_date', now()->addDays(2)->format('Y-m-d'));
        $endDateStr = $request->input('end_date', now()->addDays(3)->format('Y-m-d'));

        $startUtc = Carbon::parse($startDateStr)->utc();
        $endUtc = Carbon::parse($endDateStr)->utc();

        $remaining = $scheduler->getRemainingCapacity($product, $startUtc, $endUtc);
        $total = $product->rentalProfile?->total_units ?? 0;

        return response()->json([
            'product_id' => $product->id,
            'start_date' => $startDateStr,
            'end_date' => $endDateStr,
            'total_units' => $total,
            'remaining_units' => $remaining,
            'is_available' => $remaining > 0,
        ]);
    })->name('api.rentals.capacity');
});
