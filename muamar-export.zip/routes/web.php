<?php

use App\Http\Controllers\AdminModerationController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\CatalogController;
use App\Http\Controllers\ChatController;
use App\Http\Controllers\CheckoutController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\NotificationController;
use App\Http\Controllers\ProviderBookingFulfillmentController;
use App\Http\Controllers\ProviderOnboardingController;
use App\Http\Controllers\ProviderOrderController;
use App\Http\Controllers\ProviderProductController;
use App\Http\Controllers\ProviderProfileController;
use App\Http\Controllers\ProviderScheduleController;
use App\Http\Controllers\ReviewController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| MUAMAR Web Routes
|--------------------------------------------------------------------------
*/

// Public Routes
Route::get('/', [HomeController::class, 'index'])->name('home');

Route::middleware(['throttle:60,1'])->group(function () {
    Route::get('/catalog', [CatalogController::class, 'index'])->name('catalog.index');
    Route::get('/catalog/{slug}', [CatalogController::class, 'show'])->name('catalog.show');
    Route::get('/providers/map', [CatalogController::class, 'map'])->name('providers.map');
});

// Guest Auth Routes (Rate Limited: 6 requests per min)
Route::middleware(['guest', 'throttle:6,1'])->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])->name('login.post');
    Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
    Route::post('/register', [AuthController::class, 'register'])->name('register.post');
});

// Authenticated Routes
Route::middleware(['auth'])->group(function () {
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

    // Customer Dashboard & Onboarding
    Route::get('/customer/dashboard', [DashboardController::class, 'customerDashboard'])->name('customer.dashboard');
    Route::get('/provider/onboard', [ProviderOnboardingController::class, 'showOnboard'])->name('provider.onboard');
    Route::post('/provider/onboard', [ProviderOnboardingController::class, 'storeOnboard'])->name('provider.onboard.post');

    // Provider Studio Dashboard & Order Management
    Route::middleware(['role:provider,admin'])->prefix('provider')->name('provider.')->group(function () {
        Route::get('/dashboard', [DashboardController::class, 'providerDashboard'])->name('dashboard');
        Route::patch('/orders/{vendorOrderId}/ship', [ProviderOrderController::class, 'shipOrder'])->name('orders.ship');
        Route::post('/orders/{vendorOrderId}/tracking-update', [ProviderOrderController::class, 'addShippingUpdate'])->name('orders.tracking-update');
        Route::patch('/orders/{vendorOrderId}/confirm-cod', [ProviderOrderController::class, 'confirmCod'])->name('orders.confirm-cod');
        Route::patch('/orders/{vendorOrderId}/reject-cod', [ProviderOrderController::class, 'rejectCod'])->name('orders.reject-cod');

        // Fulfillment of bookings & rentals
        Route::patch('/bookings/{id}/complete', [ProviderBookingFulfillmentController::class, 'completeService'])->name('bookings.complete');
        Route::patch('/rentals/{id}/pickup', [ProviderBookingFulfillmentController::class, 'pickupRental'])->name('rentals.pickup');
        Route::patch('/rentals/{id}/return', [ProviderBookingFulfillmentController::class, 'returnRental'])->name('rentals.return');

        // CRUD Products, Services, Rentals
        Route::get('/products', [ProviderProductController::class, 'index'])->name('products.index');
        Route::get('/products/create', [ProviderProductController::class, 'create'])->name('products.create');
        Route::post('/products', [ProviderProductController::class, 'store'])->name('products.store');
        Route::get('/products/{id}/edit', [ProviderProductController::class, 'edit'])->name('products.edit');
        Route::put('/products/{id}', [ProviderProductController::class, 'update'])->name('products.update');
        Route::delete('/products/{id}', [ProviderProductController::class, 'destroy'])->name('products.destroy');

        // Schedule & Working Hours Matrix
        Route::get('/schedule', [ProviderScheduleController::class, 'index'])->name('schedule.index');
        Route::put('/schedule', [ProviderScheduleController::class, 'updateWeekly'])->name('schedule.update');
        Route::post('/schedule/override', [ProviderScheduleController::class, 'storeOverride'])->name('schedule.override.store');
        Route::delete('/schedule/override/{id}', [ProviderScheduleController::class, 'destroyOverride'])->name('schedule.override.destroy');

        // Studio Profile & Map Opt-in
        Route::get('/profile', [ProviderProfileController::class, 'edit'])->name('profile.edit');
        Route::put('/profile', [ProviderProfileController::class, 'update'])->name('profile.update');
    });

    // Admin Dashboard & Moderation
    Route::middleware(['role:admin'])->prefix('admin')->name('admin.')->group(function () {
        Route::get('/dashboard', [DashboardController::class, 'adminDashboard'])->name('dashboard');
        Route::patch('/providers/{providerId}/verify', [AdminModerationController::class, 'verifyProvider'])->name('providers.verify');
        Route::patch('/providers/{providerId}/toggle-suspension', [AdminModerationController::class, 'toggleProviderSuspension'])->name('providers.toggle-suspension');
        Route::patch('/products/{productId}/toggle', [AdminModerationController::class, 'toggleProductStatus'])->name('products.toggle');
        Route::patch('/reviews/{reviewId}/toggle', [AdminModerationController::class, 'toggleReviewVisibility'])->name('reviews.toggle');
        Route::post('/categories', [AdminModerationController::class, 'storeCategory'])->name('categories.store');
        Route::delete('/categories/{categoryId}', [AdminModerationController::class, 'deleteCategory'])->name('categories.destroy');
    });

    // Cart & Multi-vendor Checkout (Rate limited)
    Route::get('/cart', [CartController::class, 'index'])->name('cart.index');
    Route::post('/cart/add', [CartController::class, 'add'])->name('cart.add');
    Route::patch('/cart/{id}', [CartController::class, 'updateQuantity'])->name('cart.update');
    Route::delete('/cart/{id}', [CartController::class, 'remove'])->name('cart.remove');

    Route::middleware(['throttle:10,1'])->group(function () {
        Route::get('/checkout', [CheckoutController::class, 'showCheckout'])->name('checkout.show');
        Route::post('/checkout', [CheckoutController::class, 'processCheckout'])->name('checkout.process');
    });

    Route::get('/orders/{orderNumber}/invoice', [CheckoutController::class, 'showInvoice'])->name('order.invoice');
    Route::get('/orders/{orderNumber}/print', [CheckoutController::class, 'printInvoice'])->name('order.print');

    // Messaging & Chat (Rate limited: 30 msgs/min)
    Route::get('/conversations', [ChatController::class, 'index'])->name('chat.index');
    Route::get('/conversations/{id}', [ChatController::class, 'show'])->name('chat.show');
    Route::middleware(['throttle:30,1'])->group(function () {
        Route::post('/conversations/start', [ChatController::class, 'start'])->name('chat.start');
        Route::post('/conversations/{id}/messages', [ChatController::class, 'send'])->name('chat.send');
    });

    // Reviews & Ratings (Rate limited: 15/min)
    Route::middleware(['throttle:15,1'])->group(function () {
        Route::post('/reviews', [ReviewController::class, 'store'])->name('reviews.store');
        Route::post('/reviews/{id}/reply', [ReviewController::class, 'reply'])->name('reviews.reply');
    });

    // In-app Notifications
    Route::get('/notifications', [NotificationController::class, 'index'])->name('notifications.index');
    Route::post('/notifications/{id}/read', [NotificationController::class, 'markAsRead'])->name('notifications.read');
    Route::post('/notifications/read-all', [NotificationController::class, 'markAllAsRead'])->name('notifications.read-all');
});
