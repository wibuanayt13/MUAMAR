<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Mailgun, Postmark, AWS and more. This file provides the de facto
    | location for this type of information, allowing packages to have
    | a conventional file to locate the various service credentials.
    |
    */

    'postmark' => [
        'token' => env('POSTMARK_TOKEN'),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],

    'slack' => [
        'notifications' => [
            'bot_user_oauth_token' => env('SLACK_BOT_USER_OAUTH_TOKEN'),
            'channel' => env('SLACK_BOT_USER_DEFAULT_CHANNEL'),
        ],
    ],

    'payment' => [
        'driver' => env('PAYMENT_GATEWAY_DRIVER', 'sandbox'),
        'merchant_id' => env('PAYMENT_GATEWAY_MERCHANT_ID', 'MUA_MOCK_MERCHANT_01'),
        'client_key' => env('PAYMENT_GATEWAY_CLIENT_KEY'),
        'server_key' => env('PAYMENT_GATEWAY_SERVER_KEY'),
        'webhook_secret' => env('PAYMENT_GATEWAY_WEBHOOK_SECRET', 'muamar_secret_webhook_signature_key'),
    ],

];
