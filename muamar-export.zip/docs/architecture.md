# Arsitektur Sistem MUAMAR (Marketplace Make-Up Artist & Event)

## 1. Ringkasan Eksekutif & Karakteristik Sistem
**MUAMAR** adalah platform marketplace multi-vendor terintegrasi yang dirancang khusus untuk ekosistem Make-Up Artist (MUA), produk kosmetik/makeup, layanan kecantikan, serta penyewaan perlengkapan acara/wedding (tenda, panggung, busana pengantin).

Aplikasi mengadopsi pola modular **Domain-Driven Design (DDD)** ringan berbasis **Laravel 11**, **PHP 8.2+**, dan **MySQL 8+ / MariaDB (InnoDB)** dengan transaksi ACID, locking baris atomik (`SELECT FOR UPDATE`), serta penanganan waktu berbasis interval UTC `[start_at, end_at)`.

---

## 2. Diagram Arsitektur Tingkat Tinggi
```mermaid
flowchart TD
    Client["Client Layer (Responsive Web / Mobile-First Blade & Tailwind)"]
    WebRouter["Routing & Middleware Layer (Auth, Role, Rate Limiter, CSRF)"]
    
    subgraph Controllers["Thin Controllers Layer"]
        AuthController["Auth & Onboarding"]
        CatalogController["Catalog & Search"]
        CartController["Cart & Checkout"]
        BookingController["Booking & Rental Scheduler"]
        PaymentController["Payment Adapter & Webhook"]
        ProviderController["Provider Studio Management"]
        ChatController["Messaging"]
        ReviewController["Reviews & Rating"]
        AdminController["Admin Moderation & Audit"]
    end

    subgraph DomainServices["Domain Service Layer (Business Logic & Concurrency)"]
        BookingService["BookingSchedulerService (Interval Overlap & Hold Expiry)"]
        RentalService["RentalSchedulerService (Capacity & Deposit Overlap)"]
        OrderService["OrderCheckoutService (Stock Atomic Lock & Multi-vendor Split)"]
        PaymentGateway["PaymentGatewayAdapter (QRIS Generator & Webhook Idempotency)"]
        ShippingService["ManualShippingService (Tracking History)"]
        AuditService["AuditTrailService (Admin & Payment Event Logs)"]
    end

    subgraph DataAccess["Data Access Layer (Eloquent Models, Policies, DB Transactions)"]
        DB[(MySQL 8+ / MariaDB InnoDB)]
        Storage[(Public Storage / S3)]
        QueueWorker["Queue Worker & Task Scheduler (10-Min Hold Release)"]
    end

    Client -->|HTTP / AJAX / SSE| WebRouter
    WebRouter --> Controllers
    Controllers --> DomainServices
    DomainServices --> DataAccess
    QueueWorker --> DomainServices
```

---

## 3. Pemisahan Domain (Bounded Contexts)
Aplikasi membagi tanggung jawab ke dalam 10 domain spesifik:

1. **Catalog Domain (`App\Domains\Catalog`)**:
   - Taksonomi kategori hierarkis (Produk Fisik, Jasa MUA, Sewa Tenda & Alat Event).
   - Pencarian multi-kriteria: keyword full-text, radius geospasial (haversine formula), filter rating, dan rentang harga.
2. **Provider Onboarding & Management Domain (`App\Domains\Provider`)**:
   - Profil studio/usaha, opt-in koordinat publik untuk peta discovery konsumen.
   - Manajemen katalog produk, varian SKU, profil jasa durasi/buffer, profil rental kuantitas/deposit.
   - Pengaturan jam kerja mingguan (`provider_availabilities`) dan libur tentatif (`provider_schedules_override`).
3. **Cart & Multi-Vendor Checkout Domain (`App\Domains\Checkout`)**:
   - Keranjang multi-item dari beragam vendor.
   - Server-side stock atomicity lock: Mengamankan stok fisik dengan `SELECT FOR UPDATE` saat checkout.
   - Split pesanan: 1 induk `orders` dipecah menjadi `vendor_orders` individual untuk tiap provider.
   - Snapshot harga, nama, varian, dan alamat pengiriman statis yang tidak dapat diubah oleh perubahan listing di kemudian hari.
4. **Payment Gateway & QRIS Domain (`App\Domains\Payment`)**:
   - Adapter pattern (`PaymentGatewayInterface`) dengan implementasi sandbox mock dan integrasi gateway resmi.
   - Dynamic QRIS generation dengan payload standard ASPI/BI.
   - Webhook signature verification (HMAC-SHA256) untuk mencegah tampering.
   - Tabel `payment_audit_logs` dan idempotency key check untuk memastikan webhook duplikat tidak memicu mutasi status ganda.
   - Alur COD (Cash on Delivery): Pesanan COD tidak dianggap lunas sampai kurir/penjual mengonfirmasi penerimaan tunai secara eksplisit.
5. **Service Booking Domain (`App\Domains\Booking`)**:
   - Interval booking semi-terbuka `[start_at, end_at)` yang disimpan dalam format **UTC**.
   - Penambahan `buffer_minutes` untuk waktu persiapan dan perjalanan artist MUA.
   - Slot hold sementara selama **10 menit** saat proses checkout; jika tidak dibayar dalam 10 menit, scheduler otomatis melepas hold.
   - Deteksi bentrok atomik dengan row-locking pada provider/artist.
6. **Rental Asset Domain (`App\Domains\Rental`)**:
   - Aset sewa (sewa tenda, kursi, baju pengantin) dengan kuantitas multi-unit.
   - Pengecekan overlap kapasitas: `SUM(quantity_rented) + requested_quantity <= total_units` pada semua interval sewa yang bersinggungan.
   - Manajemen uang jaminan / deposit perlengkapan.
7. **Messaging & Chat Domain (`App\Domains\Messaging`)**:
   - Komunikasi privat antara customer dan provider.
   - Kebijakan otorisasi ketat (`ConversationPolicy`): User hanya dapat melihat chat di mana ia berpartisipasi sebagai `customer_id` atau pemilik `provider_id`.
8. **Shipping & Fulfillment Domain (`App\Domains\Shipping`)**:
   - Pengiriman manual: Seller memasukkan nama ekspedisi/kurir lokal, nomor resi, dan tanggal kirim.
   - Riwayat status pengiriman per vendor order (`shipping_histories`).
9. **Review & Rating Domain (`App\Domains\Review`)**:
   - Ulasan hanya diizinkan untuk customer yang telah menyelesaikan pesanan (`status = completed`).
   - 1 review per `order_item_id` (relasi 1-to-1 unik) untuk mencegah ulasan spam ganda.
10. **Admin Moderation & Audit Domain (`App\Domains\Admin`)**:
    - Verifikasi provider baru, moderasi listing, penanganan keluhan transaksi, serta logging audit lengkap seluruh tindakan staf/admin.

---

## 4. Mekanisme Scheduler Anti-Bentrok & Matematika Overlap
### 4.1 Definisi Interval
Semua waktu janji temu dan persewaan dikonversi ke **UTC** saat disimpan ke basis data.
Dua interval $A = [start_A, end_A)$ dan $B = [start_B, end_B)$ saling tumpang tindih (overlap) jika dan hanya jika:
$$start_A < end_B \quad \text{DAN} \quad end_A > start_B$$

Untuk jasa MUA dengan jeda perjalanan (buffer):
$$effective\_end = end\_time + buffer\_minutes$$

### 4.2 Prosedur Eksekusi Database Transaction & Row Locking
```sql
START TRANSACTION;
-- 1. Kunci baris provider untuk mencegah race condition
SELECT id FROM providers WHERE id = :provider_id FOR UPDATE;

-- 2. Cek apakah ada booking aktif (hold tidak expired ATAU confirmed) pada interval
SELECT COUNT(*) FROM service_bookings 
WHERE provider_id = :provider_id 
  AND status IN ('confirmed', 'in_progress', 'hold')
  AND (status != 'hold' OR hold_expires_at > UTC_TIMESTAMP())
  AND start_time < :requested_buffer_end
  AND buffer_end_time > :requested_start;

-- 3. Jika COUNT == 0, insert hold booking baru dengan hold_expires_at = UTC_TIMESTAMP() + 10 MENIT
-- COMMIT;
```

---

## 5. Keamanan & Idempotensi Pembayaran
- **Webhook Idempotency**: Setiap incoming payload webhook diverifikasi keunikannya menggunakan `provider_reference` / `payment_reference`. Jika transaksi sudah tercatat sebagai `paid`, webhook duplikat dicatat dalam audit log dan diabaikan tanpa re-trigger event order.
- **HMAC Signature Check**: Parameter `signature_key = hash("sha256", order_number + status_code + gross_amount + server_key)`. Webhook dengan tanda tangan tidak cocok langsung di-reject dengan HTTP 401/403.
- **Amount Tampering Defense**: Jumlah tagihan divalidasi mutlak dari baris database `orders.total_amount`, bukan dari request client.
