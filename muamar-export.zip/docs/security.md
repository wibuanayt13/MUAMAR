# Kebijakan & Arsitektur Keamanan (Security Hardening) MUAMAR

Sistem MUAMAR dirancang dengan prinsip **Defense-in-Depth** untuk melindungi data pengguna, integritas inventaris, serta transaksi finansial.

---

## 1. Otorisasi Ketat & Pencegahan IDOR (Insecure Direct Object Reference)
- Setiap resource dilindungi oleh **Laravel Policies**:
  - `OrderPolicy`: Customer hanya dapat mengakses order miliknya (`order.user_id === auth()->id()`). Provider hanya dapat melihat sub-order miliknya (`vendor_order.provider_id === auth()->user()->provider->id`).
  - `ConversationPolicy`: User yang bukan merupakan `customer_id` atau pemilik `provider_id` dilarang melihat atau mengirim pesan ke percakapan tersebut.
  - `ProductPolicy`: Seller A sama sekali tidak dapat memperbarui, menghapus, atau mengubah stok produk milik Seller B.
  - `ReviewPolicy`: Ulasan hanya dapat dibuat jika `order_items.vendor_order.order.user_id === auth()->id()` dan status vendor order adalah `completed`.

---

## 2. Integritas Konkurensi & Double-Spending / Double-Booking Prevention
1. **Pessimistic Row Locking (`SELECT FOR UPDATE`)**:
   - Saat checkout produk fisik:
     ```php
     $variant = ProductVariant::where('id', $variantId)->lockForUpdate()->first();
     if ($variant->stock < $qty) {
         throw new InsufficientStockException("Stok tidak mencukupi.");
     }
     $variant->decrement('stock', $qty);
     ```
2. **Scheduler Interval Lock (Service & Rental)**:
   - Penguncian baris `providers` atau `rental_profiles` dilakukan di dalam DB Transaction sebelum memeriksa irisan waktu `[start, end)`.
   - Mencegah dua pelanggan melakukan booking slot artist yang sama secara paralel.

---

## 3. Perlindungan Privasi Pelanggan & Geospasial
- **Customer Privacy**: Alamat rumah, nomor telepon, dan lokasi customer bersifat rahasia dan hanya dapat diakses oleh provider tempat customer tersebut melakukan order aktif.
- **Provider Public Map**:
  - Hanya provider dengan `is_location_public = true` dan `status = approved` yang dimunculkan pada peta publik.
  - Endpoint publik tidak pernah mengekspos data pribadi non-publik.

---

## 4. Keamanan Pembayaran & Verifikasi Webhook
- **HMAC Signature Check**: Webhook dari payment gateway diverifikasi menggunakan algoritma hash rahasia:
  $$\text{Expected Signature} = \text{hash\_hmac}('sha256', \text{order\_number} + \text{amount} + \text{status}, \text{secret\_key})$$
- **Idempotensi Transaksi**:
  - Sebelum mengubah status `payments` atau `orders`, sistem memeriksa apakah status saat ini sudah `paid`.
  - Jika sudah `paid`, webhook dicatat di `payment_audit_logs` dengan event `idempotent_duplicate_skipped` dan langsung mengembalikan HTTP 200 tanpa mengeksekusi mutasi ulang.
- **No Client Trust**:
  - Nilai tagihan selalu dihitung ulang di server side dari snapshot harga database, bukan dari input formulir browser.
  - COD berstatus `unpaid` sampai penjual/kurir secara eksplisit mengklik konfirmasi terima uang tunai.

---

## 5. Keamanan Upload File (Foto Produk & Bukti)
- Validasi ketat tipe MIME: Hanya memperbolehkan `image/jpeg`, `image/png`, `image/webp`.
- Batas ukuran maksimum: 3MB.
- Penamaan file acak (`Str::random(40) . '.' . $extension`) untuk mencegah path traversal dan overwriting.
- Folder penyimpanan `storage/app/public` dikonfigurasi tanpa hak eksekusi script PHP.

---

## 6. Rate Limiting & Proteksi Brute-Force
- Rate limiter diterapkan di middleware rute:
  - Auth (Login / Register): `throttle:6,1` (6 percobaan per menit).
  - Search / Catalog: `throttle:60,1` (60 request per menit).
  - Checkout & Multi-vendor process: `throttle:10,1` (10 request per menit).
  - Chat Messaging: `throttle:30,1` (30 pesan per menit).
  - Reviews Submission: `throttle:15,1` (15 request per menit).
  - Webhook API: `throttle:120,1` (120 request per menit).

---

## 7. Audit Trail & Moderasi Admin
- Seluruh aksi sensitif tingkat administrator dicatat secara permanen di tabel `admin_audit_logs`:
  - `action`: e.g. `provider_verified`, `provider_status_toggled`, `product_status_toggled`, `review_visibility_toggled`, `category_created`, `category_deleted`.
  - `old_values` & `new_values`: snapshot JSON sebelum dan sesudah perubahan.
  - `ip_address` & `user_id`: identifikasi pengubah dan asal IP request.

---

## 8. Sanitasi Output & Pencegahan XSS & CSRF
- Semua rendering data input pengguna di template Blade menggunakan escaping otomatis `{{ $data }}`.
- Tag skrip `<script>` atau tag HTML berbahaya yang dimasukkan ke ulasan atau chat secara otomatis dikonversi menjadi entitas HTML aman (`&lt;script&gt;`).
- Seluruh formulir web wajib menggunakan token validasi `@csrf`. Permintaan tanpa token valid ditolak dengan HTTP 419 Page Expired.
