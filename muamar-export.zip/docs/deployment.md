# Panduan Deployment Produksi MUAMAR

Dokumen ini memuat langkah-langkah implementasi dan konfigurasi server produksi untuk aplikasi web marketplace MUAMAR.

---

## 1. Prasyarat Server
- **Sistem Operasi**: Linux Ubuntu 22.04 LTS / Debian 12
- **Web Server**: Nginx 1.22+
- **PHP**: PHP 8.2+ dengan ekstensi:
  - `php8.2-fpm`, `php8.2-mysql`, `php8.2-mbstring`, `php8.2-xml`, `php8.2-curl`, `php8.2-zip`, `php8.2-bcmath`, `php8.2-gd`
- **Database**: MySQL 8.0+ atau MariaDB 10.6+ (Engine InnoDB, utf8mb4_unicode_ci)
- **Node.js**: Node 20 LTS & NPM
- **Process Manager**: Supervisor (untuk Queue Worker)

---

## 2. Pengaturan Basis Data & Konfigurasi Lingkungan
1. Buat database dan user MySQL:
   ```sql
   CREATE DATABASE muamar_prod CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   CREATE USER 'muamar_user'@'localhost' IDENTIFIED BY 'StrongPasswordHere123!';
   GRANT ALL PRIVILEGES ON muamar_prod.* TO 'muamar_user'@'localhost';
   FLUSH PRIVILEGES;
   ```

2. Konfigurasi `.env` Produksi:
   ```env
   APP_NAME="MUAMAR"
   APP_ENV=production
   APP_KEY=base64:GENERATE_DENGAN_ARTISAN_KEY_GENERATE
   APP_DEBUG=false
   APP_TIMEZONE=Asia/Jakarta
   APP_URL=https://muamar.id

   DB_CONNECTION=mysql
   DB_HOST=127.0.0.1
   DB_PORT=3306
   DB_DATABASE=muamar_prod
   DB_USERNAME=muamar_user
   DB_PASSWORD=StrongPasswordHere123!
   DB_COLLATION=utf8mb4_unicode_ci

   SESSION_DRIVER=database
   QUEUE_CONNECTION=database
   CACHE_STORE=database
   FILESYSTEM_DISK=public

   # Kredensial Resmi Payment Gateway QRIS
   PAYMENT_GATEWAY_DRIVER=production
   PAYMENT_GATEWAY_MERCHANT_ID=MID_PROD_12345
   PAYMENT_GATEWAY_CLIENT_KEY=client_key_prod_abcdef
   PAYMENT_GATEWAY_SERVER_KEY=server_key_prod_uvwxyz
   PAYMENT_GATEWAY_WEBHOOK_SECRET=secret_webhook_signature_prod_key
   ```

---

## 3. Langkah Instalasi & Build
```bash
# 1. Clone repository & install composer dependensi tanpa dev
composer install --no-dev --optimize-autoloader

# 2. Generate Application Key jika belum ada
php artisan key:generate --force

# 3. Jalankan migrasi basis data
php artisan migrate --force

# 4. Symbolic link storage publik
php artisan storage:link

# 5. Optimasi cache route, config, dan views
php artisan config:cache
php artisan route:cache
php artisan view:cache

# 6. Set hak akses direktori
sudo chown -R www-data:www-data storage bootstrap/cache
sudo chmod -R 775 storage bootstrap/cache
```

---

## 4. Konfigurasi Task Scheduler (Cron) & Queue Worker (Supervisor)
### 4.1 Cron Job Laravel (Release Hold Expired & Maintenance)
Buka crontab: `crontab -e -u www-data`
Tambahkan baris berikut:
```cron
* * * * * cd /var/www/muamar && php artisan schedule:run >> /dev/null 2>&1
```

### 4.2 Supervisor Queue Worker
File konfigurasi `/etc/supervisor/conf.d/muamar-worker.conf`:
```ini
[program:muamar-worker]
process_name=%(program_name)s_%(process_num)02d
command=php /var/www/muamar/artisan queue:work database --sleep=3 --tries=3 --max-time=3600
autostart=true
autorestart=true
stopasgroup=true
killasgroup=true
user=www-data
numprocs=2
redirect_stderr=true
stdout_logfile=/var/www/muamar/storage/logs/worker.log
stopwaitsecs=3600
```
Update supervisor:
```bash
sudo supervisorctl reread
sudo supervisorctl update
sudo supervisorctl start muamar-worker:*
```
