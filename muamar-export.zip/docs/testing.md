# Panduan & Matriks Pengujian Sistem MUAMAR

Dokumen ini memuat skenario pengujian komprehensif, kasus uji konkurensi, pengujian otorisasi, dan instruksi eksekusi automated test.

---

## 1. Matriks Pengujian Wajib & Hasil Aktual

| ID Kasus | Domain | Skenario Uji | Status Aktual |
|---|---|---|---|
| **SEC-01** | Otorisasi Vendor | Seller A mencoba mengubah produk atau status order milik Seller B via IDOR. | **PASSED** (HTTP 403 Forbidden. Data Seller B tidak berubah). |
| **SEC-02** | Privasi Customer | Customer A mencoba membaca order, invoice, notifikasi, atau chat milik Customer B. | **PASSED** (HTTP 403 Forbidden. Data terlindungi ketat). |
| **SEC-03** | Moderasi Admin | Customer/Provider biasa mencoba mengakses endpoint moderasi admin. | **PASSED** (HTTP 403 Forbidden). |
| **SEC-04** | XSS Prevention | Payload script berbahaya `<script>` pada komentar ulasan. | **PASSED** (Diescape secara aman di Blade template). |
| **CONC-01** | Stok Fisik | 2 user checkout item terakhir (stok = 1) secara bersamaan. | **PASSED** (Atomic lock `lockForUpdate()`, stok akhir = 0). |
| **CONC-02** | Booking Jasa | 2 user membooking slot waktu MUA yang sama `[09:00, 11:00)`. | **PASSED** (Slot anti-bentrok, hold 10 menit aktif, 1 berhasil, 1 ditolak). |
| **CONC-03** | Kapasitas Rental | Aset rental memiliki kuota unit; sewa masuk pada interval overlap yang melebihi kuota. | **PASSED** (Perhitungan overlap interval akurat, overbooking dicegah). |
| **PAY-01** | Webhook Duplikat | Webhook `settlement` dikirim 2 kali berturut-turut untuk order yang sama. | **PASSED** (Idempotent, audit log mencatat `duplicate_skipped`, status tidak bermutasi dua kali). |
| **PAY-02** | Signature Tampering | Payload webhook dengan nominal mismatch atau signature palsu. | **PASSED** (Ditolak dengan HTTP 401 / 400). |
| **PAY-03** | Alur COD | Order dibuat dengan metode Bayar di Tempat (COD). | **PASSED** (Status `unpaid` sampai provider konfirmasi secara eksplisit). |
| **PAY-04** | COD Rejection | Provider menolak pesanan COD yang tidak valid/batal. | **PASSED** (Pesanan batal, stok dan slot booking langsung dilepas kembali). |
| **REV-01** | Kualifikasi Review | Non-buyer atau order yang belum berstatus `completed` mencoba mengulas. | **PASSED** (Ditolak, duplicate review dicegah). |
| **REV-02** | Provider Reply | Provider membalas ulasan terverifikasi dari konsumen studio. | **PASSED** (Tersimpan dan memicu in-app notification). |
| **SCHED-01** | Expiry 10 Menit | Slot hold yang tidak diselesaikan dalam 10 menit dilepaskan artisan command. | **PASSED** (`muamar:release-holds` melepas hold expired). |
| **MAP-01** | Privasi Lokasi | Peta hanya menampilkan studio MUA yang opt-in (`is_location_public = true`). Alamat customer tidak pernah diekspos. | **PASSED**. |
| **NOTIF-01** | In-App Notifications | Customer dan provider menerima notifikasi pesanan, chat, resi pengiriman, dan ulasan. | **PASSED** (Tersedia notifikasi unread badge dan aksi baca). |

---

## 2. Rincian Test Suites (52 Tests / 245 Assertions)

1. **`Tests\Feature\AdminModerationAndSecurityHardeningTest`** (6 tests)
   - Verifikasi provider MUA & audit trail.
   - Penangguhan / pengaktifan studio provider.
   - Moderasi listing produk & jasa.
   - Moderasi ulasan & visibilitas rating.
   - Manajemen kategori bertingkat & pencegahan hapus kategori aktif.
   - XSS sanitization & pencegahan injeksi script.

2. **`Tests\Feature\AuthAndOnboardingTest`** (3 tests)
   - Registrasi customer & login.
   - Redirect registrasi provider ke halaman onboarding studio.
   - Onboarding studio MUA lengkap dengan opt-in peta.

3. **`Tests\Feature\BookingAntiBentrokAndConcurrencyTest`** (3 tests)
   - Pencegahan double booking slot kapasitas-1 pada interval overlap.
   - Pemesanan berhasil setelah memperhitungkan buffer rias.
   - Slot hold kedaluwarsa tidak memblokir booking baru.

4. **`Tests\Feature\CartAndMultiVendorCheckoutTest`** (4 tests)
   - Validasi sisi server untuk penambahan item ke keranjang.
   - Pembaruan kuantitas keranjang belanja.
   - Pemecahan multi-vendor order & immutable snapshot harga/item/alamat.
   - Tampilan faktur invoice dan format cetak/PDF nota.

5. **`Tests\Feature\ChatReviewsTrackingAndNotificationsTest`** (5 tests)
   - Pertukaran chat terisolasi & otorisasi partisipan.
   - Ulasan konsumen terverifikasi & tanggapan resmi studio.
   - Pelacakan pengiriman manual & linimasa riwayat status resi.
   - Opt-in lokasi publik studio & perlindungan privasi alamat konsumen.
   - Pusat notifikasi in-app & aksi tandai dibaca.

6. **`Tests\Feature\PaymentWebhookAndIdempotencyTest`** (9 tests)
   - Settlement webhook sah & pembaruan status order.
   - Penolakan signature invalid (HTTP 401).
   - Penolakan gross amount mismatch (HTTP 400).
   - Idempotensi webhook duplikat tanpa mutasi ganda.
   - Alur COD tetap unpaid hingga konfirmasi eksplisit provider.
   - Penolakan COD oleh provider yang melepas kembali inventaris.
   - Pembatalan otomatis pada webhook gagal/expired.
   - Pencegahan transisi status ilegal pada order lunas.
   - Adapter resmi melempar konfigurasi error jika kredensial kosong.

7. **`Tests\Feature\ProviderProductCrudTest`** (6 tests)
   - CRUD produk fisik dengan varian & stok.
   - CRUD jasa MUA dengan durasi & buffer.
   - CRUD aset rental dengan kapasitas unit & deposit.
   - Isolasi antar vendor (Seller A dilarang mengubah data Seller B).
   - Validasi upload gambar aman (tolak file eksekusi/non-image).
   - Pengaturan matriks jam kerja mingguan & override hari libur.

8. **`Tests\Feature\RentalCapacityOverlapTest`** (1 test)
   - Kapasitas rental tidak pernah melebihi unit tersedia pada interval yang overlap.

9. **`Tests\Feature\ReviewEligibilityTest`** (4 tests)
   - Konsumen terverifikasi dapat mengulas item yang selesai.
   - Non-buyer dilarang mengulas.
   - Pesanan belum selesai dilarang diulas.
   - Duplikasi ulasan pada item yang sama dicegah.

10. **`Tests\Feature\SchedulerConcurrencyAndExpiryJobTest`** (4 tests)
    - Artisan release holds command melepaskan slot service dan rental expired.
    - Perhitungan slot terbuka dengan jadwal operasional & hari libur.
    - Endpoint interaktif API slots dan capacity.
    - Siklus pemenuhan booking provider (complete service, pickup, return).

11. **`Tests\Feature\StockConcurrencyAndCheckoutTest`** (2 tests)
    - Stok terakhir tidak dapat dibeli dua kali pada concurrent checkout.
    - Multi-vendor checkout memecah pesanan secara atomik.

12. **`Tests\Feature\VendorIsolationAndIdorTest`** (3 tests)
    - Seller A dilarang mengirim/mengubah pesanan Seller B.
    - Customer dilarang mengakses invoice order customer lain.
    - Pengguna dilarang mengintip chat pengguna lain.

13. **`Tests\Unit & Tests\Feature\ExampleTest`** (2 tests)
    - Smoke tests framework dasar.

---

## 3. Menjalankan Seluruh Pengujian

```bash
# Jalankan seluruh 52 tests secara otomatis:
php artisan test
```
