<?php

namespace Tests\Feature;

use App\Models\CartItem;
use App\Models\Category;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use App\Models\ProductVariant;
use App\Models\Provider;
use App\Models\RentalProfile;
use App\Models\ServiceProfile;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class CartAndMultiVendorCheckoutTest extends TestCase
{
    use RefreshDatabase;

    protected function setupVendorAndProducts(): array
    {
        $customer = User::factory()->create(['role' => 'customer']);

        $providerUser1 = User::factory()->create(['role' => 'provider']);
        $provider1 = Provider::create([
            'user_id' => $providerUser1->id,
            'business_name' => 'Studio Glam MUA',
            'slug' => 'studio-glam-mua',
            'address' => 'Jl. Thamrin 10',
            'city' => 'Jakarta Pusat',
            'phone' => '0811122233',
            'status' => 'approved',
        ]);

        $providerUser2 = User::factory()->create(['role' => 'provider']);
        $provider2 = Provider::create([
            'user_id' => $providerUser2->id,
            'business_name' => 'Pesta Tenda Wedding',
            'slug' => 'pesta-tenda-wedding',
            'address' => 'Jl. Riau 45',
            'city' => 'Bandung',
            'phone' => '0822233344',
            'status' => 'approved',
        ]);

        $catMUA = Category::create(['name' => 'MUA', 'slug' => 'mua', 'type' => 'service']);
        $catCosmetics = Category::create(['name' => 'Kosmetik', 'slug' => 'kosmetik', 'type' => 'product']);
        $catRental = Category::create(['name' => 'Rental', 'slug' => 'rental', 'type' => 'rental']);

        // 1. Service Product (Provider 1)
        $svcWedding = Product::create([
            'provider_id' => $provider1->id,
            'category_id' => $catMUA->id,
            'name' => 'Makeup Akad Nikah Glamour',
            'slug' => 'makeup-akad-nikah-glamour',
            'type' => 'service',
            'base_price' => 2000000,
            'is_active' => true,
        ]);
        ServiceProfile::create([
            'product_id' => $svcWedding->id,
            'duration_minutes' => 120,
            'buffer_minutes' => 30,
            'artist_name' => 'Kak Cindy',
        ]);

        // 2. Physical Product (Provider 1)
        $prodLipstick = Product::create([
            'provider_id' => $provider1->id,
            'category_id' => $catCosmetics->id,
            'name' => 'Lip Matte Classic',
            'slug' => 'lip-matte-classic',
            'type' => 'physical',
            'base_price' => 90000,
            'is_active' => true,
        ]);
        $variantRed = ProductVariant::create([
            'product_id' => $prodLipstick->id,
            'sku' => 'LIP-RED-01',
            'variant_name' => 'Ruby Red',
            'price' => 90000,
            'stock' => 15,
            'is_active' => true,
        ]);

        // 3. Rental Product (Provider 2)
        $rentalTenda = Product::create([
            'provider_id' => $provider2->id,
            'category_id' => $catRental->id,
            'name' => 'Tenda Plafon VIP 4x6',
            'slug' => 'tenda-plafon-vip-4x6',
            'type' => 'rental',
            'base_price' => 1500000,
            'is_active' => true,
        ]);
        RentalProfile::create([
            'product_id' => $rentalTenda->id,
            'total_units' => 8,
            'deposit_amount' => 400000,
            'min_rental_days' => 1,
            'buffer_hours' => 4,
            'unit_type' => 'unit tenda',
        ]);

        return [
            $customer,
            $provider1,
            $provider2,
            $svcWedding,
            $prodLipstick,
            $variantRed,
            $rentalTenda
        ];
    }

    public function test_customer_can_add_various_items_to_cart_with_server_validation(): void
    {
        [$customer, $p1, $p2, $svc, $prod, $varRed, $rental] = $this->setupVendorAndProducts();

        // 1. Add physical item
        $resPhysical = $this->actingAs($customer)->post('/cart/add', [
            'product_id' => $prod->id,
            'product_variant_id' => $varRed->id,
            'quantity' => 2,
        ]);
        $resPhysical->assertRedirect('/cart');
        $this->assertDatabaseHas('cart_items', [
            'user_id' => $customer->id,
            'product_id' => $prod->id,
            'quantity' => 2,
        ]);

        // 2. Add service item without schedule date (must fail)
        $resServiceFail = $this->actingAs($customer)->post('/cart/add', [
            'product_id' => $svc->id,
            'quantity' => 1,
        ]);
        $resServiceFail->assertSessionHas('error');

        // 3. Add service with valid future schedule date
        $futureDate = Carbon::now('UTC')->addDays(3)->setTime(9, 0)->format('Y-m-d H:i');
        $resServiceSuccess = $this->actingAs($customer)->post('/cart/add', [
            'product_id' => $svc->id,
            'booking_start' => $futureDate,
            'quantity' => 1,
        ]);
        $resServiceSuccess->assertRedirect('/cart');

        // 4. Add rental with invalid end date (before start date)
        $resRentalFail = $this->actingAs($customer)->post('/cart/add', [
            'product_id' => $rental->id,
            'booking_start' => Carbon::now()->addDays(5)->toDateString(),
            'booking_end' => Carbon::now()->addDays(2)->toDateString(), // invalid
            'quantity' => 1,
        ]);
        $resRentalFail->assertSessionHas('error');

        // 5. Add rental with valid dates
        $resRentalSuccess = $this->actingAs($customer)->post('/cart/add', [
            'product_id' => $rental->id,
            'booking_start' => Carbon::now()->addDays(5)->toDateString(),
            'booking_end' => Carbon::now()->addDays(7)->toDateString(),
            'quantity' => 2,
        ]);
        $resRentalSuccess->assertRedirect('/cart');

        // Total 3 items in cart
        $this->assertEquals(3, CartItem::where('user_id', $customer->id)->count());
    }

    public function test_customer_can_update_cart_quantity(): void
    {
        [$customer, $p1, $p2, $svc, $prod, $varRed, $rental] = $this->setupVendorAndProducts();

        $cartItem = CartItem::create([
            'user_id' => $customer->id,
            'product_id' => $prod->id,
            'product_variant_id' => $varRed->id,
            'item_type' => 'physical',
            'quantity' => 2,
        ]);

        // Increase quantity to 5
        $res = $this->actingAs($customer)->patch("/cart/{$cartItem->id}", [
            'quantity' => 5,
        ]);
        $res->assertSessionHas('success');
        $this->assertEquals(5, $cartItem->fresh()->quantity);

        // Attempt to exceed variant stock (15 units)
        $resExceed = $this->actingAs($customer)->patch("/cart/{$cartItem->id}", [
            'quantity' => 25,
        ]);
        $resExceed->assertSessionHas('error');
        $this->assertEquals(5, $cartItem->fresh()->quantity);
    }

    public function test_multi_vendor_checkout_snapshots_are_immutable(): void
    {
        [$customer, $p1, $p2, $svc, $prod, $varRed, $rental] = $this->setupVendorAndProducts();

        // Put physical item from Vendor 1 and rental item from Vendor 2 into cart
        CartItem::create([
            'user_id' => $customer->id,
            'product_id' => $prod->id,
            'product_variant_id' => $varRed->id,
            'item_type' => 'physical',
            'quantity' => 3, // 3 * 90.000 = 270.000
        ]);

        CartItem::create([
            'user_id' => $customer->id,
            'product_id' => $rental->id,
            'item_type' => 'rental',
            'quantity' => 2, // 2 * 1.500.000 = 3.000.000, deposit = 2 * 400.000 = 800.000
            'booking_start' => Carbon::now('UTC')->addDays(10),
            'booking_end' => Carbon::now('UTC')->addDays(12),
        ]);

        $checkoutResponse = $this->actingAs($customer)->post('/checkout', [
            'recipient_name' => 'Fadhilah Putri',
            'recipient_phone' => '081299998888',
            'shipping_address' => 'Jl. Boulevard No. 88, Menteng',
            'city' => 'Jakarta Pusat',
            'postal_code' => '10310',
            'payment_method' => 'qris',
            'notes' => 'Harap konfirmasi sebelum jadwal sewa.',
        ]);

        $order = Order::where('user_id', $customer->id)->latest()->first();
        $this->assertNotNull($order);
        $checkoutResponse->assertRedirect("/orders/{$order->order_number}/invoice");

        // Verify Order Totals:
        // Vendor 1: 270.000 (deposit 0) => total 270.000
        // Vendor 2: 3.000.000 + 800.000 deposit => total 3.800.000
        // Master total: 4.070.000
        $this->assertEquals(4070000, $order->total_amount);
        $this->assertEquals(800000, $order->total_deposit);

        // Verify Split Vendor Orders
        $this->assertCount(2, $order->vendorOrders);

        $vo1 = $order->vendorOrders->firstWhere('provider_id', $p1->id);
        $this->assertNotNull($vo1);
        $this->assertEquals(270000, $vo1->subtotal);
        $this->assertCount(1, $vo1->shippingHistories);

        $vo2 = $order->vendorOrders->firstWhere('provider_id', $p2->id);
        $this->assertNotNull($vo2);
        $this->assertEquals(3000000, $vo2->subtotal);
        $this->assertEquals(800000, $vo2->deposit_subtotal);

        // Verify Snapshot Immutability:
        // If the seller now changes the product price or name in the catalog...
        $prod->update(['name' => 'Renamed Product Post-Order', 'base_price' => 500000]);
        $varRed->update(['price' => 500000]);

        // The order item snapshot must remain UNCHANGED!
        $orderItem = OrderItem::where('vendor_order_id', $vo1->id)->first();
        $this->assertEquals('Lip Matte Classic', $orderItem->name_snapshot);
        $this->assertEquals('Ruby Red', $orderItem->variant_name_snapshot);
        $this->assertEquals(90000, $orderItem->price_snapshot);
        $this->assertEquals(270000, $orderItem->subtotal);

        // Cart is cleared after checkout
        $this->assertEquals(0, CartItem::where('user_id', $customer->id)->count());

        // Stock was locked and decremented: 15 - 3 = 12
        $this->assertEquals(12, $varRed->fresh()->stock);
    }

    public function test_customer_can_view_invoice_and_printable_format(): void
    {
        [$customer, $p1] = $this->setupVendorAndProducts();

        $order = Order::create([
            'order_number' => 'MUAMAR-INVOICE-TEST',
            'user_id' => $customer->id,
            'total_amount' => 500000,
            'total_deposit' => 0,
            'status' => 'pending_payment',
            'payment_status' => 'unpaid',
            'payment_method' => 'qris',
            'shipping_address_snapshot' => [
                'name' => 'Customer Invoicing',
                'phone' => '0811111111',
                'address' => 'Jl. Merdeka 1',
                'city' => 'Jakarta',
                'postal_code' => '10110',
            ],
        ]);

        // 1. Customer can access web invoice
        $responseWeb = $this->actingAs($customer)->get("/orders/{$order->order_number}/invoice");
        $responseWeb->assertStatus(200);
        $responseWeb->assertSee('MUAMAR-INVOICE-TEST');

        // 2. Customer can access dedicated printable format
        $responsePrint = $this->actingAs($customer)->get("/orders/{$order->order_number}/print");
        $responsePrint->assertStatus(200);
        $responsePrint->assertSee('FAKTUR PESANAN');
        $responsePrint->assertSee('MUAMAR-INVOICE-TEST');
    }
}
