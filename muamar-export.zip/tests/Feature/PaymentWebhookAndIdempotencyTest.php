<?php

namespace Tests\Feature;

use App\Models\Order;
use App\Models\Payment;
use App\Models\Provider;
use App\Models\User;
use App\Models\VendorOrder;
use App\Services\PaymentGatewayService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class PaymentWebhookAndIdempotencyTest extends TestCase
{
    use RefreshDatabase;

    protected function setupOrder(): Order
    {
        $customer = User::factory()->create(['role' => 'customer']);
        $providerUser = User::factory()->create(['role' => 'provider']);
        $provider = Provider::create([
            'user_id' => $providerUser->id,
            'business_name' => 'Studio Cantik',
            'slug' => 'studio-cantik',
            'address' => 'Jakarta',
            'city' => 'Jakarta',
            'phone' => '0812345678',
            'status' => 'approved',
        ]);

        $order = Order::create([
            'order_number' => 'MUAMAR-WEBHOOK-TEST',
            'user_id' => $customer->id,
            'total_amount' => 750000,
            'status' => 'pending_payment',
            'payment_status' => 'unpaid',
            'payment_method' => 'qris',
            'shipping_address_snapshot' => ['city' => 'Jakarta'],
        ]);

        $vendorOrder = VendorOrder::create([
            'vendor_order_number' => 'VO-TEST-001',
            'order_id' => $order->id,
            'provider_id' => $provider->id,
            'subtotal' => 750000,
            'total_amount' => 750000,
            'status' => 'pending_payment',
            'payment_status' => 'unpaid',
        ]);

        Payment::create([
            'order_id' => $order->id,
            'payment_method' => 'qris',
            'provider_reference' => 'QRIS-REF-001',
            'amount' => 750000,
            'status' => 'pending',
        ]);

        return $order;
    }

    public function test_valid_webhook_settles_payment_and_updates_order_status(): void
    {
        $order = $this->setupOrder();
        $serverKey = env('PAYMENT_GATEWAY_WEBHOOK_SECRET', 'muamar_secret_webhook_signature_key');
        $signature = hash('sha256', $order->order_number . '200' . $order->total_amount . $serverKey);

        $payload = [
            'order_number' => $order->order_number,
            'status_code' => '200',
            'gross_amount' => $order->total_amount,
            'transaction_status' => 'settlement',
            'signature_key' => $signature,
        ];

        $response = $this->postJson('/api/payments/webhook', $payload);

        $response->assertStatus(200);
        $response->assertJson(['status' => 'success']);

        $this->assertEquals('paid', $order->fresh()->payment_status);
        $this->assertEquals('processing', $order->fresh()->status);
        $this->assertDatabaseHas('payment_audit_logs', [
            'order_id' => $order->id,
            'event_type' => 'webhook_settlement_processed',
        ]);
    }

    public function test_invalid_signature_is_rejected_with_401(): void
    {
        $order = $this->setupOrder();

        $payload = [
            'order_number' => $order->order_number,
            'status_code' => '200',
            'gross_amount' => $order->total_amount,
            'transaction_status' => 'settlement',
            'signature_key' => 'fake_invalid_tampered_signature_123',
        ];

        $response = $this->postJson('/api/payments/webhook', $payload);

        $response->assertStatus(401);
        $this->assertEquals('unpaid', $order->fresh()->payment_status);
    }

    public function test_amount_mismatch_is_rejected_with_400(): void
    {
        $order = $this->setupOrder();
        $serverKey = env('PAYMENT_GATEWAY_WEBHOOK_SECRET', 'muamar_secret_webhook_signature_key');
        // Signature generated for 500000 instead of real 750000
        $tamperedAmount = 500000;
        $signature = hash('sha256', $order->order_number . '200' . $tamperedAmount . $serverKey);

        $payload = [
            'order_number' => $order->order_number,
            'status_code' => '200',
            'gross_amount' => $tamperedAmount,
            'transaction_status' => 'settlement',
            'signature_key' => $signature,
        ];

        $response = $this->postJson('/api/payments/webhook', $payload);

        $response->assertStatus(400);
        $this->assertEquals('unpaid', $order->fresh()->payment_status);
        $this->assertDatabaseHas('payment_audit_logs', [
            'order_id' => $order->id,
            'event_type' => 'amount_mismatch_rejected',
        ]);
    }

    public function test_duplicate_webhook_is_handled_idempotently(): void
    {
        $order = $this->setupOrder();
        $serverKey = env('PAYMENT_GATEWAY_WEBHOOK_SECRET', 'muamar_secret_webhook_signature_key');
        $signature = hash('sha256', $order->order_number . '200' . $order->total_amount . $serverKey);

        $payload = [
            'order_number' => $order->order_number,
            'status_code' => '200',
            'gross_amount' => $order->total_amount,
            'transaction_status' => 'settlement',
            'signature_key' => $signature,
        ];

        // First call
        $firstResponse = $this->postJson('/api/payments/webhook', $payload);
        $firstResponse->assertStatus(200);
        $firstResponse->assertJson(['status' => 'success']);

        // Second call (Duplicate webhook retry)
        $secondResponse = $this->postJson('/api/payments/webhook', $payload);
        $secondResponse->assertStatus(200);
        $secondResponse->assertJson(['status' => 'skipped']);

        $this->assertDatabaseHas('payment_audit_logs', [
            'order_id' => $order->id,
            'event_type' => 'idempotent_duplicate_skipped',
        ]);
    }

    public function test_cod_remains_unpaid_until_explicit_provider_confirmation(): void
    {
        $customer = User::factory()->create(['role' => 'customer']);
        $providerUser = User::factory()->create(['role' => 'provider']);
        $provider = Provider::create([
            'user_id' => $providerUser->id,
            'business_name' => 'Studio COD',
            'slug' => 'studio-cod',
            'address' => 'Surabaya',
            'city' => 'Surabaya',
            'phone' => '08777777',
            'status' => 'approved',
        ]);

        $order = Order::create([
            'order_number' => 'MUAMAR-COD-001',
            'user_id' => $customer->id,
            'total_amount' => 450000,
            'status' => 'processing',
            'payment_status' => 'unpaid', // Initial COD status
            'payment_method' => 'cod',
            'shipping_address_snapshot' => ['city' => 'Surabaya'],
        ]);

        $vendorOrder = VendorOrder::create([
            'vendor_order_number' => 'VO-COD-001',
            'order_id' => $order->id,
            'provider_id' => $provider->id,
            'subtotal' => 450000,
            'total_amount' => 450000,
            'status' => 'processing',
            'payment_status' => 'unpaid',
        ]);

        // Provider explicitly confirms receipt of cash
        $response = $this->actingAs($providerUser)->patch("/provider/orders/{$vendorOrder->id}/confirm-cod");
        $response->assertRedirect();

        $this->assertEquals('paid', $vendorOrder->fresh()->payment_status);
        $this->assertEquals('paid', $order->fresh()->payment_status);
        $this->assertEquals('completed', $order->fresh()->status);
    }

    public function test_cod_can_be_rejected_by_provider_releasing_held_inventory(): void
    {
        $customer = User::factory()->create(['role' => 'customer']);
        $providerUser = User::factory()->create(['role' => 'provider']);
        $provider = Provider::create([
            'user_id' => $providerUser->id,
            'business_name' => 'Studio COD Reject',
            'slug' => 'studio-cod-reject',
            'address' => 'Medan',
            'city' => 'Medan',
            'phone' => '08771111',
            'status' => 'approved',
        ]);

        $order = Order::create([
            'order_number' => 'MUAMAR-COD-REJ-001',
            'user_id' => $customer->id,
            'total_amount' => 300000,
            'status' => 'processing',
            'payment_status' => 'unpaid',
            'payment_method' => 'cod',
            'shipping_address_snapshot' => ['city' => 'Medan'],
        ]);

        $vendorOrder = VendorOrder::create([
            'vendor_order_number' => 'VO-COD-REJ-001',
            'order_id' => $order->id,
            'provider_id' => $provider->id,
            'subtotal' => 300000,
            'total_amount' => 300000,
            'status' => 'processing',
            'payment_status' => 'unpaid',
        ]);

        $response = $this->actingAs($providerUser)->patch("/provider/orders/{$vendorOrder->id}/reject-cod", [
            'reason' => 'Pelanggan menolak menerima barang / bayar tunai saat kurir tiba di lokasi.',
        ]);
        $response->assertRedirect();

        $this->assertEquals('cancelled', $vendorOrder->fresh()->status);
        $this->assertEquals('cancelled', $order->fresh()->status);
        $this->assertDatabaseHas('payment_audit_logs', [
            'order_id' => $order->id,
            'event_type' => 'cod_rejected_by_provider',
        ]);
    }

    public function test_webhook_expiration_or_failure_cancels_order_and_releases_holds(): void
    {
        $order = $this->setupOrder();
        $serverKey = env('PAYMENT_GATEWAY_WEBHOOK_SECRET', 'muamar_secret_webhook_signature_key');
        $signature = hash('sha256', $order->order_number . '200' . $order->total_amount . $serverKey);

        $payload = [
            'order_number' => $order->order_number,
            'status_code' => '200',
            'gross_amount' => $order->total_amount,
            'transaction_status' => 'expire',
            'signature_key' => $signature,
        ];

        $response = $this->postJson('/api/payments/webhook', $payload);
        $response->assertStatus(200);

        $this->assertEquals('cancelled', $order->fresh()->status);
        $this->assertDatabaseHas('payment_audit_logs', [
            'order_id' => $order->id,
            'event_type' => 'webhook_expired_processed',
        ]);
    }

    public function test_illegal_status_transition_on_paid_order_is_blocked_and_audited(): void
    {
        $order = $this->setupOrder();
        $order->update([
            'status' => 'processing',
            'payment_status' => 'paid',
        ]);

        $serverKey = env('PAYMENT_GATEWAY_WEBHOOK_SECRET', 'muamar_secret_webhook_signature_key');
        $signature = hash('sha256', $order->order_number . '200' . $order->total_amount . $serverKey);

        // Webhook tries to mark already paid order as expired
        $payload = [
            'order_number' => $order->order_number,
            'status_code' => '200',
            'gross_amount' => $order->total_amount,
            'transaction_status' => 'expire',
            'signature_key' => $signature,
        ];

        $response = $this->postJson('/api/payments/webhook', $payload);
        $response->assertStatus(200);
        $response->assertJson(['status' => 'ignored']);

        // Order remains paid!
        $this->assertEquals('paid', $order->fresh()->payment_status);
        $this->assertDatabaseHas('payment_audit_logs', [
            'order_id' => $order->id,
            'event_type' => 'illegal_transition_blocked',
        ]);
    }

    public function test_official_gateway_adapter_throws_configuration_exception_when_keys_missing(): void
    {
        $adapter = new \App\Services\Payment\OfficialGatewayAdapter();
        $order = $this->setupOrder();

        $this->expectException(\Exception::class);
        $adapter->generateQris($order);
    }
}
