<?php

namespace Tests\Feature;

use App\Models\AdminAuditLog;
use App\Models\Category;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use App\Models\Provider;
use App\Models\Review;
use App\Models\User;
use App\Models\VendorOrder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AdminModerationAndSecurityHardeningTest extends TestCase
{
    use RefreshDatabase;

    protected User $admin;
    protected User $customer;
    protected User $providerUser;
    protected Provider $provider;
    protected Product $product;

    protected function setUp(): void
    {
        parent::setUp();

        $this->admin = User::factory()->create([
            'role' => 'admin',
            'is_active' => true,
        ]);

        $this->customer = User::factory()->create([
            'role' => 'customer',
            'is_active' => true,
        ]);

        $this->providerUser = User::factory()->create([
            'role' => 'provider',
            'is_active' => true,
        ]);

        $this->provider = Provider::create([
            'user_id' => $this->providerUser->id,
            'business_name' => 'Royal Wedding Studio',
            'slug' => 'royal-wedding-studio',
            'phone' => '081234567890',
            'city' => 'Jakarta Selatan',
            'address' => 'Jl. Iskandarsyah Raya No. 12',
            'status' => 'pending',
            'is_verified' => false,
            'is_location_public' => true,
            'latitude' => -6.2425,
            'longitude' => 106.8021,
        ]);

        $category = Category::create([
            'name' => 'Dekorasi & Tenda',
            'slug' => 'dekorasi-tenda',
        ]);

        $this->product = Product::create([
            'provider_id' => $this->provider->id,
            'category_id' => $category->id,
            'name' => 'Paket Sewa Tenda Roder VIP',
            'slug' => 'paket-sewa-tenda-roder-vip',
            'type' => 'rental',
            'base_price' => 15000000,
            'is_active' => true,
        ]);
    }

    protected function createCompletedOrderItem(): OrderItem
    {
        $order = Order::create([
            'order_number' => 'MUAMAR-ORD-' . uniqid(),
            'user_id' => $this->customer->id,
            'total_amount' => 15000000,
            'total_deposit' => 0,
            'status' => 'completed',
            'payment_status' => 'paid',
            'payment_method' => 'qris',
            'shipping_address_snapshot' => [
                'name' => $this->customer->name,
                'address' => 'Jl. Test No. 12',
            ],
        ]);

        $vendorOrder = VendorOrder::create([
            'vendor_order_number' => 'VO-' . uniqid(),
            'order_id' => $order->id,
            'provider_id' => $this->provider->id,
            'subtotal' => 15000000,
            'deposit_subtotal' => 0,
            'shipping_cost' => 0,
            'total_amount' => 15000000,
            'status' => 'completed',
            'payment_status' => 'paid',
        ]);

        return OrderItem::create([
            'vendor_order_id' => $vendorOrder->id,
            'product_id' => $this->product->id,
            'item_type' => 'rental',
            'name_snapshot' => $this->product->name,
            'price_snapshot' => 15000000,
            'deposit_snapshot' => 0,
            'quantity' => 1,
            'subtotal' => 15000000,
        ]);
    }

    public function test_admin_can_verify_provider_and_audit_trail_is_recorded(): void
    {
        $response = $this->actingAs($this->admin)->patch("/admin/providers/{$this->provider->id}/verify");

        $response->assertSessionHas('success');
        $this->provider->refresh();
        $this->assertTrue($this->provider->is_verified);
        $this->assertEquals('approved', $this->provider->status);

        $this->assertDatabaseHas('admin_audit_logs', [
            'user_id' => $this->admin->id,
            'action' => 'provider_verified',
            'entity_type' => Provider::class,
            'entity_id' => $this->provider->id,
        ]);
    }

    public function test_admin_can_toggle_provider_suspension(): void
    {
        $this->provider->update(['status' => 'approved', 'is_verified' => true]);

        // Suspend provider
        $suspendRes = $this->actingAs($this->admin)->patch("/admin/providers/{$this->provider->id}/toggle-suspension");
        $suspendRes->assertSessionHas('success');

        $this->assertEquals('suspended', $this->provider->fresh()->status);
        $this->assertDatabaseHas('admin_audit_logs', [
            'action' => 'provider_status_toggled',
            'entity_id' => $this->provider->id,
        ]);

        // Reactivate provider
        $activateRes = $this->actingAs($this->admin)->patch("/admin/providers/{$this->provider->id}/toggle-suspension");
        $activateRes->assertSessionHas('success');
        $this->assertEquals('approved', $this->provider->fresh()->status);
    }

    public function test_admin_can_moderate_listings_and_reviews(): void
    {
        // 1. Toggle product listing status
        $this->assertTrue($this->product->is_active);

        $productRes = $this->actingAs($this->admin)->patch("/admin/products/{$this->product->id}/toggle");
        $productRes->assertSessionHas('success');

        $this->assertFalse($this->product->fresh()->is_active);
        $this->assertDatabaseHas('admin_audit_logs', [
            'action' => 'product_status_toggled',
            'entity_id' => $this->product->id,
        ]);

        // 2. Toggle review visibility
        $orderItem = $this->createCompletedOrderItem();
        $review = Review::create([
            'user_id' => $this->customer->id,
            'provider_id' => $this->provider->id,
            'product_id' => $this->product->id,
            'order_item_id' => $orderItem->id,
            'rating' => 1,
            'comment' => 'Spam komentar tidak pantas',
            'is_visible' => true,
        ]);

        $reviewRes = $this->actingAs($this->admin)->patch("/admin/reviews/{$review->id}/toggle");
        $reviewRes->assertSessionHas('success');

        $this->assertFalse($review->fresh()->is_visible);
        $this->assertDatabaseHas('admin_audit_logs', [
            'action' => 'review_visibility_toggled',
            'entity_id' => $review->id,
        ]);
    }

    public function test_admin_category_management_and_audit(): void
    {
        // 1. Admin creates category
        $storeRes = $this->actingAs($this->admin)->post('/admin/categories', [
            'name' => 'Hair Do Modern',
            'description' => 'Tata rias rambut modern untuk pesta dan wisuda',
        ]);
        $storeRes->assertSessionHas('success');

        $category = Category::where('name', 'Hair Do Modern')->first();
        $this->assertNotNull($category);

        $this->assertDatabaseHas('admin_audit_logs', [
            'action' => 'category_created',
            'entity_id' => $category->id,
        ]);

        // 2. Admin deletes empty category
        $deleteRes = $this->actingAs($this->admin)->delete("/admin/categories/{$category->id}");
        $deleteRes->assertSessionHas('success');
        $this->assertDatabaseMissing('categories', ['id' => $category->id]);

        $this->assertDatabaseHas('admin_audit_logs', [
            'action' => 'category_deleted',
            'entity_id' => $category->id,
        ]);
    }

    public function test_non_admin_cannot_access_moderation_endpoints(): void
    {
        // Customer attempting to verify provider -> 403 Forbidden
        $this->actingAs($this->customer)
            ->patch("/admin/providers/{$this->provider->id}/verify")
            ->assertStatus(403);

        // Provider attempting to toggle review -> 403 Forbidden
        $this->actingAs($this->providerUser)
            ->patch("/admin/products/{$this->product->id}/toggle")
            ->assertStatus(403);

        // Customer attempting to delete category -> 403 Forbidden
        $this->actingAs($this->customer)
            ->delete("/admin/categories/{$this->product->category_id}")
            ->assertStatus(403);
    }

    public function test_xss_prevention_in_blade_rendering(): void
    {
        $maliciousComment = '<script>alert("XSS Attack!");</script>';
        $orderItem = $this->createCompletedOrderItem();

        $review = Review::create([
            'user_id' => $this->customer->id,
            'provider_id' => $this->provider->id,
            'product_id' => $this->product->id,
            'order_item_id' => $orderItem->id,
            'rating' => 5,
            'comment' => $maliciousComment,
            'is_visible' => true,
        ]);

        $response = $this->get("/catalog/{$this->product->slug}");
        $response->assertStatus(200);

        // Raw script tag must NOT be executed; it must be escaped in HTML entities
        $response->assertDontSee('<script>alert("XSS Attack!");</script>', false);
        $response->assertSee('&lt;script&gt;alert(&quot;XSS Attack!&quot;);&lt;/script&gt;', false);
    }
}
