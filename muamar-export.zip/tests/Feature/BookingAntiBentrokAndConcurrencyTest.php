<?php

namespace Tests\Feature;

use App\Models\Category;
use App\Models\Product;
use App\Models\Provider;
use App\Models\ServiceBooking;
use App\Models\ServiceProfile;
use App\Models\User;
use App\Services\BookingSchedulerService;
use Carbon\Carbon;
use Exception;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class BookingAntiBentrokAndConcurrencyTest extends TestCase
{
    use RefreshDatabase;

    protected function setupServiceProduct(): array
    {
        $providerUser = User::factory()->create(['role' => 'provider']);
        $provider = Provider::create([
            'user_id' => $providerUser->id,
            'business_name' => 'Tasya MUA Studio',
            'slug' => 'tasya-mua-studio',
            'address' => 'Kemang',
            'city' => 'Jakarta Selatan',
            'phone' => '0812345678',
            'status' => 'approved',
        ]);

        $category = Category::create([
            'name' => 'Jasa Rias',
            'slug' => 'jasa-rias',
            'type' => 'service',
        ]);

        $product = Product::create([
            'provider_id' => $provider->id,
            'category_id' => $category->id,
            'name' => 'Makeup Wedding Luxury',
            'slug' => 'makeup-wedding-luxury',
            'type' => 'service',
            'base_price' => 2500000,
            'is_active' => true,
        ]);

        ServiceProfile::create([
            'product_id' => $product->id,
            'duration_minutes' => 120, // 2 hours
            'buffer_minutes' => 30,   // 30 min buffer
            'capacity_per_slot' => 1,
            'artist_name' => 'Tasya Farasya',
        ]);

        return [$product, $provider];
    }

    public function test_capacity_one_service_cannot_be_double_booked_on_overlapping_interval(): void
    {
        [$product, $provider] = $this->setupServiceProduct();
        $scheduler = app(BookingSchedulerService::class);

        $customerA = User::factory()->create(['role' => 'customer']);
        $customerB = User::factory()->create(['role' => 'customer']);

        // Customer A books 08:00 UTC (duration 120m + buffer 30m = effective end 10:30 UTC)
        $startA = Carbon::parse('2026-11-15 08:00:00', 'UTC');
        $bookingA = $scheduler->holdSlot($product, $customerA, $startA);

        $this->assertEquals('hold', $bookingA->status);

        // Customer B tries to book overlapping slot at 09:00 UTC (during Customer A's session)
        $startB = Carbon::parse('2026-11-15 09:00:00', 'UTC');

        $this->expectException(Exception::class);
        $this->expectExceptionMessage('sudah terisi atau sedang di-hold');

        $scheduler->holdSlot($product, $customerB, $startB);
    }

    public function test_non_overlapping_booking_after_buffer_succeeds(): void
    {
        [$product, $provider] = $this->setupServiceProduct();
        $scheduler = app(BookingSchedulerService::class);

        $customerA = User::factory()->create(['role' => 'customer']);
        $customerB = User::factory()->create(['role' => 'customer']);

        // Slot 1: 08:00 to 10:00 + buffer 30m => 10:30 UTC
        $startA = Carbon::parse('2026-11-15 08:00:00', 'UTC');
        $bookingA = $scheduler->holdSlot($product, $customerA, $startA);

        // Slot 2: 11:00 UTC (after buffer_end_time 10:30 UTC)
        $startB = Carbon::parse('2026-11-15 11:00:00', 'UTC');
        $bookingB = $scheduler->holdSlot($product, $customerB, $startB);

        $this->assertNotNull($bookingB);
        $this->assertEquals('hold', $bookingB->status);
    }

    public function test_expired_hold_does_not_block_slot_and_is_released(): void
    {
        [$product, $provider] = $this->setupServiceProduct();
        $scheduler = app(BookingSchedulerService::class);

        $customerA = User::factory()->create(['role' => 'customer']);
        $customerB = User::factory()->create(['role' => 'customer']);

        // Customer A booked 15 minutes ago, but never completed payment (hold_expires_at is past)
        $pastStart = Carbon::now('UTC')->addDays(2)->setTime(8, 0);
        $bookingA = ServiceBooking::create([
            'provider_id' => $provider->id,
            'customer_id' => $customerA->id,
            'product_id' => $product->id,
            'start_time' => $pastStart,
            'end_time' => $pastStart->copy()->addMinutes(120),
            'buffer_end_time' => $pastStart->copy()->addMinutes(150),
            'status' => 'hold',
            'hold_expires_at' => Carbon::now('UTC')->subMinutes(5), // EXPIRED
        ]);

        // Release expired holds
        $releasedCount = $scheduler->releaseExpiredHolds();
        $this->assertGreaterThanOrEqual(1, $releasedCount);
        $this->assertEquals('expired', $bookingA->fresh()->status);

        // Now Customer B should successfully be able to hold that exact slot!
        $bookingB = $scheduler->holdSlot($product, $customerB, $pastStart);
        $this->assertNotNull($bookingB);
        $this->assertEquals('hold', $bookingB->status);
    }
}
