<?php

namespace Tests\Feature;

use App\Models\Category;
use App\Models\Product;
use App\Models\Provider;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

class AuthAndOnboardingTest extends TestCase
{
    use RefreshDatabase;

    public function test_customer_can_register_and_login(): void
    {
        $response = $this->post('/register', [
            'name' => 'Maya Anggita',
            'email' => 'maya@example.com',
            'phone' => '081299887766',
            'password' => 'password123',
            'password_confirmation' => 'password123',
            'role' => 'customer',
        ]);

        $response->assertRedirect('/customer/dashboard');
        $this->assertAuthenticated();
        $this->assertDatabaseHas('users', [
            'email' => 'maya@example.com',
            'role' => 'customer',
        ]);
    }

    public function test_provider_registration_redirects_to_onboarding(): void
    {
        $response = $this->post('/register', [
            'name' => 'Dewi MUA Artist',
            'email' => 'dewi@example.com',
            'phone' => '081311223344',
            'password' => 'password123',
            'password_confirmation' => 'password123',
            'role' => 'provider',
        ]);

        $response->assertRedirect('/provider/onboard');
        $this->assertAuthenticated();
    }

    public function test_user_can_onboard_as_provider_studio(): void
    {
        $user = User::factory()->create([
            'role' => 'customer',
            'phone' => '081234567890',
        ]);

        $response = $this->actingAs($user)->post('/provider/onboard', [
            'business_name' => 'Dewi Artistry Studio',
            'description' => 'MUA Wedding Profesional & Wisuda Glamour',
            'address' => 'Jl. Anggrek No. 10',
            'city' => 'Jakarta Selatan',
            'province' => 'DKI Jakarta',
            'postal_code' => '12110',
            'latitude' => -6.2201,
            'longitude' => 106.8202,
            'is_location_public' => true,
            'phone' => '081234567890',
            'qris_active' => true,
            'cod_active' => true,
        ]);

        $response->assertRedirect('/provider/dashboard');
        $this->assertDatabaseHas('providers', [
            'user_id' => $user->id,
            'business_name' => 'Dewi Artistry Studio',
            'city' => 'Jakarta Selatan',
        ]);

        // Check that default weekly availabilities (7 days) were generated
        $provider = Provider::where('user_id', $user->id)->first();
        $this->assertCount(7, $provider->availabilities);
        $this->assertEquals('provider', $user->fresh()->role);
    }

    public function test_user_can_onboard_and_upload_first_product_simultaneously(): void
    {
        Storage::fake('public');

        $user = User::factory()->create([
            'role' => 'customer',
            'phone' => '081298765432',
        ]);

        $category = Category::create([
            'name' => 'Paket Makeup Pengantin',
            'slug' => 'paket-makeup-pengantin',
        ]);

        $fakeImage = UploadedFile::fake()->image('portfolio.jpg', 600, 600);

        $response = $this->actingAs($user)->post('/provider/onboard', [
            'business_name' => 'Bella Glam MUA Studio',
            'description' => 'Spesialis MUA pengantin adat Jawa & Sunda',
            'address' => 'Jl. Kebon Jeruk No. 12',
            'city' => 'Jakarta Barat',
            'phone' => '081298765432',
            'qris_active' => true,
            'cod_active' => true,

            // First product upload fields
            'initial_product_name' => 'Makeup Pengantin Adat Jawa Putri Solo',
            'initial_product_type' => 'service',
            'initial_category_id' => $category->id,
            'initial_base_price' => 3500000,
            'initial_duration_minutes' => 180,
            'initial_description' => 'Paket rias paes Solo Putri lengkap dengan melati dan softlens',
            'initial_image' => $fakeImage,
        ]);

        $response->assertRedirect('/provider/dashboard');
        $this->assertDatabaseHas('providers', [
            'user_id' => $user->id,
            'business_name' => 'Bella Glam MUA Studio',
        ]);

        $provider = Provider::where('user_id', $user->id)->first();
        $this->assertNotNull($provider);

        // Verify product was created and linked to the provider
        $this->assertDatabaseHas('products', [
            'provider_id' => $provider->id,
            'name' => 'Makeup Pengantin Adat Jawa Putri Solo',
            'type' => 'service',
            'base_price' => 3500000,
        ]);

        $product = Product::where('provider_id', $provider->id)->first();
        $this->assertNotNull($product->serviceProfile);
        $this->assertEquals(180, $product->serviceProfile->duration_minutes);

        // Verify image was saved
        $this->assertNotEmpty($product->images);
    }
}
