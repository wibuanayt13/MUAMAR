<?php

namespace Tests\Feature;

use App\Models\Category;
use App\Models\Product;
use App\Models\Provider;
use App\Models\ProviderAvailability;
use App\Models\ProviderScheduleOverride;
use App\Models\RentalBooking;
use App\Models\RentalProfile;
use App\Models\ServiceBooking;
use App\Models\ServiceProfile;
use App\Models\User;
use App\Services\BookingSchedulerService;
use App\Services\RentalSchedulerService;
use Carbon\Carbon;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Artisan;
use Tests\TestCase;

class SchedulerConcurrencyAndExpiryJobTest extends TestCase
{
    use RefreshDatabase;

    protected function setupServiceAndRental(): array
    {
        $providerUser = User::factory()->create(['role' => 'provider']);
        $provider = Provider::create([
            'user_id' => $providerUser->id,
            'business_name' => 'Studio Rias & Event Megah',
            'slug' => 'studio-rias-event-megah',
            'address' => 'Jl. Diponegoro 15',
            'city' => 'Semarang',
            'phone' => '0812341234',
            'status' => 'approved',
        ]);

        // Weekly schedule: Open Monday (1) to Friday (5) from 08:00 to 18:00
        for ($day = 0; $day <= 6; $day++) {
            ProviderAvailability::create([
                'provider_id' => $provider->id,
                'day_of_week' => $day,
                'start_time' => '08:00:00',
                'end_time' => '18:00:00',
                'is_available' => in_array($day, [1, 2, 3, 4, 5]),
            ]);
        }

        $catService = Category::create(['name' => 'Layanan Rias', 'slug' => 'layanan-rias', 'type' => 'service']);
        $catRental = Category::create(['name' => 'Persewaan Event', 'slug' => 'persewaan-event', 'type' => 'rental']);

        // Service Product (120 min duration, 30 min buffer)
        $svcProduct = Product::create([
            'provider_id' => $provider->id,
            'category_id' => $catService->id,
            'name' => 'Makeup Prewedding Alam',
            'slug' => 'makeup-prewedding-alam',
            'type' => 'service',
            'base_price' => 1200000,
            'is_active' => true,
        ]);
        ServiceProfile::create([
            'product_id' => $svcProduct->id,
            'duration_minutes' => 120,
            'buffer_minutes' => 30,
            'artist_name' => 'MUA Senior',
        ]);

        // Rental Product (4 units total)
        $rentalProduct = Product::create([
            'provider_id' => $provider->id,
            'category_id' => $catRental->id,
            'name' => 'Sewa Tenda Kerucut 3x3',
            'slug' => 'sewa-tenda-kerucut-3x3',
            'type' => 'rental',
            'base_price' => 350000,
            'is_active' => true,
        ]);
        RentalProfile::create([
            'product_id' => $rentalProduct->id,
            'total_units' => 4,
            'deposit_amount' => 100000,
            'min_rental_days' => 1,
            'buffer_hours' => 2,
            'unit_type' => 'unit tenda',
        ]);

        return [$providerUser, $provider, $svcProduct, $rentalProduct];
    }

    public function test_artisan_release_holds_command_frees_expired_service_and_rental_slots(): void
    {
        [$provUser, $provider, $svcProduct, $rentalProduct] = $this->setupServiceAndRental();
        $customer1 = User::factory()->create(['role' => 'customer']);
        $customer2 = User::factory()->create(['role' => 'customer']);

        $slotTime = Carbon::now('UTC')->addDays(3)->setTime(8, 0);

        // 1. Create an expired service hold (> 10 mins ago)
        $expiredServiceBooking = ServiceBooking::create([
            'provider_id' => $provider->id,
            'customer_id' => $customer1->id,
            'product_id' => $svcProduct->id,
            'start_time' => $slotTime,
            'end_time' => $slotTime->copy()->addMinutes(120),
            'buffer_end_time' => $slotTime->copy()->addMinutes(150),
            'status' => 'hold',
            'hold_expires_at' => Carbon::now('UTC')->subMinutes(2), // Expired!
        ]);

        // 2. Create an expired rental hold
        $rentalStart = Carbon::now('UTC')->addDays(5);
        $expiredRentalBooking = RentalBooking::create([
            'provider_id' => $provider->id,
            'customer_id' => $customer1->id,
            'product_id' => $rentalProduct->id,
            'start_date' => $rentalStart,
            'end_date' => $rentalStart->copy()->addDays(2),
            'buffer_end_date' => $rentalStart->copy()->addDays(2)->addHours(2),
            'quantity_rented' => 4, // Takes all 4 units
            'deposit_amount' => 400000,
            'status' => 'hold',
            'hold_expires_at' => Carbon::now('UTC')->subMinutes(1), // Expired!
        ]);

        // 3. Run the artisan scheduled command
        Artisan::call('muamar:release-holds');

        $this->assertEquals('expired', $expiredServiceBooking->fresh()->status);
        $this->assertEquals('expired', $expiredRentalBooking->fresh()->status);

        // 4. Customer 2 can now claim the freed service slot and rental units
        $bookingScheduler = app(BookingSchedulerService::class);
        $newBooking = $bookingScheduler->holdSlot($svcProduct, $customer2, $slotTime);
        $this->assertEquals('hold', $newBooking->status);

        $rentalScheduler = app(RentalSchedulerService::class);
        $newRental = $rentalScheduler->holdRental($rentalProduct, $customer2, $rentalStart, $rentalStart->copy()->addDays(2), 2);
        $this->assertEquals('hold', $newRental->status);
    }

    public function test_get_available_slots_computes_openings_and_respects_holiday_overrides(): void
    {
        [$provUser, $provider, $svcProduct] = $this->setupServiceAndRental();
        $scheduler = app(BookingSchedulerService::class);

        // Pick next Monday (day_of_week = 1, which is available in setup)
        $testMonday = Carbon::now('Asia/Jakarta')->next(Carbon::MONDAY);

        $slots = $scheduler->getAvailableSlots($svcProduct, $testMonday);
        $this->assertNotEmpty($slots);
        $this->assertTrue($slots[0]['is_available']);

        // Add a holiday override for that Monday
        ProviderScheduleOverride::create([
            'provider_id' => $provider->id,
            'override_date' => $testMonday->toDateString(),
            'is_off' => true,
            'reason' => 'Hari Libur Nasional',
        ]);

        // Now slots must be empty because provider is off
        $holidaySlots = $scheduler->getAvailableSlots($svcProduct, $testMonday);
        $this->assertEmpty($holidaySlots);
    }

    public function test_interactive_api_slots_and_capacity_endpoints(): void
    {
        [$provUser, $provider, $svcProduct, $rentalProduct] = $this->setupServiceAndRental();

        // 1. Service slots API
        $nextTuesday = Carbon::now('Asia/Jakarta')->next(Carbon::TUESDAY);
        $responseSvc = $this->getJson("/api/services/{$svcProduct->id}/slots?date={$nextTuesday->toDateString()}");
        $responseSvc->assertStatus(200);
        $responseSvc->assertJsonStructure([
            'product_id',
            'date',
            'slots' => [
                '*' => ['time', 'start_utc', 'is_available']
            ]
        ]);

        // 2. Rental capacity API
        $resRental = $this->getJson("/api/rentals/{$rentalProduct->id}/capacity?start_date=" . now()->addDays(4)->toDateString() . "&end_date=" . now()->addDays(6)->toDateString());
        $resRental->assertStatus(200);
        $resRental->assertJson([
            'product_id' => $rentalProduct->id,
            'total_units' => 4,
            'remaining_units' => 4,
            'is_available' => true,
        ]);
    }

    public function test_provider_fulfillment_lifecycle(): void
    {
        [$provUser, $provider, $svcProduct, $rentalProduct] = $this->setupServiceAndRental();
        $customer = User::factory()->create(['role' => 'customer']);
        $intruder = User::factory()->create(['role' => 'provider']);

        // 1. Service booking completion
        $slotTime = Carbon::now('UTC')->addDays(1);
        $serviceBooking = ServiceBooking::create([
            'provider_id' => $provider->id,
            'customer_id' => $customer->id,
            'product_id' => $svcProduct->id,
            'start_time' => $slotTime,
            'end_time' => $slotTime->copy()->addMinutes(120),
            'buffer_end_time' => $slotTime->copy()->addMinutes(150),
            'status' => 'confirmed',
        ]);

        // Intruder cannot complete Provider's booking
        $this->actingAs($intruder)->patch("/provider/bookings/{$serviceBooking->id}/complete")
            ->assertSessionHas('error');

        // Proper provider completes service
        $this->actingAs($provUser)->patch("/provider/bookings/{$serviceBooking->id}/complete")
            ->assertSessionHas('success');
        $this->assertEquals('completed', $serviceBooking->fresh()->status);

        // 2. Rental booking lifecycle: confirmed -> pickup -> returned
        $rentalBooking = RentalBooking::create([
            'provider_id' => $provider->id,
            'customer_id' => $customer->id,
            'product_id' => $rentalProduct->id,
            'start_date' => Carbon::now('UTC')->addDays(1),
            'end_date' => Carbon::now('UTC')->addDays(3),
            'buffer_end_date' => Carbon::now('UTC')->addDays(3)->addHours(2),
            'quantity_rented' => 2,
            'deposit_amount' => 200000,
            'status' => 'confirmed',
        ]);

        // Provider marks picked up
        $this->actingAs($provUser)->patch("/provider/rentals/{$rentalBooking->id}/pickup")
            ->assertSessionHas('success');
        $this->assertEquals('picked_up', $rentalBooking->fresh()->status);

        // Provider marks returned with deposit return
        $this->actingAs($provUser)->patch("/provider/rentals/{$rentalBooking->id}/return", [
            'deposit_returned' => true,
        ])->assertSessionHas('success');

        $this->assertEquals('returned', $rentalBooking->fresh()->status);
        $this->assertNotNull($rentalBooking->fresh()->deposit_returned_at);
    }
}
