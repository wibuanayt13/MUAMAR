<?php

namespace Tests\Feature;

use App\Models\Category;
use App\Models\Product;
use App\Models\Provider;
use App\Models\ProviderAvailability;
use App\Models\ProviderScheduleOverride;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

class ProviderProductCrudTest extends TestCase
{
    use RefreshDatabase;

    protected function setupProvider(): array
    {
        $user = User::factory()->create(['role' => 'provider']);
        $provider = Provider::create([
            'user_id' => $user->id,
            'business_name' => 'Studio Rias Cantika',
            'slug' => 'studio-rias-cantika',
            'address' => 'Jl. Kenanga 12',
            'city' => 'Jakarta Selatan',
            'phone' => '08123456789',
            'status' => 'approved',
        ]);

        $category = Category::create([
            'name' => 'Kategori Makeup',
            'slug' => 'kategori-makeup',
            'type' => 'all',
        ]);

        return [$user, $provider, $category];
    }

    public function test_provider_can_create_physical_product_with_variants(): void
    {
        Storage::fake('public');
        [$user, $provider, $category] = $this->setupProvider();

        $image = UploadedFile::fake()->image('lipcream.jpg', 600, 600);

        $response = $this->actingAs($user)->post('/provider/products', [
            'name' => 'Velvet Matte Lipcream',
            'category_id' => $category->id,
            'type' => 'physical',
            'base_price' => 85000,
            'description' => 'Lipcream tahan hingga 12 jam tanpa membuat bibir kering.',
            'images' => [$image],
            'variants' => [
                [
                    'variant_name' => 'Shade 01 Red Velvet',
                    'sku' => 'LIP-01-RED',
                    'price' => 85000,
                    'stock' => 20,
                ],
                [
                    'variant_name' => 'Shade 02 Nude Brown',
                    'sku' => 'LIP-02-NUDE',
                    'price' => 85000,
                    'stock' => 15,
                ],
            ],
        ]);

        $response->assertRedirect('/provider/products');
        $this->assertDatabaseHas('products', [
            'name' => 'Velvet Matte Lipcream',
            'provider_id' => $provider->id,
            'type' => 'physical',
            'base_price' => 85000,
        ]);

        $product = Product::where('slug', 'velvet-matte-lipcream')->first();
        $this->assertCount(2, $product->variants);
        $this->assertDatabaseHas('product_variants', [
            'product_id' => $product->id,
            'sku' => 'LIP-01-RED',
            'stock' => 20,
        ]);
    }

    public function test_provider_can_create_service_with_duration_and_buffer(): void
    {
        [$user, $provider, $category] = $this->setupProvider();

        $response = $this->actingAs($user)->post('/provider/products', [
            'name' => 'Paket Makeup Wisuda Flawless',
            'category_id' => $category->id,
            'type' => 'service',
            'base_price' => 400000,
            'duration_minutes' => 90,
            'buffer_minutes' => 45,
            'capacity_per_slot' => 1,
            'artist_name' => 'Kak Cantika',
            'service_area' => 'Jakarta & Depok',
        ]);

        $response->assertRedirect('/provider/products');

        $product = Product::where('name', 'Paket Makeup Wisuda Flawless')->first();
        $this->assertNotNull($product);
        $this->assertEquals('service', $product->type);
        $this->assertDatabaseHas('service_profiles', [
            'product_id' => $product->id,
            'duration_minutes' => 90,
            'buffer_minutes' => 45,
            'artist_name' => 'Kak Cantika',
        ]);
    }

    public function test_provider_can_create_rental_asset_with_capacity_and_deposit(): void
    {
        [$user, $provider, $category] = $this->setupProvider();

        $response = $this->actingAs($user)->post('/provider/products', [
            'name' => 'Sewa Kursi Futura Pita Emas',
            'category_id' => $category->id,
            'type' => 'rental',
            'base_price' => 15000,
            'total_units' => 100,
            'deposit_amount' => 50000,
            'min_rental_days' => 1,
            'buffer_hours' => 3,
            'unit_type' => 'buah kursi',
        ]);

        $response->assertRedirect('/provider/products');

        $product = Product::where('name', 'Sewa Kursi Futura Pita Emas')->first();
        $this->assertNotNull($product);
        $this->assertEquals('rental', $product->type);
        $this->assertDatabaseHas('rental_profiles', [
            'product_id' => $product->id,
            'total_units' => 100,
            'deposit_amount' => 50000,
        ]);
    }

    public function test_seller_a_cannot_edit_or_delete_seller_b_product(): void
    {
        // Seller A
        [$userA, $providerA, $category] = $this->setupProvider();

        // Seller B
        $userB = User::factory()->create(['role' => 'provider']);
        $providerB = Provider::create([
            'user_id' => $userB->id,
            'business_name' => 'Studio B',
            'slug' => 'studio-b',
            'address' => 'Bandung',
            'city' => 'Bandung',
            'phone' => '082222',
            'status' => 'approved',
        ]);

        $productB = Product::create([
            'provider_id' => $providerB->id,
            'category_id' => $category->id,
            'name' => 'Private Product Seller B',
            'slug' => 'private-product-seller-b',
            'type' => 'service',
            'base_price' => 1000000,
            'is_active' => true,
        ]);

        // Seller A tries to edit Seller B's product
        $editResponse = $this->actingAs($userA)->get("/provider/products/{$productB->id}/edit");
        $editResponse->assertStatus(403);

        // Seller A tries to update Seller B's product
        $updateResponse = $this->actingAs($userA)->put("/provider/products/{$productB->id}", [
            'name' => 'Hacked Name',
            'category_id' => $category->id,
            'base_price' => 100,
        ]);
        $updateResponse->assertStatus(403);

        // Seller A tries to delete Seller B's product
        $deleteResponse = $this->actingAs($userA)->delete("/provider/products/{$productB->id}");
        $deleteResponse->assertStatus(403);

        $this->assertDatabaseHas('products', ['id' => $productB->id, 'name' => 'Private Product Seller B']);
    }

    public function test_upload_rejects_non_image_or_executable_files(): void
    {
        Storage::fake('public');
        [$user, $provider, $category] = $this->setupProvider();

        $fakeScript = UploadedFile::fake()->create('malicious.php', 10, 'application/x-php');

        $response = $this->actingAs($user)->post('/provider/products', [
            'name' => 'Product Upload Test',
            'category_id' => $category->id,
            'type' => 'physical',
            'base_price' => 50000,
            'images' => [$fakeScript],
        ]);

        $response->assertSessionHasErrors(['images.0']);
        $this->assertDatabaseMissing('products', ['name' => 'Product Upload Test']);
    }

    public function test_provider_can_update_weekly_hours_and_schedule_overrides(): void
    {
        [$user, $provider] = $this->setupProvider();

        // 1. Update weekly working hours
        $schedules = [];
        for ($day = 0; $day <= 6; $day++) {
            $schedules[] = [
                'day_of_week' => $day,
                'start_time' => '09:00',
                'end_time' => '19:00',
                'is_available' => $day !== 0, // Libur hari Minggu
            ];
        }

        $schedResponse = $this->actingAs($user)->put('/provider/schedule', [
            'schedules' => $schedules,
        ]);
        $schedResponse->assertRedirect();

        $sunday = ProviderAvailability::where('provider_id', $provider->id)->where('day_of_week', 0)->first();
        $this->assertFalse($sunday->is_available);

        $monday = ProviderAvailability::where('provider_id', $provider->id)->where('day_of_week', 1)->first();
        $this->assertTrue($monday->is_available);
        $this->assertEquals('09:00:00', $monday->start_time);

        // 2. Add holiday override
        $holidayResponse = $this->actingAs($user)->post('/provider/schedule/override', [
            'override_date' => now()->addDays(5)->toDateString(),
            'reason' => 'Libur Workshop Makeup',
            'is_off' => true,
        ]);
        $holidayResponse->assertRedirect();

        $this->assertDatabaseHas('provider_schedule_overrides', [
            'provider_id' => $provider->id,
            'reason' => 'Libur Workshop Makeup',
        ]);
    }
}
