<?php

namespace Tests\Feature;

use App\Models\Category;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use App\Models\Provider;
use App\Models\Review;
use App\Models\User;
use App\Models\VendorOrder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class ReviewEligibilityTest extends TestCase
{
    use RefreshDatabase;

    protected function setupCompletedOrderItem(): array
    {
        $customer = User::factory()->create(['role' => 'customer']);
        $providerUser = User::factory()->create(['role' => 'provider']);
        $provider = Provider::create([
            'user_id' => $providerUser->id,
            'business_name' => 'Studio Rias Cantika',
            'slug' => 'studio-rias-cantika',
            'address' => 'Yogyakarta',
            'city' => 'Yogyakarta',
            'phone' => '0812345678',
            'status' => 'approved',
        ]);

        $category = Category::create([
            'name' => 'Jasa Rias',
            'slug' => 'jasa-rias',
            'type' => 'service',
        ]);

        $product = Product::create([
            'provider_id' => $provider->id,
            'category_id' => $category->id,
            'name' => 'Makeup Wisuda Flawless',
            'slug' => 'makeup-wisuda-flawless',
            'type' => 'service',
            'base_price' => 350000,
            'is_active' => true,
        ]);

        $order = Order::create([
            'order_number' => 'MUAMAR-REV-001',
            'user_id' => $customer->id,
            'total_amount' => 350000,
            'status' => 'completed',
            'payment_status' => 'paid',
            'payment_method' => 'qris',
            'shipping_address_snapshot' => ['city' => 'Yogyakarta'],
        ]);

        $vendorOrder = VendorOrder::create([
            'vendor_order_number' => 'VO-REV-001',
            'order_id' => $order->id,
            'provider_id' => $provider->id,
            'subtotal' => 350000,
            'total_amount' => 350000,
            'status' => 'completed',
            'payment_status' => 'paid',
        ]);

        $orderItem = OrderItem::create([
            'vendor_order_id' => $vendorOrder->id,
            'product_id' => $product->id,
            'item_type' => 'service',
            'name_snapshot' => $product->name,
            'price_snapshot' => 350000,
            'quantity' => 1,
            'subtotal' => 350000,
        ]);

        return [$customer, $orderItem, $product];
    }

    public function test_verified_customer_can_review_completed_order_item(): void
    {
        [$customer, $orderItem, $product] = $this->setupCompletedOrderItem();

        $response = $this->actingAs($customer)->post('/reviews', [
            'order_item_id' => $orderItem->id,
            'rating' => 5,
            'comment' => 'Hasil riasan sangat rapi dan memuaskan!',
        ]);

        $response->assertRedirect();
        $this->assertDatabaseHas('reviews', [
            'order_item_id' => $orderItem->id,
            'user_id' => $customer->id,
            'rating' => 5,
        ]);
    }

    public function test_non_buyer_cannot_review_order_item(): void
    {
        [$customer, $orderItem, $product] = $this->setupCompletedOrderItem();
        $intruder = User::factory()->create(['role' => 'customer']);

        $response = $this->actingAs($intruder)->post('/reviews', [
            'order_item_id' => $orderItem->id,
            'rating' => 1,
            'comment' => 'Percobaan ulasan palsu.',
        ]);

        $response->assertStatus(403);
    }

    public function test_cannot_review_uncompleted_order_item(): void
    {
        [$customer, $orderItem, $product] = $this->setupCompletedOrderItem();
        $orderItem->vendorOrder->update(['status' => 'pending_payment']);
        $orderItem->vendorOrder->order->update(['status' => 'pending_payment']);

        $response = $this->actingAs($customer)->post('/reviews', [
            'order_item_id' => $orderItem->id,
            'rating' => 5,
            'comment' => 'Ulasan terlalu cepat sebelum pesanan selesai.',
        ]);

        $response->assertSessionHas('error');
        $this->assertDatabaseMissing('reviews', [
            'order_item_id' => $orderItem->id,
        ]);
    }

    public function test_duplicate_review_is_prevented(): void
    {
        [$customer, $orderItem, $product] = $this->setupCompletedOrderItem();

        // First review
        Review::create([
            'user_id' => $customer->id,
            'provider_id' => $orderItem->vendorOrder->provider_id,
            'product_id' => $product->id,
            'order_item_id' => $orderItem->id,
            'rating' => 5,
            'comment' => 'Ulasan pertama.',
            'is_visible' => true,
        ]);

        // Second review attempt on same item
        $response = $this->actingAs($customer)->post('/reviews', [
            'order_item_id' => $orderItem->id,
            'rating' => 4,
            'comment' => 'Ulasan kedua tidak boleh lolos.',
        ]);

        $response->assertSessionHas('error');
        $this->assertEquals(1, Review::where('order_item_id', $orderItem->id)->count());
    }
}
