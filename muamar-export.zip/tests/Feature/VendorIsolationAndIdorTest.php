<?php

namespace Tests\Feature;

use App\Models\Conversation;
use App\Models\Order;
use App\Models\Provider;
use App\Models\User;
use App\Models\VendorOrder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class VendorIsolationAndIdorTest extends TestCase
{
    use RefreshDatabase;

    public function test_seller_a_cannot_modify_or_ship_seller_b_order(): void
    {
        // Seller A
        $userA = User::factory()->create(['role' => 'provider']);
        $providerA = Provider::create([
            'user_id' => $userA->id,
            'business_name' => 'Studio A',
            'slug' => 'studio-a',
            'address' => 'Addr A',
            'city' => 'Jakarta',
            'phone' => '0811111111',
            'status' => 'approved',
        ]);

        // Seller B
        $userB = User::factory()->create(['role' => 'provider']);
        $providerB = Provider::create([
            'user_id' => $userB->id,
            'business_name' => 'Studio B',
            'slug' => 'studio-b',
            'address' => 'Addr B',
            'city' => 'Bandung',
            'phone' => '0822222222',
            'status' => 'approved',
        ]);

        $customer = User::factory()->create(['role' => 'customer']);
        $order = Order::create([
            'order_number' => 'MUAMAR-TEST-001',
            'user_id' => $customer->id,
            'total_amount' => 500000,
            'status' => 'processing',
            'payment_status' => 'paid',
            'payment_method' => 'qris',
            'shipping_address_snapshot' => ['city' => 'Jakarta'],
        ]);

        // Vendor Order belonging strictly to Seller B
        $vendorOrderB = VendorOrder::create([
            'vendor_order_number' => 'VO-TEST-B-001',
            'order_id' => $order->id,
            'provider_id' => $providerB->id,
            'subtotal' => 500000,
            'total_amount' => 500000,
            'status' => 'processing',
            'payment_status' => 'paid',
        ]);

        // Seller A attempts to update resi / ship Seller B's order
        $response = $this->actingAs($userA)->patch("/provider/orders/{$vendorOrderB->id}/ship", [
            'shipping_carrier' => 'JNE Express',
            'tracking_number' => 'JNE9988776655',
        ]);

        // Must be rejected with 403 Forbidden!
        $response->assertStatus(403);
        $this->assertNull($vendorOrderB->fresh()->tracking_number);
    }

    public function test_customer_cannot_read_another_customer_order_invoice(): void
    {
        $customerA = User::factory()->create(['role' => 'customer']);
        $customerB = User::factory()->create(['role' => 'customer']);

        $orderA = Order::create([
            'order_number' => 'MUAMAR-A-001',
            'user_id' => $customerA->id,
            'total_amount' => 300000,
            'status' => 'processing',
            'payment_status' => 'paid',
            'payment_method' => 'qris',
            'shipping_address_snapshot' => ['name' => 'Customer A', 'city' => 'Jakarta'],
        ]);

        // Customer B tries to view Customer A's invoice
        $response = $this->actingAs($customerB)->get("/orders/{$orderA->order_number}/invoice");

        // Must be rejected with 403 Forbidden!
        $response->assertStatus(403);
    }

    public function test_user_cannot_read_another_users_chat_conversation(): void
    {
        $customer = User::factory()->create(['role' => 'customer']);
        $intruder = User::factory()->create(['role' => 'customer']);
        $providerUser = User::factory()->create(['role' => 'provider']);

        $provider = Provider::create([
            'user_id' => $providerUser->id,
            'business_name' => 'Studio Glow',
            'slug' => 'studio-glow',
            'address' => 'Addr',
            'city' => 'Surabaya',
            'phone' => '0833333333',
            'status' => 'approved',
        ]);

        $conversation = Conversation::create([
            'customer_id' => $customer->id,
            'provider_id' => $provider->id,
            'last_message_at' => now(),
        ]);

        // Intruder tries to access conversation
        $response = $this->actingAs($intruder)->get("/conversations/{$conversation->id}");

        $response->assertStatus(403);
    }
}
