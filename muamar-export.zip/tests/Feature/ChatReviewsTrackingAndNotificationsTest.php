<?php

namespace Tests\Feature;

use App\Models\Category;
use App\Models\Conversation;
use App\Models\Message;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use App\Models\Provider;
use App\Models\Review;
use App\Models\ShippingHistory;
use App\Models\User;
use App\Models\VendorOrder;
use App\Notifications\GeneralNotification;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Notification;
use Tests\TestCase;

class ChatReviewsTrackingAndNotificationsTest extends TestCase
{
    use RefreshDatabase;

    protected User $customer;
    protected User $providerUser;
    protected Provider $provider;
    protected Product $product;

    protected function setUp(): void
    {
        parent::setUp();

        $this->customer = User::factory()->create([
            'role' => 'customer',
            'is_active' => true,
        ]);

        $this->providerUser = User::factory()->create([
            'role' => 'provider',
            'is_active' => true,
        ]);

        $this->provider = Provider::create([
            'user_id' => $this->providerUser->id,
            'business_name' => 'Glow MUA Artistry Studio',
            'slug' => 'glow-mua-artistry-studio',
            'phone' => '081298765432',
            'city' => 'Jakarta Selatan',
            'address' => 'Jl. Kemang Raya No. 45',
            'status' => 'approved',
            'is_verified' => true,
            'is_location_public' => true,
            'latitude' => -6.2738,
            'longitude' => 106.8156,
        ]);

        $category = Category::create([
            'name' => 'Bridal Makeup',
            'slug' => 'bridal-makeup',
        ]);

        $this->product = Product::create([
            'provider_id' => $this->provider->id,
            'category_id' => $category->id,
            'name' => 'Paket Makeup Pengantin Glamour',
            'slug' => 'paket-makeup-pengantin-glamour',
            'type' => 'service',
            'base_price' => 2500000,
            'is_active' => true,
        ]);
    }

    public function test_chat_exchange_and_authorization_isolation(): void
    {
        // 1. Customer initiates chat
        $startRes = $this->actingAs($this->customer)->post('/conversations/start', [
            'provider_id' => $this->provider->id,
            'product_id' => $this->product->id,
        ]);

        $conversation = Conversation::first();
        $this->assertNotNull($conversation);
        $this->assertEquals($this->customer->id, $conversation->customer_id);
        $this->assertEquals($this->provider->id, $conversation->provider_id);

        $startRes->assertRedirect(route('chat.show', $conversation->id));

        // 2. Customer sends message
        $sendRes = $this->actingAs($this->customer)->post("/conversations/{$conversation->id}/messages", [
            'message' => 'Halo kak, apakah ada portofolio untuk resepsi adat Sunda?',
        ]);
        $sendRes->assertRedirect(route('chat.show', $conversation->id));

        $this->assertDatabaseHas('messages', [
            'conversation_id' => $conversation->id,
            'sender_id' => $this->customer->id,
            'message' => 'Halo kak, apakah ada portofolio untuk resepsi adat Sunda?',
        ]);

        // Verify provider received notification
        $this->assertDatabaseHas('notifications', [
            'notifiable_id' => $this->providerUser->id,
            'type' => GeneralNotification::class,
        ]);

        // 3. Provider replies
        $replyRes = $this->actingAs($this->providerUser)->post("/conversations/{$conversation->id}/messages", [
            'message' => 'Halo! Tentu ada kak, kami sudah sering merias pengantin siger Sunda.',
        ]);
        $replyRes->assertRedirect(route('chat.show', $conversation->id));

        // Verify customer received notification
        $this->assertDatabaseHas('notifications', [
            'notifiable_id' => $this->customer->id,
            'type' => GeneralNotification::class,
        ]);

        // 4. Unauthorized User C tries to view conversation -> 403 Forbidden
        $otherUser = User::factory()->create(['role' => 'customer']);
        $this->actingAs($otherUser)
            ->get("/conversations/{$conversation->id}")
            ->assertStatus(403);

        $this->actingAs($otherUser)
            ->post("/conversations/{$conversation->id}/messages", ['message' => 'Sneaky message'])
            ->assertStatus(403);
    }

    public function test_verified_review_submission_and_provider_reply(): void
    {
        // Setup completed order
        $order = Order::create([
            'order_number' => 'MUAMAR-ORD-REVIEW',
            'user_id' => $this->customer->id,
            'total_amount' => 2500000,
            'total_deposit' => 0,
            'status' => 'completed',
            'payment_status' => 'paid',
            'payment_method' => 'qris',
            'shipping_address_snapshot' => [
                'name' => $this->customer->name,
                'address' => 'Jl. Pengantin No. 1',
                'phone' => '08123456789',
            ],
        ]);

        $vendorOrder = VendorOrder::create([
            'vendor_order_number' => 'VO-REV-01',
            'order_id' => $order->id,
            'provider_id' => $this->provider->id,
            'subtotal' => 2500000,
            'deposit_subtotal' => 0,
            'shipping_cost' => 0,
            'total_amount' => 2500000,
            'status' => 'completed',
            'payment_status' => 'paid',
        ]);

        $orderItem = OrderItem::create([
            'vendor_order_id' => $vendorOrder->id,
            'product_id' => $this->product->id,
            'item_type' => 'service',
            'name_snapshot' => $this->product->name,
            'price_snapshot' => 2500000,
            'deposit_snapshot' => 0,
            'quantity' => 1,
            'subtotal' => 2500000,
        ]);

        // Customer submits 5-star review
        $reviewRes = $this->actingAs($this->customer)->post('/reviews', [
            'order_item_id' => $orderItem->id,
            'rating' => 5,
            'comment' => 'Hasil riasan sangat rapi, tahan seharian dan tidak cakey. Recommended!',
        ]);

        $reviewRes->assertSessionHas('success');
        $this->assertDatabaseHas('reviews', [
            'order_item_id' => $orderItem->id,
            'user_id' => $this->customer->id,
            'rating' => 5,
        ]);

        $review = Review::where('order_item_id', $orderItem->id)->first();

        // Provider replies to review
        $replyRes = $this->actingAs($this->providerUser)->post("/reviews/{$review->id}/reply", [
            'provider_reply' => 'Terima kasih banyak kak atas kepercayaannya! Semoga langgeng selalu.',
        ]);

        $replyRes->assertSessionHas('success');
        $this->assertDatabaseHas('reviews', [
            'id' => $review->id,
            'provider_reply' => 'Terima kasih banyak kak atas kepercayaannya! Semoga langgeng selalu.',
        ]);
    }

    public function test_manual_shipment_tracking_and_timeline(): void
    {
        $order = Order::create([
            'order_number' => 'MUAMAR-ORD-SHIP',
            'user_id' => $this->customer->id,
            'total_amount' => 500000,
            'total_deposit' => 0,
            'status' => 'processing',
            'payment_status' => 'paid',
            'payment_method' => 'qris',
            'shipping_address_snapshot' => [
                'name' => $this->customer->name,
                'address' => 'Jl. Pengiriman No. 9',
                'phone' => '08123456789',
            ],
        ]);

        $vendorOrder = VendorOrder::create([
            'vendor_order_number' => 'VO-SHIP-01',
            'order_id' => $order->id,
            'provider_id' => $this->provider->id,
            'subtotal' => 500000,
            'deposit_subtotal' => 0,
            'shipping_cost' => 0,
            'total_amount' => 500000,
            'status' => 'processing',
            'payment_status' => 'paid',
        ]);

        // 1. Provider inputs tracking resi
        $shipRes = $this->actingAs($this->providerUser)->patch("/provider/orders/{$vendorOrder->id}/ship", [
            'shipping_carrier' => 'JNE Express',
            'tracking_number' => 'JNE987654321ID',
        ]);

        $shipRes->assertSessionHas('success');
        $vendorOrder->refresh();
        $this->assertEquals('shipped', $vendorOrder->status);
        $this->assertEquals('JNE Express', $vendorOrder->shipping_carrier);
        $this->assertEquals('JNE987654321ID', $vendorOrder->tracking_number);

        $this->assertDatabaseHas('shipping_histories', [
            'vendor_order_id' => $vendorOrder->id,
            'status' => 'shipped',
        ]);

        // 2. Provider posts intermediate status update
        $updateRes = $this->actingAs($this->providerUser)->post("/provider/orders/{$vendorOrder->id}/tracking-update", [
            'status' => 'delivered',
            'notes' => 'Paket sedang dibawa kurir menuju alamat tujuan dan telah diterima.',
        ]);

        $updateRes->assertSessionHas('success');
        $this->assertDatabaseHas('shipping_histories', [
            'vendor_order_id' => $vendorOrder->id,
            'status' => 'delivered',
            'notes' => 'Paket sedang dibawa kurir menuju alamat tujuan dan telah diterima.',
        ]);

        // 3. Customer checks invoice and views tracking timeline
        $invoiceRes = $this->actingAs($this->customer)->get("/orders/{$order->order_number}/invoice");
        $invoiceRes->assertStatus(200);
        $invoiceRes->assertSee('JNE Express');
        $invoiceRes->assertSee('JNE987654321ID');
        $invoiceRes->assertSee('Paket sedang dibawa kurir menuju alamat tujuan dan telah diterima.');
    }

    public function test_maps_public_opt_in_and_customer_privacy(): void
    {
        // Provider A: opt-in public location
        // Already created in setUp: 'Glow MUA Artistry Studio', is_location_public = true, -6.2738, 106.8156

        // Provider B: private location (opt-out)
        $userB = User::factory()->create(['role' => 'provider']);
        $providerB = Provider::create([
            'user_id' => $userB->id,
            'business_name' => 'Secret Beauty Room',
            'slug' => 'secret-beauty-room',
            'phone' => '081211112222',
            'city' => 'Bandung',
            'address' => 'Jl. Rahasia No. 1',
            'status' => 'approved',
            'is_verified' => true,
            'is_location_public' => false,
            'latitude' => -6.9175,
            'longitude' => 107.6191,
        ]);

        $mapRes = $this->get('/providers/map');
        $mapRes->assertStatus(200);

        // Provider A is visible
        $mapRes->assertSee('Glow MUA Artistry Studio');

        // Provider B (opt-out) is NOT visible
        $mapRes->assertDontSee('Secret Beauty Room');

        // Customer's address must never be shown on public map
        $mapRes->assertDontSee($this->customer->email);
        $mapRes->assertDontSee('Jl. Kemang Raya No. 45 - Customer Private Home');
    }

    public function test_notification_center_and_read_actions(): void
    {
        // Dispatch notification
        $this->customer->notify(new GeneralNotification(
            'Pesanan Berhasil Dibuat',
            'Pesanan MUAMAR-ORD-123 sedang diproses.',
            '/orders/MUAMAR-ORD-123/invoice',
            'order'
        ));

        $this->assertEquals(1, $this->customer->unreadNotifications()->count());

        // View notifications page
        $indexRes = $this->actingAs($this->customer)->get('/notifications');
        $indexRes->assertStatus(200);
        $indexRes->assertSee('Pesanan Berhasil Dibuat');

        // Mark all as read
        $readAllRes = $this->actingAs($this->customer)->post('/notifications/read-all');
        $readAllRes->assertSessionHas('success');

        $this->assertEquals(0, $this->customer->fresh()->unreadNotifications()->count());
    }
}
