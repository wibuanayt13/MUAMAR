<?php

namespace Tests\Feature;

use App\Models\Category;
use App\Models\Product;
use App\Models\Provider;
use App\Models\RentalBooking;
use App\Models\RentalProfile;
use App\Models\User;
use App\Services\RentalSchedulerService;
use Carbon\Carbon;
use Exception;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class RentalCapacityOverlapTest extends TestCase
{
    use RefreshDatabase;

    protected function setupRentalProduct(): array
    {
        $providerUser = User::factory()->create(['role' => 'provider']);
        $provider = Provider::create([
            'user_id' => $providerUser->id,
            'business_name' => 'Tenda Berkah Rental',
            'slug' => 'tenda-berkah-rental',
            'address' => 'Bandung',
            'city' => 'Bandung',
            'phone' => '0899887766',
            'status' => 'approved',
        ]);

        $category = Category::create([
            'name' => 'Sewa Tenda',
            'slug' => 'sewa-tenda',
            'type' => 'rental',
        ]);

        $product = Product::create([
            'provider_id' => $provider->id,
            'category_id' => $category->id,
            'name' => 'Tenda Roder VIP 4x6',
            'slug' => 'tenda-roder-vip-4x6',
            'type' => 'rental',
            'base_price' => 1000000,
            'is_active' => true,
        ]);

        $rentalProfile = RentalProfile::create([
            'product_id' => $product->id,
            'total_units' => 5, // Total 5 units available
            'deposit_amount' => 500000,
            'min_rental_days' => 1,
            'buffer_hours' => 4,
            'unit_type' => 'unit tenda',
        ]);

        return [$product, $rentalProfile];
    }

    public function test_rental_capacity_cannot_exceed_available_units_on_overlapping_interval(): void
    {
        [$product, $profile] = $this->setupRentalProduct();
        $scheduler = app(RentalSchedulerService::class);

        $customer1 = User::factory()->create(['role' => 'customer']);
        $customer2 = User::factory()->create(['role' => 'customer']);
        $customer3 = User::factory()->create(['role' => 'customer']);

        $start1 = Carbon::parse('2026-12-01 00:00:00', 'UTC');
        $end1 = Carbon::parse('2026-12-03 00:00:00', 'UTC');

        // Customer 1 rents 3 units
        $booking1 = $scheduler->holdRental($product, $customer1, $start1, $end1, 3);
        $this->assertEquals(3, $booking1->quantity_rented);

        // Customer 2 rents 2 units for overlapping dates (Dec 02 to Dec 04) => total rented = 3 + 2 = 5 (allowed)
        $start2 = Carbon::parse('2026-12-02 00:00:00', 'UTC');
        $end2 = Carbon::parse('2026-12-04 00:00:00', 'UTC');
        $booking2 = $scheduler->holdRental($product, $customer2, $start2, $end2, 2);
        $this->assertEquals(2, $booking2->quantity_rented);

        // Customer 3 tries to rent 1 unit for overlapping date Dec 02 => 3 + 2 + 1 = 6 > 5 (must be rejected!)
        $this->expectException(Exception::class);
        $this->expectExceptionMessage('Kapasitas sewa perlengkapan tidak mencukupi');

        $scheduler->holdRental($product, $customer3, $start2, $end2, 1);
    }
}
