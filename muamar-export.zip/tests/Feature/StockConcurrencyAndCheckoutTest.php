<?php

namespace Tests\Feature;

use App\Models\CartItem;
use App\Models\Category;
use App\Models\Product;
use App\Models\ProductVariant;
use App\Models\Provider;
use App\Models\User;
use App\Services\OrderCheckoutService;
use Exception;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class StockConcurrencyAndCheckoutTest extends TestCase
{
    use RefreshDatabase;

    public function test_last_stock_cannot_be_purchased_twice(): void
    {
        $providerUser = User::factory()->create(['role' => 'provider']);
        $provider = Provider::create([
            'user_id' => $providerUser->id,
            'business_name' => 'Kosmetik Original',
            'slug' => 'kosmetik-original',
            'address' => 'Jakarta Barat',
            'city' => 'Jakarta Barat',
            'phone' => '0855555555',
            'status' => 'approved',
        ]);

        $category = Category::create([
            'name' => 'Makeup Face',
            'slug' => 'makeup-face',
            'type' => 'product',
        ]);

        $product = Product::create([
            'provider_id' => $provider->id,
            'category_id' => $category->id,
            'name' => 'Flawless Cushion SPF 50',
            'slug' => 'flawless-cushion-spf-50',
            'type' => 'physical',
            'base_price' => 175000,
            'is_active' => true,
        ]);

        // Variant with exactly 1 unit of stock
        $variant = ProductVariant::create([
            'product_id' => $product->id,
            'sku' => 'CSH-01-LIGHT',
            'variant_name' => 'Light Beige',
            'price' => 175000,
            'stock' => 1,
            'is_active' => true,
        ]);

        $customer1 = User::factory()->create(['role' => 'customer']);
        $customer2 = User::factory()->create(['role' => 'customer']);

        $checkoutService = app(OrderCheckoutService::class);

        // 1. Customer 1 adds last stock to cart and checks out
        CartItem::create([
            'user_id' => $customer1->id,
            'product_id' => $product->id,
            'product_variant_id' => $variant->id,
            'item_type' => 'physical',
            'quantity' => 1,
        ]);

        $order1 = $checkoutService->checkout(
            customer: $customer1,
            shippingAddress: ['name' => 'Cust 1', 'address' => 'Jl. A', 'city' => 'Jakarta'],
            paymentMethod: 'qris'
        );

        $this->assertNotNull($order1);
        $this->assertEquals(0, $variant->fresh()->stock);

        // 2. Customer 2 tries to checkout the now out-of-stock item
        CartItem::create([
            'user_id' => $customer2->id,
            'product_id' => $product->id,
            'product_variant_id' => $variant->id,
            'item_type' => 'physical',
            'quantity' => 1,
        ]);

        $this->expectException(Exception::class);
        $this->expectExceptionMessage('tidak mencukupi');

        $checkoutService->checkout(
            customer: $customer2,
            shippingAddress: ['name' => 'Cust 2', 'address' => 'Jl. B', 'city' => 'Jakarta'],
            paymentMethod: 'qris'
        );
    }

    public function test_multi_vendor_checkout_splits_into_individual_vendor_orders(): void
    {
        $provUser1 = User::factory()->create(['role' => 'provider']);
        $provUser2 = User::factory()->create(['role' => 'provider']);

        $provider1 = Provider::create([
            'user_id' => $provUser1->id,
            'business_name' => 'Studio Rias Mawar',
            'slug' => 'studio-rias-mawar',
            'address' => 'Jakarta',
            'city' => 'Jakarta',
            'phone' => '08111',
            'status' => 'approved',
        ]);

        $provider2 = Provider::create([
            'user_id' => $provUser2->id,
            'business_name' => 'Tenda Pernikahan Bandung',
            'slug' => 'tenda-pernikahan-bandung',
            'address' => 'Bandung',
            'city' => 'Bandung',
            'phone' => '08222',
            'status' => 'approved',
        ]);

        $cat = Category::create(['name' => 'General', 'slug' => 'gen', 'type' => 'all']);

        $prod1 = Product::create([
            'provider_id' => $provider1->id,
            'category_id' => $cat->id,
            'name' => 'Lipcream Velvet',
            'slug' => 'lipcream-velvet',
            'type' => 'physical',
            'base_price' => 80000,
            'is_active' => true,
        ]);
        $var1 = ProductVariant::create([
            'product_id' => $prod1->id,
            'sku' => 'LIP-01',
            'variant_name' => 'Nude Pink',
            'price' => 80000,
            'stock' => 10,
        ]);

        $prod2 = Product::create([
            'provider_id' => $provider2->id,
            'category_id' => $cat->id,
            'name' => 'Blush On Shimmer',
            'slug' => 'blush-on-shimmer',
            'type' => 'physical',
            'base_price' => 120000,
            'is_active' => true,
        ]);
        $var2 = ProductVariant::create([
            'product_id' => $prod2->id,
            'sku' => 'BLS-01',
            'variant_name' => 'Coral Peach',
            'price' => 120000,
            'stock' => 10,
        ]);

        $customer = User::factory()->create(['role' => 'customer']);

        // Customer puts products from 2 different vendors in the same cart
        CartItem::create([
            'user_id' => $customer->id,
            'product_id' => $prod1->id,
            'product_variant_id' => $var1->id,
            'item_type' => 'physical',
            'quantity' => 2, // 2x 80000 = 160000
        ]);

        CartItem::create([
            'user_id' => $customer->id,
            'product_id' => $prod2->id,
            'product_variant_id' => $var2->id,
            'item_type' => 'physical',
            'quantity' => 1, // 1x 120000 = 120000
        ]);

        $checkoutService = app(OrderCheckoutService::class);
        $order = $checkoutService->checkout(
            customer: $customer,
            shippingAddress: ['name' => 'Customer Multi', 'address' => 'Jl. Sudirman', 'city' => 'Jakarta'],
            paymentMethod: 'qris'
        );

        // Master Order Total: 160.000 + 120.000 = 280.000
        $this->assertEquals(280000, $order->total_amount);

        // Split into 2 distinct vendor orders
        $this->assertCount(2, $order->vendorOrders);

        $vo1 = $order->vendorOrders->firstWhere('provider_id', $provider1->id);
        $this->assertEquals(160000, $vo1->subtotal);

        $vo2 = $order->vendorOrders->firstWhere('provider_id', $provider2->id);
        $this->assertEquals(120000, $vo2->subtotal);

        // Cart is cleared
        $this->assertEquals(0, CartItem::where('user_id', $customer->id)->count());
    }
}
